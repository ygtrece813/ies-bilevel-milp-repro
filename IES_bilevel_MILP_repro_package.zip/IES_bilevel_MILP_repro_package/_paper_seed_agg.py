# -*- coding: utf-8 -*-
"""汇总多种子实验1结果 → 生成论文 §5.4 稳健性表格数据。"""
import sys
import pandas as pd
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SEEDS = [42, 43, 44]


def dominated_frac(fa, fb):
    """fa 中被 fb 任一点弱支配且至少一维严格优的比例。"""
    hit = 0
    for a in fa:
        if any(all(mb <= ma for mb, ma in zip(b, a)) and
               any(mb < ma for mb, ma in zip(b, a)) for b in fb):
            hit += 1
    return hit / max(len(fa), 1)


def main():
    rows = []
    for s in SEEDS:
        tag = '' if s == 42 else f'_{s}'
        try:
            df = pd.read_csv(f'_paper_exp1_fronts{tag}.csv', encoding='utf-8-sig')
        except FileNotFoundError:
            print(f'种子 {s}: 文件缺失, 跳过')
            continue
        r = df[df.arm == 'rule'][['TA', 'AC', 'TG']].values
        m = df[df.arm == 'milp'][['TA', 'AC', 'TG']].values
        rows.append(dict(
            seed=s,
            n_rule=len(r), n_milp=len(m),
            frac_dom=dominated_frac(r, m) * 100,
            ta_rule=r[:, 0].min(), ta_milp=m[:, 0].min(),
            ac_rule=r[:, 1].min(), ac_milp=m[:, 1].min(),
            tg_rule=r[:, 2].min(), tg_milp=m[:, 2].min(),
        ))
    if not rows:
        print('无可用数据')
        return
    df = pd.DataFrame(rows)
    df['TA改善%'] = (1 - df.ta_milp / df.ta_rule) * 100
    df['AC改善%'] = (1 - df.ac_milp / df.ac_rule) * 100
    df['TG改善%'] = (1 - df.tg_milp / df.tg_rule) * 100
    df['knee_PV'] = df['knee_Bat'] = np.nan

    # 拐点配置
    import json
    for i, s in enumerate(SEEDS):
        tag = '' if s == 42 else f'_{s}'
        try:
            with open(f'_paper_exp1_knee{tag}.json', encoding='utf-8') as f:
                k = json.load(f)
            df.loc[df.seed == s, 'knee_PV'] = k['X_PV']
            df.loc[df.seed == s, 'knee_Bat'] = k['X_Bat']
            df.loc[df.seed == s, 'knee_Tank'] = k['X_Tank']
        except (FileNotFoundError, NameError):
            pass

    pd.set_option('display.width', 200)
    print('\n===== 多种子稳健性汇总 (实验1) =====')
    cols = ['seed', 'n_rule', 'n_milp', 'frac_dom', 'TA改善%', 'AC改善%', 'TG改善%',
            'knee_PV', 'knee_Bat', 'knee_Tank']
    print(df[cols].round(2).to_string(index=False))
    df.to_csv('_paper_exp1_seeds_agg.csv', index=False, encoding='utf-8-sig')
    print('\n已保存: _paper_exp1_seeds_agg.csv')


if __name__ == '__main__':
    main()
