# -*- coding: utf-8 -*-
"""
小论文实验 2: 多时间尺度调度价值验证 (固定容量, Essie 四典型日)
================================================================
容量固定 = 实验 1 嵌套 MILP Pareto 前沿的 TOPSIS 拐点配置 (含 MILP 推导的 ASHP)。
同一 RT 实际负荷曲线 (5min/288 步, 8% 扰动) 上, 开环执行三种颗粒度的计划:
    DA-only : 日前 1h 计划 (无噪声预测) 直接执行
    DA-ID   : 日内 15min 重优化计划 (3% 预测误差) 执行
    DA-ID-RT: 实时 5min 重优化计划 (直接基于实际) 执行
不平衡 (供≠需) 按失负荷 10000 ¥/kWh + 弃能 0.5 ¥/kWh 结算, 度量
"计划颗粒度 ↓ → 执行偏差损失 ↓" 的多尺度价值。

输出: _paper_exp2_table.csv / 论文图片/图3_实验2_多时间尺度执行对比.png / 控制台表格
"""
import sys
import os
import copy
import joblib
import numpy as np
import pandas as pd
import pulp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.patches import Patch

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import _paper_figstyle  # noqa: F401  (统一风格)

from multi_scale_engine import MultiScaleDispatcher
from system_builder import SystemBuilder
from milp_capacity_engine import MILPCapacityEngine
import pyomo.environ as pyo

PEN_SHORT, PEN_DUMP = 10000.0, 0.5
T_RT, DT_RT = 288, 5.0 / 60.0


# ---------------- 容量: 实验 1 MILP 前沿 TOPSIS 拐点 ----------------
def knee_from_exp1():
    import json
    with open('_paper_exp1_knee.json', encoding='utf-8') as f:
        k = json.load(f)
    return float(k['X_PV']), float(k['X_Bat']), float(k['X_Tank'])


def milp_ashp_kw(contract, pv, bat, tank):
    """在拐点容量处重解 MILP, 提取 ASHP 电装机 (kW)。"""
    cfg = {"Scenario": "Custom", "Buses": ["ElectricityBus", "HeatBus", "CoolBus"],
           "obj_cost": True, "obj_carbon": True, "obj_grid": True,
           "Parameters": {"capacity_bounds": {'Roof_PV': [pv, pv], 'Battery_Array': [bat, bat],
                                              'Thermal_Tank': [tank, tank]}},
           "Components": {"State_Grid": {"allow_sell": False}, "Roof_PV": {}, "Main_ASHP": {},
                          "Battery_Array": {}, "Thermal_Tank": {}}}
    eng = MILPCapacityEngine(cfg, contract)
    eng.build_model()
    opt = pyo.SolverFactory('asl:cbc')
    if not opt.available(exception_flag=False):
        opt = pyo.SolverFactory('asl:cbc', executable=r'C:\Users\i5\Desktop\.venv1\Scripts\cbc.exe')
    opt.solve(eng.m, tee=False)
    return float(pyo.value(eng.m.ASHP_Cap))


# ---------------- 调度配置 (GUI 翻译链等价) ----------------
def make_config(contract, day_idx, pv, bat, tank, ashp_el_kw):
    return {
        "Scenario": "Custom", "custom_day_idx": day_idx, "custom_data": contract,
        "Buses": ["ElectricityBus", "HeatBus", "CoolBus"],
        "Components": {
            "State_Grid": {"type": "PowerGrid", "bus": "ElectricityBus",
                           "p_max": 50000, "p_sell_max": 0, "allow_sell": False},
            "Roof_PV": {"type": "RenewableSource", "bus": "ElectricityBus",
                        "capacity": pv, "inputs": {}, "outputs": {"out": "ElectricityBus"}},
            "Battery_Array": {"type": "Storage_Battery", "bus": "ElectricityBus",
                              "capacity": bat, "power": bat * 0.2},
            "Main_ASHP": {"type": "AirSourceHeatPump", "capacity": ashp_el_kw},  # 电功率口径, 与规划层/执行层一致 (热冷同供共享电容量)
            "Heat_Tank": {"type": "Storage_HeatTank", "capacity": tank, "power": tank * 0.2},
            "Cool_Tank": {"type": "Storage_CoolTank", "capacity": tank, "power": tank * 0.2},
            "Elec_Load": {"type": "EnergyLoad", "target_bus": "ElectricityBus", "load_type": "E_load"},
            "Heat_Load": {"type": "EnergyLoad", "target_bus": "HeatBus", "load_type": "H_load"},
            "Cool_Load": {"type": "EnergyLoad", "target_bus": "CoolBus", "load_type": "C_load"},
        },
    }


def extract(builder):
    res = {}
    for c_name, comp in builder.components.items():
        d = {}
        for v_name, v_list in comp.vars.items():
            if isinstance(v_list, list) and v_list and isinstance(v_list[0], pulp.LpVariable):
                d[v_name] = np.array([v.varValue if v.varValue is not None else 0.0 for v in v_list])
        res[c_name] = d
    return res


def bus_penalty(builder, T, dt):
    sh = du = 0.0
    for b in builder.buses.values():
        sh += sum((v.varValue or 0.0) for v in b.short_vars) * dt
        du += sum((v.varValue or 0.0) for v in b.dump_vars) * dt
    return sh, du


def run_multiscale(disp):
    """复刻 run_simulation 的 DA→ID→RT 循环, 返回三个颗粒度的计划 (画图跳过)。"""
    # ---- DA ----
    cfg_da = disp._prepare_config(disp.load_DA)
    b_da = SystemBuilder(cfg_da, disp.load_DA['T'], disp.load_DA['dt'])
    b_da.build(); b_da.model += b_da.base_cost
    b_da.solve(time_limit=120)
    da_res = extract(b_da)
    da_cost = float(pulp.value(b_da.base_cost) or 0.0)
    print(f'    DA 最优运行成本 = {da_cost:,.0f} ¥')

    # ---- ID (15min, 追踪 DA) ----
    T_id, dt_id = disp.load_ID['T'], disp.load_ID['dt']
    horizon_id = int(4 / dt_id)
    states_id, id_res = {}, {c: {v: np.zeros(T_id) for v in da_res[c]} for c in da_res}
    t_da_c = np.arange(disp.load_DA['T']) * disp.load_DA['dt'] + disp.load_DA['dt'] / 2
    from scipy.interpolate import interp1d
    for k in range(T_id):
        end = min(k + horizon_id, T_id); L = end - k
        wd = {'T': L, 'dt': dt_id,
              'E_load': disp.load_ID['E_load'][k:end], 'C_load': disp.load_ID['C_load'][k:end],
              'H_load': disp.load_ID['H_load'][k:end],
              'G_load': disp.load_ID.get('G_load', np.zeros(L))[k:end],
              'H2_load': disp.load_ID.get('H2_load', np.zeros(L))[k:end],
              'PV_out': disp.load_ID['PV_out'][k:end],
              'Wind_out': disp.load_ID.get('Wind_out', np.zeros(L))[k:end]}
        cfg = disp._prepare_config(wd, states_id, step_idx=k)
        b = SystemBuilder(cfg, L, dt_id); b.build()
        pen = 0
        for c_name, comp in b.components.items():
            if c_name not in da_res: continue
            for v_name, v_list in comp.vars.items():
                if v_name in ['SOC', 'State', 'u_in', 'u_out'] or v_name not in da_res[c_name]: continue
                f_ref = interp1d(t_da_c, da_res[c_name][v_name], kind='nearest',
                                 bounds_error=False,
                                 fill_value=(da_res[c_name][v_name][0], da_res[c_name][v_name][-1]))
                for i in range(L):
                    ref = f_ref((k + i) * dt_id + dt_id / 2).item()
                    dev = pulp.LpVariable(f'dev_{c_name}_{v_name}_{k}_{i}', lowBound=0)
                    b.model += (dev >= v_list[i] - ref); b.model += (dev >= ref - v_list[i])
                    pen += dev * 500
        b.model += b.base_cost + pen
        b.solve(time_limit=30)
        if pulp.LpStatus[b.model.status] == 'Optimal':
            for c_name, comp in b.components.items():
                if c_name in id_res:
                    for v_name, v_list in comp.vars.items():
                        if v_name in id_res[c_name] and isinstance(v_list, list) and v_list \
                                and isinstance(v_list[0], pulp.LpVariable):
                            id_res[c_name][v_name][k] = v_list[0].varValue or 0.0
                            if v_name in ['SOC', 'State'] and len(v_list) > 1:
                                cmax = max(getattr(comp, 'C_max', 1.0), 1e-6)
                                states_id[c_name] = max(0.0, min(1.0, v_list[1].varValue / cmax))
    print('    ID 完成 (96 步)')

    # ---- RT (5min, 追踪 ID) ----
    T_rt, dt_rt = disp.load_RT['T'], disp.load_RT['dt']
    horizon_rt = max(1, int(0.25 / dt_rt))
    states_rt, rt_res = {}, {c: {v: np.zeros(T_rt) for v in id_res[c]} for c in id_res}
    t_id_c = np.arange(T_id) * dt_id + dt_id / 2
    for k in range(T_rt):
        end = min(k + horizon_rt, T_rt); L = end - k
        wd = {'T': L, 'dt': dt_rt,
              'E_load': disp.load_RT['E_load'][k:end], 'C_load': disp.load_RT['C_load'][k:end],
              'H_load': disp.load_RT['H_load'][k:end],
              'G_load': disp.load_RT.get('G_load', np.zeros(L))[k:end],
              'H2_load': disp.load_RT.get('H2_load', np.zeros(L))[k:end],
              'PV_out': disp.load_RT['PV_out'][k:end],
              'Wind_out': disp.load_RT.get('Wind_out', np.zeros(L))[k:end]}
        cfg = disp._prepare_config(wd, states_rt, step_idx=k)
        b = SystemBuilder(cfg, L, dt_rt); b.build()
        pen = 0
        for c_name, comp in b.components.items():
            if c_name not in id_res: continue
            for v_name, v_list in comp.vars.items():
                if v_name in ['SOC', 'State', 'u_in', 'u_out'] or v_name not in id_res[c_name]: continue
                f_ref = interp1d(t_id_c, id_res[c_name][v_name], kind='nearest',
                                 bounds_error=False,
                                 fill_value=(id_res[c_name][v_name][0], id_res[c_name][v_name][-1]))
                for i in range(L):
                    ref = f_ref((k + i) * dt_rt + dt_rt / 2).item()
                    dev = pulp.LpVariable(f'devr_{c_name}_{v_name}_{k}_{i}', lowBound=0)
                    b.model += (dev >= v_list[i] - ref); b.model += (dev >= ref - v_list[i])
                    pen += dev * 800
        b.model += b.base_cost + pen
        b.solve(time_limit=30)
        if pulp.LpStatus[b.model.status] == 'Optimal':
            for c_name, comp in b.components.items():
                if c_name in rt_res:
                    for v_name, v_list in comp.vars.items():
                        if v_name in rt_res[c_name] and isinstance(v_list, list) and v_list \
                                and isinstance(v_list[0], pulp.LpVariable):
                            rt_res[c_name][v_name][k] = v_list[0].varValue or 0.0
                            if v_name in ['SOC', 'State'] and len(v_list) > 1:
                                cmax = max(getattr(comp, 'C_max', 1.0), 1e-6)
                                states_rt[c_name] = max(0.0, min(1.0, v_list[1].varValue / cmax))
    print('    RT 完成 (288 步)')
    return da_res, id_res, rt_res


def execute_on_rt(plan, disp, pv_cap, idx_map):
    """把某颗粒度计划映射到 RT 实际时线上开环执行, 返回 (成本¥, 失负荷kWh, 弃能kWh, 偏差kWh)。

    开环执行语义 (电网为电侧 slack):
      - PV 注入 = min(实际可用, 计划 P_out)  ← 计划 P_out 已含弃电决策
      - 储能/ASHP 按计划执行 (开环, 不二次调整)
      - 电侧缺额 → 电网实时补偿购电 (成本 = 追加购电×当时电价); 富余 → 弃能 0.5¥/kWh
      - 热/冷侧缺额 → 真实失负荷 10000¥/kWh; 富余 → 弃能
    idx_map: RT 步 t → 该计划时轴上的索引 (DA: t//12, ID: t//3, RT: t)。
    """
    RT = disp.load_RT
    pv_norm_max = float(np.max(disp.load_DA['PV_out'])) or 1.0
    buy_price = np.interp(np.arange(T_RT) * DT_RT + DT_RT / 2, np.arange(24) + 0.5,
                          disp.sys_data['price']['buy'])
    cost = sh = du = dev = 0.0
    n_map = len(idx_map)
    for t in range(T_RT):
        i = idx_map[min(t, n_map - 1)]

        def fv(c, v):
            arr = plan.get(c, {}).get(v, None)
            return float(arr[i]) if arr is not None and i < len(arr) else 0.0

        pv_avail = RT['PV_out'][t] / pv_norm_max * pv_cap
        pv_inj = min(pv_avail, fv('Roof_PV', 'P_out'))
        e_a, h_a, c_a = RT['E_load'][t], RT['H_load'][t], RT['C_load'][t]
        buy_p = fv('State_Grid', 'P_buy')
        bat_ch, bat_dis = fv('Battery_Array', 'Flow_in'), fv('Battery_Array', 'Flow_out')
        ashp_el = fv('Main_ASHP', 'P_elec_in')
        qh, qc = fv('Main_ASHP', 'Q_heat_out'), fv('Main_ASHP', 'Q_cool_out')
        ht_dis, ht_ch = fv('Heat_Tank', 'Flow_out'), fv('Heat_Tank', 'Flow_in')
        ct_dis, ct_ch = fv('Cool_Tank', 'Flow_out'), fv('Cool_Tank', 'Flow_in')

        # 电侧: 电网 slack, 缺额→追加购电, 富余→弃能
        bal_el = pv_inj + bat_dis + buy_p - (e_a + bat_ch + ashp_el)
        extra_buy = max(0.0, -bal_el)
        dump_el = max(0.0, bal_el)
        # 热/冷侧: 开环无补偿, 缺额=失负荷
        bal_h = qh + ht_dis - (h_a + ht_ch)
        bal_c = qc + ct_dis - (c_a + ct_ch)
        s_t = max(0.0, -bal_h) + max(0.0, -bal_c)
        d_t = dump_el + max(0.0, bal_h) + max(0.0, bal_c)
        sh += s_t * DT_RT; du += d_t * DT_RT
        cost += ((buy_p + extra_buy) * buy_price[t] + s_t * PEN_SHORT
                 + d_t * PEN_DUMP) * DT_RT
        dev += extra_buy * DT_RT
    return cost, sh, du, dev


def _make_figure(df, day_names):
    """图3: 左 = 执行成本 (三段断轴, 蓝~10^2元 vs 红~10^6元 跨4个量级), 右 = 失负荷 (线性)。"""
    arms = ['DA-only', 'DA-ID', 'DA-ID-RT']
    colors = ['#D62728', '#FF9D45', '#1F77B4']
    def _fmt(v):
        """柱顶数值标注: 大数压缩 (1.23M / 456k), 近零显式标 ≈0。"""
        if v >= 1e6: return f'{v / 1e6:.2f}M'
        if v >= 1e3: return f'{v / 1e3:.0f}k'
        return f'{v:.0f}' if v >= 1 else '≈0'

    def _col(arm, col):
        return [df[(df.day == d) & (df.arm == arm)][col].sum() for d in day_names]

    fig = plt.figure(figsize=(7.2, 3.7))
    gs = fig.add_gridspec(1, 2, wspace=0.24)
    gs_c = gs[0].subgridspec(3, 1, hspace=0.12)
    ax_c = [fig.add_subplot(gs_c[0])]
    ax_c += [fig.add_subplot(gs_c[i], sharex=ax_c[0]) for i in (1, 2)]
    ax_u = fig.add_subplot(gs[1])
    x = np.arange(len(day_names)); w = 0.24; off = 0.36   # 组内偏移>柱宽, 留出标注空隙

    # 成本断轴三段 (按数据定界): 下段容纳 DA-ID-RT, 中段红橙臂低值, 上段红臂高值。
    # 经典断轴样式: 每段画出全部柱 — 高柱被段顶裁切、矮柱低于段底不可见, 柱体贯穿连贯;
    # 数值标注只标在柱顶所在的那一段, 避免重复。
    cost = {a: _col(a, 'cost') for a in arms}
    rt_hi = max(cost['DA-ID-RT'])
    ro = [v for a in ('DA-only', 'DA-ID') for v in cost[a]]
    segs = [(0.0, rt_hi * 1.55),
            (min(ro) * 0.62, max(ro) * 0.60),
            (max(ro) * 0.55, max(ro) * 1.06)]
    # reversed(): segs 从小到大, 而 gs_c[0] 是画布最上面的面板 — 视觉上大值段应在顶部
    for k, (slo, shi) in enumerate(reversed(segs)):
        ax = ax_c[k]
        for j, (a, c) in enumerate(zip(arms, colors)):
            ax.bar(x + (j - 1) * off, cost[a], w, color=c)
            for xi, v in zip(x + (j - 1) * off, cost[a]):
                if slo <= v <= shi:
                    ax.annotate(_fmt(v), (xi, v), textcoords='offset points',
                                xytext=(0, 2), ha='center', fontsize=8.5)
        ax.set_ylim(slo, shi)
        ax.yaxis.set_major_locator(ticker.MaxNLocator(3, steps=[1, 2, 2.5, 5, 10]))
        ax.yaxis.set_major_formatter(ticker.FuncFormatter(
            lambda v, p: '0' if v == 0 else _fmt(v)))
        ax.set_xticks(x)
        ax.spines['bottom'].set_visible(k == 2)
        ax.spines['top'].set_visible(k == 0)
        ax.tick_params(direction='in',
                       bottom=(k == 2), labelbottom=(k == 2))
    ax_c[1].set_ylabel('Executed cost on RT actuals (CNY)')
    ax_c[2].set_xticklabels([f'Day {i+1}' for i in range(len(day_names))])
    # 断轴缺口斜线标记
    d = .5
    kw = dict(marker=[(-1, -d), (1, d)], markersize=11, linestyle='none',
              color='k', clip_on=False)
    for k in range(2):
        ax_c[k].plot([0, 1], [0, 0], transform=ax_c[k].transAxes, **kw)
        ax_c[k + 1].plot([0, 1], [1, 1], transform=ax_c[k + 1].transAxes, **kw)
    # 图例横排放到顶部面板上方, 避开段内柱顶标注
    ax_c[0].legend(handles=[Patch(facecolor=c, label=a) for a, c in zip(arms, colors)],
                   loc='lower left', bbox_to_anchor=(0, 1.02), ncol=3,
                   handlelength=1.4, columnspacing=1.4)

    # 右面板: 失负荷线性轴 (非零值 46~314 kWh 本就可读, ≈0 柱由标注说明)
    for j, (a, c) in enumerate(zip(arms, colors)):
        vals = _col(a, 'short_kwh')
        ax_u.bar(x + (j - 1) * off, vals, w, color=c)
        for xi, v in zip(x + (j - 1) * off, vals):
            ax_u.annotate(_fmt(v), (xi, v), textcoords='offset points',
                          xytext=(0, 2), ha='center', fontsize=8.5)
    ax_u.set_ylabel('Unserved energy (kWh)')
    ax_u.set_xticks(x)
    ax_u.set_xticklabels([f'Day {i+1}' for i in range(len(day_names))])
    ax_u.tick_params(direction='in')

    fig.tight_layout()
    fig.savefig('论文图片/图3_实验2_多时间尺度执行对比.png', dpi=300, bbox_inches='tight')
    print('\n已保存: 论文图片/图3_实验2_多时间尺度执行对比.png')

    # ---- 对数轴版本 (另存, 与断轴版并存): 单轴即可覆盖 5 个量级, 无需断轴 ----
    fig2 = plt.figure(figsize=(7.2, 3.2))
    gs2 = fig2.add_gridspec(1, 2, wspace=0.24)
    ax_l = fig2.add_subplot(gs2[0])
    ax_r2 = fig2.add_subplot(gs2[1])
    for j, (a, c) in enumerate(zip(arms, colors)):
        vals_s = _col(a, 'short_kwh')
        ax_l.bar(x + (j - 1) * off, cost[a], w, color=c)
        ax_r2.bar(x + (j - 1) * off, vals_s, w, color=c)
        for xi, v in zip(x + (j - 1) * off, cost[a]):
            ax_l.annotate(_fmt(v), (xi, v), textcoords='offset points',
                          xytext=(0, 2), ha='center', fontsize=8.5)
        for xi, v in zip(x + (j - 1) * off, vals_s):
            ax_r2.annotate(_fmt(v), (xi, v), textcoords='offset points',
                           xytext=(0, 2), ha='center', fontsize=8.5)
    ax_l.set_yscale('log')
    ax_l.set_ylim(50, 6e6)   # 下限 50: 最低蓝柱 108 落在线内且有基线
    ax_l.yaxis.set_major_locator(ticker.LogLocator(base=10, numticks=6))
    ax_l.yaxis.set_major_formatter(ticker.FuncFormatter(
        lambda v, p: _fmt(v) if v >= 1 else ''))
    ax_l.set_ylabel('Executed cost on RT actuals (CNY)')
    ax_l.set_xticks(x)
    ax_l.set_xticklabels([f'Day {i+1}' for i in range(len(day_names))])
    ax_l.tick_params(direction='in', which='both')
    ax_l.legend(handles=[Patch(facecolor=c, label=a) for a, c in zip(arms, colors)],
                loc='lower left', bbox_to_anchor=(0, 1.02), ncol=3,
                handlelength=1.4, columnspacing=1.4)
    ax_r2.set_ylabel('Unserved energy (kWh)')
    ax_r2.set_xticks(x)
    ax_r2.set_xticklabels([f'Day {i+1}' for i in range(len(day_names))])
    ax_r2.tick_params(direction='in')
    fig2.tight_layout()
    fig2.savefig('论文图片/图3_实验2_多时间尺度执行对比_对数轴.png',
                 dpi=300, bbox_inches='tight')
    print('已保存: 论文图片/图3_实验2_多时间尺度执行对比_对数轴.png (对数轴版)')


def main():
    if '--replot' in sys.argv:   # 不重跑仿真, 直接用已有 _paper_exp2_table.csv 出图
        df = pd.read_csv('_paper_exp2_table.csv', encoding='utf-8-sig')
        _make_figure(df, list(dict.fromkeys(df['day'])))
        return
    contract = joblib.load('ies_forecast_contract_eui.pkl')
    pv, bat, tank = knee_from_exp1()
    print(f'拐点容量 (实验1 TOPSIS): PV={pv:.0f} kW, Bat={bat:.0f} kWh, Tank={tank:.0f} kWh')
    ashp_el = milp_ashp_kw(contract, pv, bat, tank)
    print(f'MILP 推导 ASHP 电装机: {ashp_el:.0f} kW (电功率口径, COP_H=4.18/COP_C=5.45 共享, 热/冷可同供)')

    rows = []
    day_names = list(contract['typical_days'].keys())
    for day_idx, d_name in enumerate(day_names):
        print(f'\n===== 典型日 {day_idx + 1}/4: {d_name} =====')
        # ⚠️ 引擎 load_ID(3%)/load_RT(8%) 噪声取自全局 np.random (multi_scale_engine:82,86
        #    未播种), 不锁种子则每次运行图表数字漂移 ~±2%。逐典型日固定种子保证可复现。
        np.random.seed(42 + day_idx)
        cfg = make_config(contract, day_idx, pv, bat, tank, ashp_el)
        disp = MultiScaleDispatcher(cfg)
        da_res, id_res, rt_res = run_multiscale(disp)
        pv_cap = pv
        idx_maps = {'DA-only': np.arange(T_RT) // 12,
                    'DA-ID': np.arange(T_RT) // 3,
                    'DA-ID-RT': np.arange(T_RT)}
        for label, plan in [('DA-only', da_res), ('DA-ID', id_res), ('DA-ID-RT', rt_res)]:
            cost, sh, du, dev = execute_on_rt(plan, disp, pv_cap, idx_maps[label])
            rows.append(dict(day=d_name, arm=label, cost=cost, short_kwh=sh,
                             dump_kwh=du, deviation_kwh=dev))
            print(f'  [{label:8s}] RT执行成本 {cost:>10,.0f} ¥ | 失负荷 {sh:>8.1f} kWh | '
                  f'弃能 {du:>8.1f} kWh | 购电偏差 {dev:>9.1f} kWh')

    df = pd.DataFrame(rows)
    df.to_csv('_paper_exp2_table.csv', index=False, encoding='utf-8-sig')
    _make_figure(df, day_names)
    print('\n汇总 (四典型日合计):')
    print(df.groupby('arm')[['cost', 'short_kwh', 'dump_kwh', 'deviation_kwh']].sum().to_string())


if __name__ == '__main__':
    main()
