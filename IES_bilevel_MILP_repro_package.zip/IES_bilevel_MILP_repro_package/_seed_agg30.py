# -*- coding: utf-8 -*-
"""30 种子 (42..71) 稳健性汇总 — _paper_seed_agg.py 的 30 种子版。
输出写新文件 _paper_exp1_seeds_agg30.csv, 不动论文现有数据。"""
import sys
import json
import pandas as pd
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SEEDS = list(range(42, 72))          # 30 个种子
OUT = '_paper_exp1_seeds_agg30.csv'


def dominated_frac(fa, fb):
    hit = 0
    for a in fa:
        if any(all(mb <= ma for mb, ma in zip(b, a)) and
               any(mb < ma for mb, ma in zip(b, a)) for b in fb):
            hit += 1
    return hit / max(len(fa), 1)


def main():
    rows = []
    for s in SEEDS:
        tag = '' if s == 42 else f'_{s}'
        try:
            df = pd.read_csv(f'_paper_exp1_fronts{tag}.csv', encoding='utf-8-sig')
        except FileNotFoundError:
            print(f'种子 {s}: 文件缺失, 跳过')
            continue
        r = df[df.arm == 'rule'][['TA', 'AC', 'TG']].values
        m = df[df.arm == 'milp'][['TA', 'AC', 'TG']].values
        rows.append(dict(seed=s, n_rule=len(r), n_milp=len(m),
                         frac_dom=dominated_frac(r, m) * 100,
                         ta_rule=r[:, 0].min(), ta_milp=m[:, 0].min(),
                         ac_rule=r[:, 1].min(), ac_milp=m[:, 1].min(),
                         tg_rule=r[:, 2].min(), tg_milp=m[:, 2].min()))
    df = pd.DataFrame(rows)
    df['TA改善%'] = (1 - df.ta_milp / df.ta_rule) * 100
    df['AC改善%'] = (1 - df.ac_milp / df.ac_rule) * 100
    df['TG改善%'] = (1 - df.tg_milp / df.tg_rule) * 100
    df['knee_PV'] = df['knee_Bat'] = df['knee_Tank'] = np.nan
    for s in SEEDS:
        tag = '' if s == 42 else f'_{s}'
        try:
            with open(f'_paper_exp1_knee{tag}.json', encoding='utf-8') as f:
                k = json.load(f)
            df.loc[df.seed == s, ['knee_PV', 'knee_Bat', 'knee_Tank']] = \
                [k['X_PV'], k['X_Bat'], k['X_Tank']]
        except FileNotFoundError:
            pass

    pd.set_option('display.width', 220)
    print(f'===== 30 种子稳健性汇总 (seeds {SEEDS[0]}..{SEEDS[-1]}, n={len(df)}) =====')
    cols = ['seed', 'n_rule', 'n_milp', 'frac_dom', 'TA改善%', 'AC改善%', 'TG改善%',
            'knee_PV', 'knee_Bat', 'knee_Tank']
    print(df[cols].round(2).to_string(index=False))

    print('\n===== 均值 ± 标准差 (30 种子) =====')
    for c in ['frac_dom', 'TA改善%', 'AC改善%', 'TG改善%']:
        print(f'{c}: {df[c].mean():.2f} ± {df[c].std():.2f}   '
              f'(min {df[c].min():.2f}, max {df[c].max():.2f})')
    print(f'膝点配置范围: PV {df.knee_PV.min():.0f}~{df.knee_PV.max():.0f}, '
          f'Bat {df.knee_Bat.min():.0f}~{df.knee_Bat.max():.0f}, '
          f'Tank {df.knee_Tank.min():.0f}~{df.knee_Tank.max():.0f} kW/kWh')

    df.to_csv(OUT, index=False, encoding='utf-8-sig')
    print(f'\n已保存: {OUT} (论文原 _paper_exp1_seeds_agg.csv 未动)')


if __name__ == '__main__':
    main()
