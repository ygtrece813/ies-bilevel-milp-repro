# Reproduction Guide for Reviewers

**Paper:** *Nested exact mixed-integer linear programming for optimal sizing of park-level integrated energy systems*

This guide walks you through verifying the paper's results with the accompanying code package. There are three tracks, in increasing depth:

| Track | Time | What you verify |
|---|---|---|
| **A. Quick check** | ~10 min | Environment works; the carbon-ablation experiment (Table 7) reproduces **bit-for-bit**; all figures re-render from the published data |
| **B. Full experiments** | ~30 h unattended | All Pareto fronts (30 seeds), the merged-front protocol (Sec. 5.4), multi-time-scale execution (Table 6), and the nine-scenario sensitivity (Table 9) |
| **C. From raw data** | Track B + data download | The BDG2 → ML reconstruction → EUI anchoring pipeline itself |

> The package was verified by extracting it into a clean directory and running every fast script end-to-end. Track A outputs matched the published data files byte-for-byte (MD5-identical CSVs), and the full MILP solve of Experiment 3 reproduced Table 7 exactly.

---

## Track A — Quick check (~10 min)

### A1. Install (once)

- Python ≥ 3.9, then:

```bash
pip install numpy pandas matplotlib scipy scikit-learn xgboost joblib pyomo pulp
```

- **CBC solver** on `PATH` (used by every MILP): e.g. `conda install -c conda-forge coincbc`, or download from the CoinOr website. Verify with `cbc -quit` (or `-exit` on Windows).

### A2. Bit-for-bit check of Experiment 3 (seconds)

```bash
python _paper_exp3_carbon.py
```

This solves three full MILP models (stepped carbon trading / flat carbon tax / no carbon price). Expected console output (key lines):

```
容量: PV=1104 kW | Bat=425 kWh | Tank=336 kWh | ASHP(电)=90 kW
TA=483,733 ...  碳排 368.0 t          (no carbon price)
stepped: 碳排 269.9 t (↓26.7%), TA 增量 +22,250, 减碳代价 227    (stepped CCT)
flat:    碳排 270.4 t (↓26.5%), TA 增量 +22,296, 减碳代价 228    (flat tax)
```

Then compare against the published data file:

- `_paper_exp3_table.csv` should be **identical** to `published_outputs/_paper_exp3_table.csv` (same bytes — this experiment is a pure MILP solve with no stochastic component).

This is the ablation of Section 5.3 / Table 7 / Fig. 8: the stepped mechanism delivers the paper's headline 26.7% emission reduction at 227 CNY/t marginal abatement cost.

### A3. Bit-for-bit check of the merged-front protocol (seconds)

```bash
python _paper_exp1_merge_fronts.py
python _paper_seed_agg.py
python _merge_fronts30.py
python _seed_agg30.py
```

Expected console line from the 30-seed merge command:

```
合并 TOPSIS 推荐: PV=1241 Bat=575 Tank=456 | TA=504,830 AC=249.9 TG=231,409
```

This is exactly the recommended compromise solution of Section 5.4 (PV 1241 kW / battery 575 kWh / tank 456 kWh, TA = 504,830 CNY), now computed over all 30 seeds (42–71). The 3-seed commands regenerate the original seeds-42/43/44 merged front (TOPSIS knee PV 1251 / Bat 670 / Tank 343), which remains shipped for reference. All regenerated files should again be byte-identical to their copies in `published_outputs/`.

### A4. Re-render the figures (seconds, no experiments needed)

```bash
python _paper_fig_pareto3d.py          # Fig. 6  (3D Pareto fronts, 100 vs 100 points)
python _paper_fig_pareto3d.py alice    # Fig. 9
python _paper_fig2d_replot.py          # Fig. 6  (2D projections)
python _paper_fig1.py                  # Fig. 5  (annual loads + typical days)
python _paper_exp3_carbon.py --fig-only        # Fig. 8
python _paper_exp3_carbon.py alice --fig-only  # Fig. 10
python _paper_draw_diagrams.py         # Figs. 1-4 (structure, framework, flowcharts)
```

All PNGs are written into `论文图片/`. File names are in Chinese (production artifacts); the mapping to paper figure numbers is given in `README.md`.

---

## Track B — Full experiments (unattended compute)

All commands run from the package root. Nothing needs editing.

| # | Command | Runtime* | Produces | Paper |
|---|---|---|---|---|
| 1 | `python _paper_exp1_compare.py 42` | ~80 min | `_paper_exp1_fronts.csv`, `_paper_exp1_knee.json`, `_paper_exp1_metrics.txt` | Sec. 5.1, Table 5, Fig. 6 |
| 2 | `python _paper_exp1_compare.py 43` / `44`, then `python _run_seeds30.py` | ~80 min each + ~17.5 h (batch, 2 workers, chunked resume) | `*_43.*`, `*_44.*`, `_paper_exp1_fronts_{45..71}.*` + knees/metrics | Sec. 5.4, Table 8 |
| 3 | `python _merge_fronts30.py` + `python _seed_agg30.py` | seconds | 30-seed merged front + knee, per-seed aggregation | Sec. 5.4 |
| 4 | `python _paper_exp2_multiscale.py` | ~10 min | `_paper_exp2_table.csv` | Sec. 5.2, Table 6, Fig. 7 |
| 5 | `python _paper_exp3_carbon.py alice` | seconds | `_paper_exp3_table_alice.csv` | Sec. 5.6, Table 11, Fig. 10 |
| 6 | `python _paper_exp1_compare.py 42 2000 alice` | ~80 min | `*_alice.*` | Sec. 5.6, Table 10, Fig. 9 |
| 7 | `python _paper_exp1_sens.py` | ~12 h (9 scenarios) | `_paper_exp1_sens_T*.csv`, `_paper_exp1_sens_metrics.csv` | Sec. 5.5, Table 9 |

\* on an ordinary desktop PC with CBC. Tip: `python _paper_exp1_sens.py --one` advances exactly one scenario per process invocation (memory-safe chunking for the long factorial run); `_paper_exp1_compare.py` also supports chunked generations with checkpoint resume via its 4th CLI argument (seed, tank bound, case tag, chunk size). `_run_seeds30.py` drives the full 45–71 batch automatically (2 workers, 25-generation chunks, idempotent — already-finished seeds are skipped, so it can simply be rerun after any interruption).

**Numbers to check when the runs finish:**

| Quantity | Expected (as published) |
|---|---|
| Seed-42 fronts: rule vs MILP best values | TA 655,544 vs 520,087 CNY; AC 290.3 vs 15.8 t; TG 268,754 vs 14,620 kWh |
| Front domination | 100% of rule-front points strictly dominated, both fronts fully separated |
| Multi-seed TA improvement (30 seeds, 42–71) | 22.3 ± 0.7% (range 20.5%–23.6%); AC and TG stable at 94.5 ± 0.1% |
| Merged front (30 seeds) | 3,000 points → 1,133 distinct → 152 nondominated (1–10 points per seed); TOPSIS knee PV 1241 / Bat 575 / Tank 456 (TA = 504,830 CNY, AC = 249.9 t) |
| Table 6 (open-loop execution) | Execution cost 7,698,854 → 3,711,953 → 73,389 CNY; unserved energy 769.7 → 371.1 → 7.2 kWh |
| Table 9 (9 scenarios) | Domination 100% everywhere; TA improvement 14.9%–25.7%; AC/TG improvement 94.2%–94.6% |
| Table 10 (Alice, seed 42) | TA 1,062,155 vs 917,842 (13.6%); AC 1,132.0 vs 524.7 t (53.6%) |

Every one of these numbers is also present in the shipped `published_outputs/` CSVs, so you can verify the reruns by direct file comparison (`fc`, `diff`, or MD5).

---

## Track C — From raw BDG2 data (optional)

The two contracts (`ies_forecast_contract_*.pkl`) and the reconstructed annual curves are included, so Tracks A/B never need the raw dataset. To regenerate them from source:

1. Download the public **Building Data Genome Project 2** dataset (CC BY 4.0): official repository `github.com/buds-lab/building-data-genome-project-2` (also mirrored on Kaggle). You need `metadata.csv`, `weather.csv`, and the meter files `electricity.csv`, `hotwater.csv`, `chilledwater.csv`.
2. Point `DATA_DIR` in `eui_harmonize.py` to that directory.
3. Main case (Essie): `python ies_load_forecast_bridge.py <dataset_dir> Fox_office_Essie --export`
4. Second case (Alice): `python _paper_case2_alice.py`

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `SolverFactory('cbc')` / solver not found | Install CBC and add it to `PATH`; check with `cbc -quit` |
| `FileNotFoundError: '_paper_exp1_*.csv'` | You are not in the package root — all scripts use paths relative to the package root |
| Figure looks wrong / font warnings | Times New Roman is expected (Windows/macOS has it; on Linux install `ttf-mscorefonts`); warnings are non-fatal |
| A long run was interrupted | Experiment 1 supports checkpoint resume (chunked generations, exit code 2 = unfinished); sensitivity runs resume from their incrementally updated CSVs — just rerun the same command |
| Chinese filenames garble in the console | Cosmetic only (console codepage); file contents and results are unaffected |

## Package manifest

- `*.py` (23) — paper pipeline + platform modules (see `README.md` for the full mapping)
- `ies_forecast_contract_*.pkl`, `ies_forecast_8760*.csv` — processed case data (included)
- `published_outputs/` — pristine copies of every data file behind the paper's figures and tables
- `README.md` — package overview and file mapping
- `data_availability_statement.txt` — the statement as submitted

Questions about the code or data are welcome via the correspondence author.
