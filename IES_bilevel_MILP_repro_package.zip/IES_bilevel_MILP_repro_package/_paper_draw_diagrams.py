# -*- coding: utf-8 -*-
"""
论文示意图绘制 (风格对齐 Wang et al. 2025 Energy, Fig.1 & Fig.6)
================================================================
1. 系统结构图   : 电/热/冷三彩色母线 + 设备方块跨接 + 储能回路 (仿 Fig.1)
2. 双层框架流程图: 外层NSGA-II + 内层可插拔评价器 圆角框图 (仿 Fig.6)
3. 多时间尺度示意图: DA/ID/RT 三级时间轴 + 滚动窗口 + 追踪罚
输出: 论文图片/系统结构图.png, 论文图片/双层框架流程图.png, 论文图片/多时间尺度调度示意图.png
"""
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import _paper_figstyle  # noqa: F401  (统一风格)

C_ELE, C_HEAT, C_COOL = '#4C72B0', '#DD8452', '#55A868'
C_BOX_F, C_BOX_E = 'white', '#333333'


def dev_box(ax, cx, cy, w, h, text, fs=10, fc='white', ec=None, bold=False,
            ls='-'):
    """带圆角设备方块 + 居中文字。"""
    ec = ec or C_BOX_E
    b = FancyBboxPatch((cx - w / 2, cy - h / 2), w, h,
                       boxstyle='round,pad=0.02,rounding_size=0.08',
                       fc=fc, ec=ec, lw=1.1, zorder=5, linestyle=ls)
    ax.add_patch(b)
    ax.text(cx, cy, text, ha='center', va='center', fontsize=fs, zorder=6,
            fontweight='bold' if bold else 'normal')
    return b


def arrow(ax, p0, p1, color, lw=2.2, ls='-', mut=14, zorder=4):
    a = FancyArrowPatch(p0, p1, arrowstyle='-|>', mutation_scale=mut,
                        color=color, lw=lw, linestyle=ls, zorder=zorder,
                        shrinkA=0, shrinkB=0)
    ax.add_patch(a)


def bus(ax, y, x0, x1, color, label):
    ax.plot([x0, x1], [y, y], color=color, lw=5, solid_capstyle='round',
            zorder=2, alpha=0.85)
    ax.text(x0 - 0.15, y - 0.22, label, ha='left', va='top', fontsize=11,
            color=color, fontweight='bold')


def draw_structure():
    """图: IES 系统结构 (电-热-冷三母线)。"""
    fig, ax = plt.subplots(figsize=(7.6, 5.2))
    ax.set_xlim(-0.6, 12.2)
    ax.set_ylim(-1.1, 8.4)
    ax.axis('off')

    yE, yH, yC = 6.4, 3.7, 1.3
    x0, x1 = 1.6, 11.0
    bus(ax, yE, x0, x1, C_ELE, 'Electricity bus')
    bus(ax, yH, x0, x1, C_HEAT, 'Heat bus')
    bus(ax, yC, x0, x1, C_COOL, 'Cooling bus')

    # ---- 电母线上排: 电网 / PV / 蓄电池(回路) / 电负荷 ----
    dev_box(ax, 2.2, 7.8, 1.5, 0.72, 'Electricity\ngrid')
    arrow(ax, (2.2, 7.44), (2.2, yE), C_ELE)
    dev_box(ax, 4.3, 7.8, 1.1, 0.72, 'PV')
    arrow(ax, (4.3, 7.44), (4.3, yE), C_ELE)
    # 蓄电池: 充(上)/放(下) 回路
    dev_box(ax, 7.6, 7.8, 1.9, 0.72, 'Battery\nstorage')
    arrow(ax, (7.25, yE), (7.25, 7.42), C_ELE)          # 充: 母线→电池
    arrow(ax, (7.95, 7.42), (7.95, yE), C_ELE)          # 放: 电池→母线
    dev_box(ax, 10.4, 7.8, 1.2, 0.72, 'Electrical\nload')
    arrow(ax, (10.4, yE), (10.4, 7.44), C_ELE)

    # ---- ASHP: 电母线取电 (左侧折线, 避免穿越热母线) → 热/冷母线 ----
    axh, xc = 2.45, 4.6
    dev_box(ax, xc, axh, 2.1, 0.85, 'ASHP\n(COP$_h$ / COP$_c$)')
    ax.plot([1.6, 1.15], [yE, yE], color=C_ELE, lw=2.2, zorder=3)
    ax.plot([1.15, 1.15], [yE, axh], color=C_ELE, lw=2.2, zorder=3)
    arrow(ax, (1.15, axh), (xc - 1.08, axh), C_ELE, lw=2.2)
    # 热输出 (橙, 上行) / 冷输出 (绿, 下行)
    arrow(ax, (xc - 0.75, axh + 0.46), (xc - 0.75, yH - 0.02), C_HEAT)
    arrow(ax, (xc + 0.75, axh - 0.46), (xc + 0.75, yC + 0.02), C_COOL)

    # ---- 热母线上排: 蓄热罐回路 + 热负荷 ----
    dev_box(ax, 8.2, 4.7, 1.9, 0.72, 'Thermal tank\n(heating mode)')
    arrow(ax, (7.85, yH), (7.85, 4.32), C_HEAT)
    arrow(ax, (8.55, 4.32), (8.55, yH), C_HEAT)
    dev_box(ax, 10.4, 4.7, 1.2, 0.72, 'Heat\nload')
    arrow(ax, (10.4, yH), (10.4, 4.32), C_HEAT)

    # ---- 冷母线下排: 蓄冷罐回路(虚线=季节切换) + 冷负荷 ----
    dev_box(ax, 8.2, 2.45, 1.9, 0.72, 'Thermal tank\n(cooling mode)', ls='--')
    arrow(ax, (7.85, yC), (7.85, 2.07), C_COOL)
    arrow(ax, (8.55, 2.07), (8.55, yC), C_COOL)
    dev_box(ax, 10.4, 0.15, 1.2, 0.72, 'Cooling\nload')
    arrow(ax, (10.4, yC), (10.4, 0.51), C_COOL)

    # 蓄能罐两模式虚线连接 (同一罐, 季节切换)
    ax.plot([9.17, 9.17], [2.83, 4.32], color='#888888', lw=1.2, ls=':', zorder=1)
    ax.text(9.35, 3.15, 'seasonal\nswitching', fontsize=8.8, color='#666666',
            ha='left', va='center', style='italic')

    # ---- 底部图例 ----
    lg_y = -0.75
    for i, (c, t) in enumerate([(C_ELE, 'Electricity'), (C_HEAT, 'Heat'),
                                (C_COOL, 'Cooling')]):
        xa = 3.6 + i * 2.2
        arrow(ax, (xa, lg_y), (xa + 0.9, lg_y), c, lw=3, mut=16)
        ax.text(xa + 1.1, lg_y, t, fontsize=11, va='center')

    fig.tight_layout(pad=0.3)
    fig.savefig('论文图片/系统结构图.png', dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('已保存: 论文图片/系统结构图.png')


def draw_flowchart():
    """图: 双层容量规划框架 (外层NSGA-II ⇄ 内层可插拔评价器)。"""
    fig, ax = plt.subplots(figsize=(7.6, 6.0))
    ax.set_xlim(-0.5, 12.5)
    ax.set_ylim(-1.95, 9)
    ax.axis('off')

    def big_box(x, y, w, h, fc, title):
        b = FancyBboxPatch((x, y), w, h,
                           boxstyle='round,pad=0.06,rounding_size=0.25',
                           fc=fc, ec='#999999', lw=1.2, alpha=0.35, zorder=1)
        ax.add_patch(b)
        ax.text(x + w / 2, y + h - 0.28, title, ha='center', va='center',
                fontsize=12, fontweight='bold', zorder=3)

    def sub_box(x, y, w, h, head, body, fs=9.6):
        b = FancyBboxPatch((x, y), w, h,
                           boxstyle='round,pad=0.04,rounding_size=0.12',
                           fc='white', ec='#777777', lw=1.0, zorder=3)
        ax.add_patch(b)
        ax.text(x + w / 2, y + h - 0.26, head, ha='center', va='center',
                fontsize=fs + 0.4, fontweight='bold', zorder=4)
        ax.text(x + w / 2, y + (h - 0.6) / 2, body, ha='center', va='center',
                fontsize=fs, zorder=4, linespacing=1.5)

    # ---- 外层 (黄) ----
    big_box(1.0, 6.15, 10.0, 2.55, '#F0C24B', 'Outer layer: capacity optimization (NSGA-II)')
    sub_box(1.45, 6.55, 2.9, 1.6, 'Objectives',
            'min [TA, AC, TG]\nannual cost / carbon /\ngrid interaction')
    sub_box(4.55, 6.55, 3.0, 1.6, 'Variables',
            '$C_{PV}$, $C_{bat}$, $C_{tank}$\n$\in$ [0, 2000] kW (kWh)')
    sub_box(7.75, 6.55, 2.85, 1.6, 'Operators',
            'SBX crossover / polynomial\nmutation; nondominated sort\n+ crowding distance')

    # ---- 内层 (绿) ----
    big_box(1.0, 0.45, 10.0, 3.6, '#7FBF7F',
            'Inner layer: operational evaluation (pluggable)')
    sub_box(1.45, 0.85, 4.55, 2.5,
            'Evaluator A: nested exact MILP (proposed)',
            'Objective: TA = CRF·Inv + Maint + Op + CCT\n'
            'Constraints: device limits, bus balance,\n'
            'daily-cyclic storage, stepped CCT (LP)\n'
            'CBC solver, ~0.16 s per evaluation',
            fs=9.2)
    sub_box(6.35, 0.85, 4.25, 2.5,
            'Evaluator B: fixed TOU rules (baseline)',
            'Valley-charge / peak-discharge rules;\n'
            'thermal side first, then electrical;\n'
            'pure simulation (no optimization)\n'
            'numpy loop, ~0.5 ms per evaluation',
            fs=9.2)

    # ---- 环形箭头 (左: 候选容量向下; 右: 目标向量向上) ----
    a1 = FancyArrowPatch((0.72, 6.35), (0.72, 3.85), arrowstyle='-|>',
                         mutation_scale=22, color='#B8860B', lw=2.6,
                         connectionstyle='arc3,rad=0.45', zorder=2)
    a2 = FancyArrowPatch((11.28, 3.85), (11.28, 6.35), arrowstyle='-|>',
                         mutation_scale=22, color='#2E7D32', lw=2.6,
                         connectionstyle='arc3,rad=0.45', zorder=2)
    ax.add_patch(a1); ax.add_patch(a2)
    # 标签置于弧线最凸点外侧 (rad=0.45 时凸点 x≈0.16/11.84), 避免与箭头重叠
    ax.text(-0.25, 5.1, 'candidate capacity $\\mathbf{x}$', fontsize=10,
            ha='center', va='center', rotation=90, color='#B8860B')
    ax.text(12.25, 5.1, 'objective vector $[TA, AC, TG]$', fontsize=10,
            ha='center', va='center', rotation=270, color='#2E7D32')

    # ---- 底部延伸: TOPSIS + 多时间尺度 ----
    dev_box(ax, 6.0, -1.1, 5.4, 0.8,
            'TOPSIS knee selection  $\\rightarrow$  recommended capacity',
            fs=10.5, fc='#EDF3FB')
    arrow(ax, (6.0, 0.38), (6.0, -0.68), '#555555', lw=2.0)

    fig.tight_layout(pad=0.3)
    fig.savefig('论文图片/双层框架流程图.png', dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('已保存: 论文图片/双层框架流程图.png')


def draw_multiscale():
    """图: DA-ID-RT 多时间尺度滚动调度示意。"""
    fig, ax = plt.subplots(figsize=(8.6, 3.9))
    ax.set_xlim(0, 13.6)
    ax.set_ylim(-0.8, 4.6)
    ax.axis('off')

    rows = [
        (3.6, 'DA (day-ahead)', 24, '#4C72B0', '1 h'),
        (2.1, 'ID (intra-day)', 96, '#DD8452', '15 min'),
        (0.6, 'RT (real-time)', 288, '#55A868', '5 min'),
    ]
    xL, xR = 2.6, 11.6
    for y, name, n, c, dt in rows:
        w = (xR - xL) / n
        for i in range(n):
            ax.add_patch(plt.Rectangle((xL + i * w, y - 0.28), w * 0.92, 0.56,
                                       fc=c, ec='white', lw=0.2, alpha=0.75))
        ax.text(xL - 0.25, y, f'{name}\n({dt} per step)', ha='right',
                va='center', fontsize=9)
        ax.text(xR + 0.25, y, f'{n} steps', ha='left', va='center',
                fontsize=8.5, color='#555555')

    # 滚动窗口高亮 (ID & RT)
    for y, n, span, c in [(2.1, 96, 16, '#B45309'), (0.6, 288, 3, '#B45309')]:
        w = (xR - xL) / n
        ax.add_patch(plt.Rectangle((xL + 30 * w, y - 0.34), span * w, 0.68,
                                   fc='none', ec=c, lw=1.8, zorder=6))
    ax.text(xL + 38 * (xR - xL) / 96, 1.5, 'rolling window (4 h)',
            fontsize=7.5, ha='center', color='#B45309')
    ax.text(xL + 31.5 * (xR - xL) / 288, 0.0, 'window (15 min)',
            fontsize=7.5, ha='center', color='#B45309')

    # 追踪罚箭头 (垂直, 上→下)
    arrow(ax, (12.5, 3.32), (12.5, 2.38), '#B45309', lw=1.8, mut=13)
    ax.text(12.68, 2.85, 'tracking\npenalty', fontsize=7.5, color='#B45309',
            va='center')
    arrow(ax, (12.5, 1.82), (12.5, 0.88), '#B45309', lw=1.8, mut=13)
    ax.text(12.68, 1.35, 'tracking\npenalty', fontsize=7.5, color='#B45309',
            va='center')

    # 预测扰动标注
    for y, t in [(3.6, 'forecast (clean)'), (2.1, 'forecast + 3% noise'),
                 (0.6, 'actual + 8% noise')]:
        ax.text((xL + xR) / 2, y + 0.44, t, ha='center', fontsize=7.5,
                color='#444444', style='italic')

    # 底部: 开环执行
    arrow(ax, (7.0, 0.28), (7.0, -0.42), '#333333', lw=1.8, mut=13)
    ax.text(7.0, -0.62, 'open-loop execution of plans on RT actuals '
            '(unserved-energy settling)', fontsize=8.5, ha='center',
            va='center')

    fig.tight_layout(pad=0.3)
    fig.savefig('论文图片/多时间尺度调度示意图.png', dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('已保存: 论文图片/多时间尺度调度示意图.png')


if __name__ == '__main__':
    draw_structure()
    draw_flowchart()
    draw_multiscale()
