import pulp


class EnergyBus:
    def __init__(self, name):
        self.name = name
        self.inputs = []
        self.outputs = []

    def connect_input(self, var_list):
        self.inputs.append(var_list)

    def connect_output(self, var_list):
        self.outputs.append(var_list)

    def build_balance_constraints(self, model, T):
        # 💡 核心修复：引入虚拟松弛变量，绝对保证数学有解 (Infeasible 终结者)
        self.dump_vars = [pulp.LpVariable(f"Dump_{self.name}_{t}", lowBound=0) for t in range(T)]
        self.short_vars = [pulp.LpVariable(f"Short_{self.name}_{t}", lowBound=0) for t in range(T)]

        for t in range(T):
            sum_in = pulp.lpSum([var_list[t] for var_list in self.inputs])
            sum_out = pulp.lpSum([var_list[t] for var_list in self.outputs])

            # 严格平衡：总输入 + 虚拟缺额 = 总输出 + 虚拟弃能
            model += (sum_in + self.short_vars[t] == sum_out + self.dump_vars[t], f"Bus_Balance_{self.name}_t{t}")