"""
IES 通用系统 — 三场景集中参数配置
修改设备参数和上下限只需编辑对应场景 section
"""

SCENARIO_PARAMS = {

    # ==========================================
    # 场景1: Microgrid (光伏+电池+热泵+冷热组合储罐)
    # ==========================================
    "Microgrid": {
        "economic": {
            "interest_rate": 0.05,
            "project_life": 20,
            "carbon_tax": 301,
            "carbon_factor_grid": 1.298,
            "carbon_factor_gas": 1.96,
        },
        "device_costs": {
            "Roof_PV":           3528, #按功率
            "Battery_Array":     1100,
            "Main_ASHP":         2170,
            "Thermal_Tank":       160,
        },
        "maintenance_rates": {
            "Roof_PV":          0.0235,
            "Battery_Array":    0.0189,
            "Main_ASHP":        0.0175,
            "Thermal_Tank":     0.0130,
        },
        "capacity_bounds": {
            "Roof_PV":          [0, 2072],
            "Battery_Array":    [0, 10000],
            "Main_ASHP":        [0, 5000],
            "Thermal_Tank":     [0, 3000],
        },
        "storage_params": {
            "Battery_Array":    {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.10, "loss_rate": 0.000, "eta_ch": 0.95, "eta_dis": 0.95},
            "Thermal_Tank":     {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.10, "loss_rate": 0.001, "eta_ch": 0.98, "eta_dis": 0.98, "tou_mode": False},
        },
        "fuel_prices": {"gas": 3.395},
    },

    # ==========================================
    # 场景2: Hainan (光伏+电池+燃气发电机+溴化锂+电制冷+蓄冷罐)
    # ==========================================
    "Hainan": {
        "economic": {
            "interest_rate": 0.08,
            "project_life": 30,
            "carbon_tax": 50,
            "carbon_factor_grid": 1.298,
            "carbon_factor_gas": 0.2,
        },
        "device_costs": {
            "Roof_PV":          3000,
            "Battery_Array":      500,
            "Gas_CHP":           8000,
            "Abs_Chiller":       6000,
            "Elec_Chiller":      4000,
            "Thermal_Tank":      1200,
        },
        "maintenance_rates": {
            "Roof_PV":          0.015,
            "Battery_Array":    0.035,
            "Gas_CHP":          0.030,
            "Abs_Chiller":      0.025,
            "Elec_Chiller":     0.020,
            "Thermal_Tank":     0.020,
        },
        "capacity_bounds": {
            "Roof_PV":          [2000, 30000],
            "Battery_Array":    [500, 15000],
            "Gas_CHP":          [1000, 8000],
            "Abs_Chiller":      [2000, 8000],
            "Elec_Chiller":     [500, 10000],
            "Thermal_Tank":     [3000, 20000],
        },
        "storage_params": {
            "Battery_Array":    {"charge_rate": 0.5, "discharge_rate": 0.5, "max_soc": 0.95, "min_soc": 0.10, "loss_rate": 0.0, "eta_ch": 0.95, "eta_dis": 0.95},
            "Thermal_Tank":     {"charge_rate": 0.3, "discharge_rate": 0.3, "max_soc": 0.95, "min_soc": 0.20, "loss_rate": 0.001, "eta_ch": 0.99, "eta_dis": 0.99},
        },
        "replacements": {
            "Roof_PV":          25,
            "Battery_Array":    10,
            "Gas_CHP":          20,
            "Abs_Chiller":      20,
            "Elec_Chiller":     15,
            "Thermal_Tank":     15,
        },
        "fuel_prices": {"gas": 2.0},
    },

    # ==========================================
    # 场景3: Hydrogen (风电+光伏+GT+GB+EL+HFC+MR+电池+热罐+氢罐+气罐)
    # ==========================================
    "Hydrogen": {
        "economic": {
            "interest_rate": 0.05,
            "project_life": 20,
            "carbon_tax": 250,  # 论文里的基础碳价 250
            "carbon_factor_grid": 1.08,  # Table 1 购买电力的碳配额系数 1.08
            "carbon_factor_gas": 0.195,  # Table 1 GT/GB 产热对应的实际碳配额系数 0.195
        },
        "device_costs": {
            # Table 2 真实投资成本 (¥/kW 或 ¥/kWh 或 ¥/kg)
            "Roof_PV": 3528, "Wind_Farm": 4500, "Battery_Array": 1100,
            "Gas_CHP": 1500,        # Table 2: GT 1500 ¥/kW
            "Gas_Boiler": 800,      # Table 2: GB 800 ¥/kW
            "Electrolyzer": 2500,   # Table 2: EL 2500 ¥/kW
            "HydrogenFuelCell": 5000,  # Table 2: HFC 5000 ¥/kW
            "MethanationReactor": 3000,  # Table 2: MR 3000 ¥/kW
            "Heat_Tank": 160, "Hydrogen_Tank": 1200, "Gas_Tank": 800,
            "WHB": 400             # Table 2: WHB 400 ¥/kW
        },
        "maintenance_rates": {  # 严格对应 Table 1 & 2 (单位: ¥/MWh 功率型; ¥/kg 质量型)
            "Roof_PV": 0.032,
            "Wind_Farm": 0.070,
            "Battery_Array": 0.018,
            "Gas_CHP": 0.0125,       # GT 运维: 12.5 ¥/MWh
            "Gas_Boiler": 0.085,     # GB 运维: 85 ¥/MWh
            "Electrolyzer": 0.025,
            "HydrogenFuelCell": 0.018,
            "MethanationReactor": 0.019,
            "Heat_Tank": 0.016,
            "Hydrogen_Tank": 16.0,  # 16 ¥/kg 氢储能
            "Gas_Tank": 0.016,      # 16 ¥/MWh
            "WHB": 0.065,           # 65 ¥/MWh
        },
        "capacity_bounds": {  # 严格对应 Table 1 & 2 的物理极限
            "Roof_PV": [45000, 45000],  # 强制固定 (论文隐含~45MW峰值)
            "Wind_Farm": [60000, 60000],  # 强制固定 (论文隐含~60MW峰值)
            "Battery_Array": [180000, 180000],  # 强制固定 (Table2: 180MWh)
            "Heat_Tank": [180000, 180000],  # 强制固定 (Table2: 180MWh)
            "Hydrogen_Tank": [900, 900],  # 强制固定 (Table2: 900kg)
            "Gas_Tank": [90000, 90000],  # 强制固定 (Table2: 90MWh)
            "Gas_CHP": [0, 580000],  # 580 MW
            "Gas_Boiler": [0, 1000000],  # 1000 MW
            "Electrolyzer": [0, 100000],  # 100 MW
            "HydrogenFuelCell": [0, 25],  # 25 kg/h (视底层单位调整)
            "MethanationReactor": [0, 2000],  # 1000 kg/h
            "WHB": [0, 150000],
        },
        "storage_params": {  # 充放电倍率从论文P_max/Cap反推为1/3, 此处保守用0.2
            "Battery_Array": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 1.0, "min_soc": 0.222,
                              "loss_rate": 0.0, "eta_ch": 0.95, "eta_dis": 0.95},
            "Heat_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 1.0, "min_soc": 0.222, "loss_rate": 0.0,
                          "eta_ch": 0.95, "eta_dis": 0.95},
            "Hydrogen_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 1.0, "min_soc": 0.222,
                              "loss_rate": 0.0, "eta_ch": 0.95, "eta_dis": 0.95},
            "Gas_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 1.0, "min_soc": 0.222, "loss_rate": 0.0,
                         "eta_ch": 0.95, "eta_dis": 0.95},
        },
        "fuel_prices": {"gas": 3.395, "h2": 59.31},  # 气和氢价格保持
    },
}

# ================================================================
# 通用默认值 (兜底用)
# ================================================================
DEFAULT_PARAMS = {
    "economic": {"interest_rate": 0.05, "project_life": 20, "carbon_tax": 301, "carbon_factor_grid": 1.298, "carbon_factor_gas": 1.96},
    "device_costs": {"Roof_PV": 3000, "Wind_Farm": 4500, "Battery_Array": 1100, "Main_ASHP": 2170, "Gas_CHP": 4000, "Elec_Boiler": 500, "Gas_Boiler": 400, "Elec_Chiller": 800, "Abs_Chiller": 1200, "Thermal_Tank": 160, "Cool_Tank": 160, "Heat_Tank": 160, "Hydrogen_Tank": 1200, "Gas_Tank": 800, "Electrolyzer": 2500, "HydrogenFuelCell": 5000, "PVT_Collector": 3500, "MethanationReactor": 3000, "Ground_Source_HP": 4500},
    "maintenance_rates": {"Roof_PV": 0.0235, "Wind_Farm": 0.02, "Battery_Array": 0.0189, "Main_ASHP": 0.0175, "Gas_CHP": 0.02, "Elec_Boiler": 0.015, "Gas_Boiler": 0.015, "Elec_Chiller": 0.015, "Abs_Chiller": 0.015, "Thermal_Tank": 0.013, "Cool_Tank": 0.013, "Heat_Tank": 0.013, "Hydrogen_Tank": 0.01, "Gas_Tank": 0.01, "Electrolyzer": 0.02, "HydrogenFuelCell": 0.03, "PVT_Collector": 0.02, "MethanationReactor": 0.02, "Ground_Source_HP": 0.015, "WHB": 0.065},
    "capacity_bounds": {"Roof_PV": [0, 2000], "Wind_Farm": [0, 100000], "Battery_Array": [0, 2000], "Main_ASHP": [0, 2000], "Gas_CHP": [500, 20000], "Elec_Boiler": [0, 10000], "Gas_Boiler": [0, 20000], "Elec_Chiller": [0, 10000], "Abs_Chiller": [0, 10000], "Thermal_Tank": [0, 2000], "Cool_Tank": [0, 2000], "Heat_Tank": [0, 10000], "Hydrogen_Tank": [0, 5000], "Gas_Tank": [0, 15000], "Electrolyzer": [0, 10000], "HydrogenFuelCell": [0, 8000], "PVT_Collector": [0, 80000], "MethanationReactor": [0, 5000], "Ground_Source_HP": [0, 10000]},
    "storage_params": {"Battery_Array": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.1, "loss_rate": 0, "eta_ch": 0.95, "eta_dis": 0.95}, "Thermal_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.1, "loss_rate": 0.001, "eta_ch": 0.98, "eta_dis": 0.98}, "Cool_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.1, "loss_rate": 0.001, "eta_ch": 0.98, "eta_dis": 0.98}, "Heat_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.1, "loss_rate": 0.002, "eta_ch": 0.98, "eta_dis": 0.98}, "Hydrogen_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.1, "loss_rate": 0.001, "eta_ch": 0.99, "eta_dis": 0.99}, "Gas_Tank": {"charge_rate": 0.2, "discharge_rate": 0.2, "max_soc": 0.95, "min_soc": 0.1, "loss_rate": 0.001, "eta_ch": 0.99, "eta_dis": 0.99}},
    "battery_aging": 0.0,
    "grid_limit": 50000,
    # 零失负荷硬约束模式: 列入名单的母线其 Short(缺额) 变量上界锁定为 0,
    # 优化器必须 100% 满足该母线负荷 (不可行时模型无解, 由调用方回退).
    # 例: ["ElectricityBus", "HeatBus", "CoolBus"]; 空列表 = 默认天价惩罚软约束
    "no_shortage_buses": [],
    # 💡 dump 弃能罚价 0.5 ¥/kWh: 压过 PV 度电成本(3528×CRF0.0802/1200h≈0.26+运维0.024),
    #    否则碳目标会奖励"狂建光伏→白天全弃电"的虚假解 (实测 PV 超建 5606kW vs 负荷 300kW)
    "penalty": {"shortage": 10000, "dump": 0.5},
    "objective_weights": {"cost": 1.0, "carbon": 1.0, "grid": 1.0},
    "replacements": {},
    "fuel_prices": {"gas": 3.395, "h2": 59.31},
}


def merge_params(user_params, scenario=None):
    import copy
    merged = copy.deepcopy(DEFAULT_PARAMS)
    if scenario and scenario in SCENARIO_PARAMS:
        overrides = SCENARIO_PARAMS[scenario]
        for section in overrides:
            if section in merged and isinstance(merged[section], dict):
                merged[section].update(overrides[section])
    for section in merged:
        if section in user_params:
            if isinstance(merged[section], dict) and isinstance(user_params[section], dict):
                merged[section].update(user_params[section])
            else:
                merged[section] = user_params[section]
    return merged
