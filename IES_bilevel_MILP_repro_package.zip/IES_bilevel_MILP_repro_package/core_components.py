import pulp

class BaseComponent:
    def __init__(self, name):
        self.name = name
        self.vars = {}
    def build_variables(self, T): raise NotImplementedError
    def build_constraints(self, model, T, dt): raise NotImplementedError

class RenewableSource(BaseComponent):
    def __init__(self, name, capacity, profile_1kw):
        super().__init__(name)
        self.capacity = capacity
        self.profile_1kw = profile_1kw
    def build_variables(self, T):
        self.vars['P_out'] = [pulp.LpVariable(f"{self.name}_P_out_{t}", 0) for t in range(T)]
        self.vars['P_cut'] = [pulp.LpVariable(f"{self.name}_P_cut_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['P_out'][t] + self.vars['P_cut'][t] == self.capacity * self.profile_1kw[t])

class SolarThermalCollector(BaseComponent):
    def __init__(self, name, area, efficiency_profile):
        super().__init__(name)
        self.area = area
        self.eff_profile = efficiency_profile
    def build_variables(self, T):
        self.vars['Q_out'] = [pulp.LpVariable(f"{self.name}_Q_out_{t}", 0, self.area * self.eff_profile[t]) for t in range(T)]
    def build_constraints(self, model, T, dt): pass

class PowerGrid(BaseComponent):
    def __init__(self, name, p_max=1000000, buy_price=0.5, p_sell_max=0):
        super().__init__(name)
        self.p_max = p_max; self.p_sell_max = p_sell_max; self.buy_price = buy_price
    def build_variables(self, T):
        self.vars['P_buy'] = [pulp.LpVariable(f"{self.name}_P_buy_{t}", 0, self.p_max) for t in range(T)]
        self.vars['P_sell'] = [pulp.LpVariable(f"{self.name}_P_sell_{t}", 0, self.p_sell_max) for t in range(T)]
    def build_constraints(self, model, T, dt): pass

class GasNetwork(BaseComponent):
    def __init__(self, name, max_flow=1000000, gas_price=3.395): # 💡 修正气价防套利
        super().__init__(name)
        self.max_flow = max_flow; self.gas_price = gas_price
    def build_variables(self, T):
        self.vars['Gas_buy'] = [pulp.LpVariable(f"{self.name}_Gas_buy_{t}", 0, self.max_flow) for t in range(T)]
    def build_constraints(self, model, T, dt): pass

# 💡 新增：外部购氢网络
class HydrogenNetwork(BaseComponent):
    def __init__(self, name, max_flow=1000000, h2_price=59.31): # 💡 修正氢价防套利
        super().__init__(name)
        self.max_flow = max_flow; self.h2_price = h2_price
    def build_variables(self, T):
        self.vars['H2_buy'] = [pulp.LpVariable(f"{self.name}_H2_buy_{t}", 0, self.max_flow) for t in range(T)]
    def build_constraints(self, model, T, dt): pass

class EnergyLoad(BaseComponent):
    def __init__(self, name, load_profile):
        super().__init__(name)
        self.load_profile = load_profile
    def build_variables(self, T):
        self.vars['P_demand'] = [pulp.LpVariable(f"{self.name}_Demand_{t}", self.load_profile[t], self.load_profile[t]) for t in range(T)]
    def build_constraints(self, model, T, dt): pass

class AirSourceHeatPump(BaseComponent):
    # ⚠️ 与规划层 (milp_capacity_engine) 及论文 Eq.5-6 严格对齐: 电容量共享, 热/冷可同供.
    # 旧版逐小时 Mode_H+Mode_C<=1 互斥二进制会导致过渡季"供热小时冷负荷必然失负荷",
    # 且让 DA/ID/RT 窗口引入无谓整数变量拖慢求解. 现仅以耗电耦合式 + 电功率上限约束.
    def __init__(self, name, p_max, COP_H=3.0, COP_C=3.0):
        super().__init__(name)
        self.p_max = p_max; self.COP_H = COP_H; self.COP_C = COP_C
    def build_variables(self, T):
        self.vars['P_elec_in'] = [pulp.LpVariable(f"{self.name}_ElecIn_{t}", 0) for t in range(T)]
        self.vars['Q_heat_out'] = [pulp.LpVariable(f"{self.name}_HeatOut_{t}", 0) for t in range(T)]
        self.vars['Q_cool_out'] = [pulp.LpVariable(f"{self.name}_CoolOut_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['P_elec_in'][t] <= self.p_max)
            model += (self.vars['P_elec_in'][t] == self.vars['Q_heat_out'][t] / self.COP_H + self.vars['Q_cool_out'][t] / self.COP_C)

class GasGenerator_CHP(BaseComponent):
    def __init__(self, name, p_max, eta_e=0.35, eta_h=0.45, gas_lhv=9.7):
        super().__init__(name)
        self.p_max = p_max; self.eta_e = eta_e; self.eta_h = eta_h; self.lhv = gas_lhv
    def build_variables(self, T):
        self.vars['P_elec_out'] = [pulp.LpVariable(f"{self.name}_ElecOut_{t}", 0, self.p_max) for t in range(T)]
        self.vars['V_gas_in'] = [pulp.LpVariable(f"{self.name}_GasIn_{t}", 0) for t in range(T)]
        self.vars['Q_heat_out'] = [pulp.LpVariable(f"{self.name}_HeatOut_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['P_elec_out'][t] == self.vars['V_gas_in'][t] * self.lhv * self.eta_e)
            model += (self.vars['Q_heat_out'][t] == self.vars['V_gas_in'][t] * self.lhv * self.eta_h)

class ElectricBoiler(BaseComponent):
    def __init__(self, name, p_max, eta_h=0.95):
        super().__init__(name)
        self.p_max = p_max; self.eta_h = eta_h
    def build_variables(self, T):
        self.vars['P_elec_in'] = [pulp.LpVariable(f"{self.name}_ElecIn_{t}", 0, self.p_max) for t in range(T)]
        self.vars['Q_heat_out'] = [pulp.LpVariable(f"{self.name}_HeatOut_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['Q_heat_out'][t] == self.vars['P_elec_in'][t] * self.eta_h)

class GasBoiler(BaseComponent):
    def __init__(self, name, q_max, eta_h=0.75, gas_lhv=9.7):
        super().__init__(name)
        self.q_max = q_max; self.eta_h = eta_h; self.lhv = gas_lhv
    def build_variables(self, T):
        self.vars['Q_heat_out'] = [pulp.LpVariable(f"{self.name}_HeatOut_{t}", 0, self.q_max) for t in range(T)]
        self.vars['V_gas_in'] = [pulp.LpVariable(f"{self.name}_GasIn_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['Q_heat_out'][t] == self.vars['V_gas_in'][t] * self.lhv * self.eta_h)

class ElectricChiller(BaseComponent):
    def __init__(self, name, q_max, COP_C=4.0):
        super().__init__(name)
        self.q_max = q_max; self.COP_C = COP_C
    def build_variables(self, T):
        self.vars['Q_cool_out'] = [pulp.LpVariable(f"{self.name}_CoolOut_{t}", 0, self.q_max) for t in range(T)]
        self.vars['P_elec_in'] = [pulp.LpVariable(f"{self.name}_ElecIn_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['Q_cool_out'][t] == self.vars['P_elec_in'][t] * self.COP_C)

class AbsorptionChiller(BaseComponent):
    def __init__(self, name, q_max, COP_AC=1.2):
        super().__init__(name)
        self.q_max = q_max; self.COP_AC = COP_AC
    def build_variables(self, T):
        self.vars['Q_cool_out'] = [pulp.LpVariable(f"{self.name}_CoolOut_{t}", 0, self.q_max) for t in range(T)]
        self.vars['Q_heat_in'] = [pulp.LpVariable(f"{self.name}_HeatIn_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['Q_cool_out'][t] == self.vars['Q_heat_in'][t] * self.COP_AC)

class GenericStorage(BaseComponent):
    def __init__(self, name, capacity, power, loss_rate=0.001, eta_in=0.95, eta_out=0.95, init_state=0.1):
        super().__init__(name)
        self.C_max = capacity; self.P_max = power; self.loss = loss_rate
        self.eta_in = eta_in; self.eta_out = eta_out; self.init_state = init_state
    def build_variables(self, T):
        self.vars['Flow_in'] = [pulp.LpVariable(f"{self.name}_In_{t}", 0, self.P_max) for t in range(T)]
        self.vars['Flow_out'] = [pulp.LpVariable(f"{self.name}_Out_{t}", 0, self.P_max) for t in range(T)]
        self.vars['State'] = [pulp.LpVariable(f"{self.name}_State_{t}", 0, self.C_max) for t in range(T + 1)]
        self.vars['u_in'] = [pulp.LpVariable(f"{self.name}_u_in_{t}", cat=pulp.LpBinary) for t in range(T)]
        self.vars['u_out'] = [pulp.LpVariable(f"{self.name}_u_out_{t}", cat=pulp.LpBinary) for t in range(T)]
    def build_constraints(self, model, T, dt):
        model += (self.vars['State'][0] == self.init_state * self.C_max)
        for t in range(T):
            model += (self.vars['State'][t + 1] == self.vars['State'][t] * (1 - self.loss) + (self.vars['Flow_in'][t] * self.eta_in - self.vars['Flow_out'][t] / self.eta_out) * dt)
            model += (self.vars['Flow_in'][t] <= self.P_max * self.vars['u_in'][t])
            model += (self.vars['Flow_out'][t] <= self.P_max * self.vars['u_out'][t])
            model += (self.vars['u_in'][t] + self.vars['u_out'][t] <= 1)
        if T >= 24:
            model += (self.vars['State'][T] >= self.init_state * self.C_max)

class Electrolyzer(BaseComponent):
    def __init__(self, name, p_max, eta_EL=0.75, meh=39.54):
        super().__init__(name)
        self.p_max = p_max; self.eta_EL = eta_EL; self.meh = meh
    def build_variables(self, T):
        self.vars['P_elec_in'] = [pulp.LpVariable(f"{self.name}_ElecIn_{t}", 0, self.p_max) for t in range(T)]
        self.vars['M_H2_out'] = [pulp.LpVariable(f"{self.name}_H2Out_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['M_H2_out'][t] == (self.vars['P_elec_in'][t] * self.eta_EL) / self.meh)

class HydrogenFuelCell(BaseComponent):
    def __init__(self, name, m_max, eta_e=0.8, eta_h=0.15, meh=39.54):
        super().__init__(name)
        self.m_max = m_max; self.eta_e = eta_e; self.eta_h = eta_h; self.meh = meh
    def build_variables(self, T):
        self.vars['M_H2_in'] = [pulp.LpVariable(f"{self.name}_H2In_{t}", 0, self.m_max) for t in range(T)]
        self.vars['P_elec_out'] = [pulp.LpVariable(f"{self.name}_ElecOut_{t}", 0) for t in range(T)]
        self.vars['Q_heat_out'] = [pulp.LpVariable(f"{self.name}_HeatOut_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['P_elec_out'][t] == self.vars['M_H2_in'][t] * self.meh * self.eta_e)
            model += (self.vars['Q_heat_out'][t] == self.vars['M_H2_in'][t] * self.meh * self.eta_h)

class MethanationReactor(BaseComponent):
    def __init__(self, name, m_max, eta_MR=0.8, meh=39.54, meg=9.7):
        super().__init__(name)
        self.m_max = m_max; self.eta_MR = eta_MR; self.meh = meh; self.meg = meg
    def build_variables(self, T):
        self.vars['M_H2_in'] = [pulp.LpVariable(f"{self.name}_H2In_{t}", 0, self.m_max) for t in range(T)]
        self.vars['V_Gas_out'] = [pulp.LpVariable(f"{self.name}_GasOut_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['V_Gas_out'][t] == (self.vars['M_H2_in'][t] * self.meh * self.eta_MR) / self.meg)

class CarbonCaptureSystem(BaseComponent):
    def __init__(self, name, eta_ccs=0.65, eccs=0.269):
        super().__init__(name)
        self.eta_ccs = eta_ccs; self.eccs = eccs
    def build_variables(self, T):
        self.vars['M_CO2_cap'] = [pulp.LpVariable(f"{self.name}_CO2_cap_{t}", 0) for t in range(T)]
        self.vars['P_elec_in'] = [pulp.LpVariable(f"{self.name}_ElecIn_{t}", 0) for t in range(T)]
    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += (self.vars['P_elec_in'][t] == self.vars['M_CO2_cap'][t] * self.eccs)


# 💡 新增：余热锅炉类 (衔接废热与有效热)
class WasteHeatBoiler(BaseComponent):
    def __init__(self, name, capacity, eta_WHB=0.75):
        super().__init__(name)
        self.capacity = capacity
        self.eta_WHB = eta_WHB

    def build_variables(self, T):
        # 输入：吸纳废热； 输出：产出有效热
        self.vars['Q_waste_in'] = [pulp.LpVariable(f"{self.name}_Q_in_{t}", lowBound=0) for t in range(T)]
        self.vars['Q_heat_out'] = [pulp.LpVariable(f"{self.name}_Q_out_{t}", lowBound=0) for t in range(T)]

    def build_constraints(self, model, T, dt):
        for t in range(T):
            # 物理转换：有效热 = 废热 * 回收效率
            model += (self.vars['Q_heat_out'][t] == self.vars['Q_waste_in'][t] * self.eta_WHB)

            # 容量约束：受限于 NSGA-II 给定的最大容量
            if self.capacity is not None and self.capacity != '[后台自动寻优]':
                model += (self.vars['Q_heat_out'][t] <= float(self.capacity))