# -*- coding: utf-8 -*-
"""
固定 TOU 规则策略容量评价基线 (fixed_strategy_engine.py)
================================================================
小论文创新点 2 的对照组: 与嵌套精确 MILP (milp_capacity_engine.py) 在
同一外层 NSGA-II、同一典型日数据、同一经济参数下对比容量评价方法。

规则忠实转译自 Liu et al. 2025 (J. Energy Storage 122, 116592)
§2.2.2.1 / 图3 / 图4, 完整设计见 docs/固定TOU策略基线设计.md。

  谷价: 光伏余电充储能, 电池未满时额外购谷电充满; 缺额由电网补
  平价: 余电充储能→售电; 缺额直接电网, 不额外充电
  峰价: 余电全售; 缺额先电池放电, 再电网
  热/冷侧 (对称"谷蓄峰放"): 谷价 ASHP 供热/冷并额外充罐;
        峰价罐先放、ASHP 补; ASHP 电耗并入电负荷后再执行电侧规则

纯 numpy 逐时仿真, 单次评价毫秒级, 供 NSGA-II 大规模调用。

用法:
    from fixed_strategy_engine import FixedTOUEvaluator
    ev = FixedTOUEvaluator(contract)          # contract = 桥接模块输出契约
    res = ev.evaluate(pv_kw=5460, bat_kwh=5826, tank_kwh=2000)
    res['TA'] / res['AC'] / res['TG']         # 年总成本 / 年碳排(t) / 电网交互(kWh)
"""
import numpy as np

# ---------------- 经济与设备参数 (与 config_params.DEFAULT_PARAMS 对齐) ----------------
P = dict(
    interest_rate=0.05, project_life=20,
    device_costs={'PV': 3000, 'Battery': 1100, 'ASHP': 2170, 'Tank': 160},   # ¥/kW(或kWh)
    maintenance={'PV': 0.0235, 'Battery': 0.0189, 'ASHP': 0.0175, 'Tank': 0.0130},
    carbon_factor_grid=1.298,        # kg CO2 / kWh 购电
    carbon_tax=301,                  # ¥/t
    sell_ratio=0.6,                  # 售电价 = 购电价 × 0.6 (与 multi_scale_engine 自定义场景一致)
    penalty_shortage=10000,          # ¥/kWh 失负荷
    penalty_dump=0.5,                # ¥/kWh 弃能
    allow_sell=True,                 # 余电上网 (图3/图4 原文允许; 与 MILP 严格对比时置 False)
    bat_rate=0.2, bat_soc_min=0.10, bat_soc_max=0.95, bat_eta=0.95,
    tank_rate=0.2, tank_soc_min=0.10, tank_soc_max=0.95, tank_eta=0.98,
    cop_heat=4.18, cop_cool=5.45,    # 文献值, 与平台 ASHP 一致
)


def crf(i=P['interest_rate'], n=P['project_life']):
    """等额年金资本回收系数 (投资 → 年金化)。"""
    return i * (1 + i) ** n / ((1 + i) ** n - 1)


def _price_classes(price24):
    """TOU 价格 → 0谷/1平/2峰 三档时段索引 (按当日 24h 价格的档位排序)。"""
    uniq = np.unique(np.round(price24, 6))
    if len(uniq) >= 3:
        lo, hi = uniq[0], uniq[-1]
    elif len(uniq) == 2:                       # 只有两档: 低=谷, 高=峰 (无平段)
        lo, hi = uniq[0], uniq[1]
    else:                                      # 单一电价: 全按平段, 规则退化为"光伏自用+余电上网"
        return np.ones(24, dtype=int)
    cls = np.ones(24, dtype=int)
    cls[np.round(price24, 6) <= lo] = 0
    cls[np.round(price24, 6) >= hi] = 2
    return cls


class FixedTOUEvaluator:
    """给定容量 (pv_kw, bat_kwh, tank_kwh) → 规则策略年化 (TA, AC, TG)。

    contract: ies_load_forecast_bridge.assemble_contract 输出, 或 GUI import_custom_data
              生成的同构字典: typical_days / price_elec / profiles.PV / loads.{bus}
    ASHP 装机由热/冷负荷峰值派生 (文献 §2.2.2.2: 3 个决策变量之外的派生量)。
    """

    def __init__(self, contract, params=None):
        self.p = dict(P)
        if params:
            self.p.update(params)
        self.days = list(contract['typical_days'].keys())
        self.weights = np.array([contract['typical_days'][d] for d in self.days], dtype=float)
        self.weights /= self.weights.sum()                 # 归一为频率
        self.price = {d: np.asarray(contract['price_elec'][d], dtype=float) for d in self.days}
        self.cls = {d: _price_classes(self.price[d]) for d in self.days}
        self.e_load = {d: np.asarray(contract['loads']['ElectricityBus'].get(d, np.zeros(24)), dtype=float)
                       for d in self.days}
        self.h_load = {d: np.asarray(contract['loads']['HeatBus'].get(d, np.zeros(24)), dtype=float)
                       for d in self.days}
        self.c_load = {d: np.asarray(contract['loads']['CoolBus'].get(d, np.zeros(24)), dtype=float)
                       for d in self.days}
        self.pv_pf = {d: np.asarray(contract['profiles']['PV'].get(d, np.zeros(24)), dtype=float)
                      for d in self.days}

    # ---------------------------------------------------------------- 内层: 单典型日规则调度
    def _simulate_day(self, d, pv_kw, bat_kwh, tank_kwh):
        p = self.p
        dt = 1.0
        e_load, h_load, c_load = self.e_load[d], self.h_load[d], self.c_load[d]
        pv = self.pv_pf[d] * pv_kw
        cls = self.cls[d]
        price = self.price[d]

        # ---------- 1. 热/冷侧 (先算, ASHP 电耗并入电负荷) ----------
        heat_day = h_load.sum() >= c_load.sum()
        th_load = h_load if heat_day else c_load
        cop = p['cop_heat'] if heat_day else p['cop_cool']
        ashp_th = np.zeros(24)                 # ASHP 热/冷出力
        tank_in = np.zeros(24)                 # 罐充热 (来自 ASHP)
        tank_out = np.zeros(24)                # 罐放热
        unmet_th = np.zeros(24)

        if th_load.sum() > 1e-9 and (tank_kwh > 0 or th_load.max() > 0):
            cap_ahp = th_load.max()            # ASHP 装机 = 峰值热/冷负荷 (派生量, 文献口径)
            t_cap = max(tank_kwh, 1e-9)
            t_pw = p['tank_rate'] * t_cap
            stored = p['tank_soc_min'] * t_cap # 始于 SOC 下限: 当日充放全程被规则覆盖
            for t in range(24):
                demand = th_load[t]
                if cls[t] == 2:                # 峰价: 罐先放, ASHP 补
                    out = min(t_pw, max(stored - p['tank_soc_min'] * t_cap, 0.0) / dt
                              * p['tank_eta'], demand)
                    stored -= out * dt / p['tank_eta']
                    tank_out[t] = out
                    ahp = min(demand - out, cap_ahp)
                    ashp_th[t] = ahp
                    unmet_th[t] = demand - out - ahp
                else:                          # 谷/平: ASHP 直供; 谷价额外充罐
                    ahp = min(demand, cap_ahp)
                    ashp_th[t] = ahp
                    if cls[t] == 0 and stored < p['tank_soc_max'] * t_cap - 1e-6:
                        room = (p['tank_soc_max'] * t_cap - stored) / p['tank_eta'] / dt
                        extra = min(t_pw, room, cap_ahp - ahp + cap_ahp)  # ASHP 转入充罐模式
                        extra = min(extra, (p['tank_soc_max'] * t_cap - stored) / p['tank_eta'] / dt)
                        stored += extra * p['tank_eta'] * dt
                        tank_in[t] = extra * p['tank_eta']
                        ashp_th[t] += extra
            tank_loss = stored - p['tank_soc_min'] * t_cap   # 日末残差 (记为微小弃热成本)
        else:
            cap_ahp = 0.0
            tank_loss = 0.0
        ashp_el = ashp_th / cop if cop > 0 else np.zeros(24)

        # ---------- 2. 电侧 TOU 规则 (图3/图4) ----------
        load = e_load + ashp_el
        b_cap = max(bat_kwh, 1e-9)
        b_pw = p['bat_rate'] * b_cap
        soc = p['bat_soc_min'] * b_cap         # 空罐开局
        ch = np.zeros(24); dis = np.zeros(24)
        g_buy = np.zeros(24); g_sell = np.zeros(24)
        dump = np.zeros(24)                    # 物理弃电 (禁售时余电无处可去)
        unmet_el = np.zeros(24)
        for t in range(24):
            net = pv[t] - load[t]              # >0 光伏富余, <0 缺口
            if cls[t] in (0, 1):               # 谷/平: 余电充电→售电(或弃)
                if net >= 0:
                    pin = min(net, b_pw, (p['bat_soc_max'] * b_cap - soc) / p['bat_eta'] / dt)
                    soc += pin * p['bat_eta'] * dt
                    ch[t] = pin
                    rest = net - pin
                    if p['allow_sell']:
                        g_sell[t] = rest
                    else:
                        dump[t] = rest
                else:
                    need = -net
                    g_buy[t] = need
                    if cls[t] == 0:            # 文献明确: 谷价且电池未满 → 额外购电充满
                        pin = min(b_pw, (p['bat_soc_max'] * b_cap - soc) / p['bat_eta'] / dt)
                        soc += pin * p['bat_eta'] * dt
                        ch[t] = pin
                        g_buy[t] += pin
            else:                              # 峰: 余电全售(或弃); 缺口电池→电网
                if net >= 0:
                    if p['allow_sell']:
                        g_sell[t] = net
                    else:
                        dump[t] = net
                else:
                    need = -net
                    pout = min(b_pw, (soc - p['bat_soc_min'] * b_cap) * p['bat_eta'] / dt, need)
                    soc -= pout * dt / p['bat_eta']
                    dis[t] = pout
                    g_buy[t] = need - pout          # 电网兜底 → 电侧理论上不失负荷
        bat_residual = soc - p['bat_soc_min'] * b_cap        # 日末残差 (>0 蓄能未用尽)

        # ---------- 3. 当日成本项 ----------
        # 日末储能残差不另罚弃能: 其购电/ASHP 电耗成本已在 g_buy 中沉没
        # (典型日循环抽象下"买了没用"本身就是规则策略的真实代价, MILP 靠
        #  End-of-Horizon 守恒约束可完全避免 → 这正是对比点, 残差单独报告)
        buy_cost = float(np.sum(g_buy * price) * dt)
        sell_rev = float(np.sum(g_sell * price * p['sell_ratio']) * dt)
        dump_cost = float(np.sum(dump)) * p['penalty_dump']
        short_cost = float(np.sum(unmet_th) + np.sum(unmet_el)) * p['penalty_shortage']
        oper = buy_cost - sell_rev + dump_cost + short_cost
        carbon = float(np.sum(g_buy)) * p['carbon_factor_grid'] / 1000.0     # t
        tg = float(np.sum(g_buy) + np.sum(g_sell))
        return dict(oper=oper, carbon=carbon, tg=tg,
                    unmet=float(np.sum(unmet_th) + np.sum(unmet_el)),
                    dump_kwh=float(np.sum(dump)),
                    residual_kwh=float(max(bat_residual, 0) / p['bat_eta'] + max(tank_loss, 0) / p['tank_eta']),
                    buy=float(np.sum(g_buy)), sell=float(np.sum(g_sell)),
                    pv_gen=float(np.sum(pv)), ashp_el=float(np.sum(ashp_el)),
                    bat_thru=float(np.sum(ch) + np.sum(dis)),
                    tank_thru=float(np.sum(tank_in) + np.sum(tank_out)))

    # ---------------------------------------------------------------- 外层: 年化目标
    def evaluate(self, pv_kw, bat_kwh, tank_kwh, detail=False):
        p = self.p
        # ASHP 派生装机 (全年口径): 各典型日热/冷峰值的最大者
        peaks = []
        for d in self.days:
            th = self.h_load[d] if self.h_load[d].sum() >= self.c_load[d].sum() else self.c_load[d]
            peaks.append(th.max() if th.sum() > 1e-9 else 0.0)
        ahp_kw = max(peaks)

        oper = carbon = tg = 0.0
        unmet = residual_kwh = dump_kwh = 0.0
        pv_gen = ashp_el = bat_thru = tank_thru = 0.0
        for i, d in enumerate(self.days):
            r = self._simulate_day(d, pv_kw, bat_kwh, tank_kwh)
            w = self.weights[i] * 365.0
            oper += r['oper'] * w
            carbon += r['carbon'] * w
            tg += r['tg'] * w
            unmet += r['unmet'] * w
            residual_kwh += r['residual_kwh'] * w
            dump_kwh += r['dump_kwh'] * w
            pv_gen += r['pv_gen'] * w
            ashp_el += r['ashp_el'] * w
            bat_thru += r['bat_thru'] * w
            tank_thru += r['tank_thru'] * w

        cap = {'PV': pv_kw, 'Battery': bat_kwh, 'ASHP': ahp_kw, 'Tank': tank_kwh}
        c_inv = crf() * sum(cap[k] * p['device_costs'][k] for k in cap)
        # 运维与 MILP 层口径对齐: 按能量吞吐计 (PV 按发电量, 储能按充+放, ASHP 按耗电)
        c_ma = (pv_gen * p['maintenance']['PV'] + ashp_el * p['maintenance']['ASHP']
                + bat_thru * p['maintenance']['Battery'] + tank_thru * p['maintenance']['Tank'])
        ta = c_inv + c_ma + oper + carbon * p['carbon_tax']
        out = dict(TA=ta, AC=carbon, TG=tg, C_inv=c_inv, C_ma=c_ma, C_oper=oper,
                   ASHP_kw=ahp_kw, unmet_kwh=unmet, residual_kwh=residual_kwh,
                   dump_kwh=dump_kwh, pv_gen=pv_gen, ashp_el=ashp_el,
                   bat_thru=bat_thru, tank_thru=tank_thru)
        if detail:
            out['capacity'] = cap
        return out


if __name__ == '__main__':
    import sys
    import joblib
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    path = sys.argv[1] if len(sys.argv) > 1 else 'ies_forecast_contract.pkl'
    contract = joblib.load(path)
    ev = FixedTOUEvaluator(contract)
    print(f"典型日: {contract['typical_days']}")
    print(f"CRF = {crf():.4f}")
    # 冒烟测试: 零容量 / 文献推荐拐点附近的几组配置
    for pv, bat, tank in [(0, 0, 0), (500, 500, 0), (2000, 2000, 1000),
                          (5000, 5000, 2000), (10000, 10000, 4000)]:
        r = ev.evaluate(pv, bat, tank, detail=True)
        print(f"PV={pv:>5} Bat={bat:>5} Tank={tank:>5} | "
              f"TA={r['TA']:>12,.0f}  AC={r['AC']:>7.1f}t  TG={r['TG']:>10,.0f}  "
              f"ASHP={r['ASHP_kw']:>6.0f}  失负荷={r['unmet_kwh']:.0f}  储能残差={r['residual_kwh']:.0f}")
