import pulp
import numpy as np
import copy
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d, PchipInterpolator
import importlib
from system_builder import SystemBuilder
import plot_export

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class MultiScaleDispatcher:
    def __init__(self, project_config):
        self.config = project_config
        self.scenario = project_config.get("Scenario", "Microgrid")

        # =====================================================================
        # 💡 数据分流器：新老时代在此交汇
        # =====================================================================
        if self.scenario == "Custom":
            print(">>> [画图引擎] 识别到 Custom 场景，启动 Pchip 样条插值多尺度降维扩充...")
            self._init_custom_data()
        else:
            print(f">>> [画图引擎] 识别到预设场景 {self.scenario}，执行本地旧硬盘高频数据挂载...")
            import sys as _sys
            if self.scenario == "Hainan":
                _dl_path = r"C:\Users\i5\Desktop\多能互补拓扑系统海南多时间"
            elif self.scenario == "Hydrogen":
                _dl_path = r"C:\Users\i5\Desktop\多能互补拓扑系统电热氢多时间"
            else:
                _dl_path = r"C:\Users\i5\Desktop\多能互补拓扑系统多时间"

            if _dl_path not in _sys.path:
                _sys.path.insert(0, _dl_path)
            from data_loader import load_forecast_data, load_system_data
            self.sys_data = load_system_data('summer')
            self.load_DA, self.load_ID, self.load_RT = load_forecast_data('summer', self.sys_data)

    # =========================================================================
    # 💡 核心引擎：Custom 专属插值扩充器 (将 24 维平滑衍生至 96 维和 288 维)
    # =========================================================================
    def _init_custom_data(self):
        base_data = self.config.get("custom_data", None)
        if base_data is None:
            raise ValueError("❌ 画图引擎严重错误：未收到 custom_data，请检查 GUI 桥接是否成功！")

        # 💡 动态接收来自 GUI 的轮播指令（默认从 0 开始）
        day_idx = self.config.get('custom_day_idx', 0)
        day_key = list(base_data['typical_days'].keys())[day_idx]

        def get_24h(cat, sub=None):
            if cat == 'loads':
                return np.array(base_data['loads'].get(sub, {}).get(day_key, np.zeros(24)))
            elif cat == 'profiles':
                return np.array(base_data['profiles'].get(sub, {}).get(day_key, np.zeros(24)))
            elif cat == 'price':
                return np.array(base_data['price_elec'].get(day_key, np.ones(24)*0.5))

        pv_24 = get_24h('profiles', 'PV')
        wind_24 = get_24h('profiles', 'Wind')
        e_load_24 = get_24h('loads', 'ElectricityBus')
        h_load_24 = get_24h('loads', 'HeatBus')
        c_load_24 = get_24h('loads', 'CoolBus')
        g_load_24 = get_24h('loads', 'GasBus')
        h2_load_24 = get_24h('loads', 'HydrogenBus')
        price_24 = get_24h('price')

        # 样条平滑插值函数 (将 24h 扩充至任意分辨率，并注入真实世界的高频噪声)
        def interp_data(arr, steps, noise_ratio=0.0, renewable=False):
            if steps == 24:
                res = np.array(arr, dtype=float)
            else:
                x_old = np.linspace(0, 24, 24, endpoint=False)
                x_new = np.linspace(0, 24, steps, endpoint=False)
                f = PchipInterpolator(x_old, arr)
                res = f(x_new)
                # 全零负荷流(如无冷负荷的建筑)不注入噪声: 否则 1e-4 噪声底会造出幻影负荷被判失负荷
                # 💡 可再生能源跳过加性噪声 (只走下面的乘性噪声, 夜间0值才不会被噪声底抬成正出力)
                if noise_ratio > 0 and np.mean(arr) > 0 and not renewable:
                    res += np.random.normal(0, np.mean(arr) * noise_ratio + 1e-4, steps)
            # 💡 可再生能源用乘性噪声: 夜间0值不会被加性噪声底抬成幻影出力
            #    (旧逻辑下夜间 PV≈±几十kW 非零, 再被窗口内max归一化放大成满发)
            if renewable and noise_ratio > 0:
                res = res * (1.0 + noise_ratio * np.random.randn(steps))
            return np.clip(res, 0, None)

        def make_dict(steps, noise=0.0):
            return {
                'T': steps,             # 💡 补回缺失的时间步数
                'dt': 24.0 / steps,     # 💡 补回缺失的步长时间
                'PV_out': interp_data(pv_24, steps, noise, renewable=True),   # 💡 严格对齐老代码大写键名
                'Wind_out': interp_data(wind_24, steps, noise, renewable=True),
                'E_load': interp_data(e_load_24, steps, noise),
                'H_load': interp_data(h_load_24, steps, noise),
                'C_load': interp_data(c_load_24, steps, noise),
                'G_load': interp_data(g_load_24, steps, noise),
                'H2_load': interp_data(h2_load_24, steps, noise)
            }

        # 💡 补全 sys_data 字典骨架，满足 _prepare_config 读取需求防止崩溃
        self.sys_data = {
            'p_max': 50000,
            'price_gas': 3.395,
            'price_h2': 20.0,
            'price': {
                'buy': price_24,
                'sell': price_24 * 0.6  # 假设上网售电价打 6 折
            },
            'cost': {
                'env_cost_per_kwh': 0.0 # 默认无环境附加费
            },
            'capacity': {
                'PV_panels': 0, # 设为0触发自动最大值归一化逻辑
                'PV_P0': 0
            }
        }

        # 阶梯生成多尺度数据集
        self.load_DA = make_dict(24, 0.0)    # 日前预测 (1h级，无误差)
        self.load_ID = make_dict(96, 0.03)   # 日内滚动 (15min级，3%预测误差)
        self.load_RT = make_dict(288, 0.08)  # 实时调度 (5min级，8%强随机扰动)

    def _resample_data(self, parent, ratio, noise_level):
        """内置高精度插值器，不再依赖外部废弃文件"""
        sub_T = parent['T'] * ratio
        sub_dt = parent['dt'] / ratio
        t_p = np.arange(parent['T']) * parent['dt'] + parent['dt'] / 2
        t_s = np.arange(sub_T) * sub_dt + sub_dt / 2

        np.random.seed(42)
        noise = 1 + noise_level * np.random.randn(sub_T)

        sub = {'T': sub_T, 'dt': sub_dt}
        for k in ['E_load', 'C_load', 'H_load', 'G_load', 'H2_load', 'PV_out', 'Wind_out']:
            if k in parent:
                interp_func = PchipInterpolator(t_p, parent[k])
                raw = interp_func(t_s)
                raw[raw < 0] = 0
                sub[k] = raw * noise
        return sub

    # 🟢 注意：从这里开始往下，你的 def _prepare_config() 和 def run_simulation() 必须原封不动保留！

    def _day_max(self, key, window_arr):
        """💡 取全天曲线的最大值做归一化基准。
        旧逻辑按当前滚动窗口内的 max 归一化: 夜间窗口 PV 序列近零(噪声残留),
        除以极小的窗口 max 后 profile≈1.0, 导致光伏深夜满发出力(全弃电)。"""
        full = self.load_DA.get(key)
        if full is not None and np.max(full) > 0:
            return np.max(full)
        return np.max(window_arr) if np.max(window_arr) > 0 else 1.0

    def _prepare_config(self, scale_data, current_states=None, step_idx=0):
        cfg = copy.deepcopy(self.config)
        L = scale_data['T']
        dt_c = scale_data['dt']
        t_da = np.arange(1, 25)
        t_window = np.arange(1, L + 1) * dt_c + step_idx * dt_c

        price_buy = self.sys_data['price']['buy']
        price_sell = self.sys_data['price']['sell']
        f_buy = interp1d(t_da, price_buy, kind='previous', bounds_error=False, fill_value=(price_buy[0], price_buy[-1]))
        f_sell = interp1d(t_da, price_sell, kind='previous', bounds_error=False,
                          fill_value=(price_sell[0], price_sell[-1]))
        buy_arr = f_buy(t_window)
        sell_arr = f_sell(t_window)

        for c_name, p in cfg["Components"].items():
            if "type" not in p:
                continue  # 免疫所有字典报错

            if p["type"] == "PowerGrid":
                p["buy_price"] = buy_arr
                p["sell_price"] = sell_arr
                p["env_cost"] = self.sys_data['cost']['env_cost_per_kwh']
                # 论文 Eq.15 仅有购能项，不允许余电上网

            elif p["type"] == "Storage_Battery":
                p["aging_cost"] = 0.05

            elif p["type"] == "EnergyLoad":
                l_type = p.get("load_type", "E_load")
                p["profile"] = scale_data.get(l_type, np.zeros(L))
            # 💡 核心修复：把 PVT 加入光照曲线解析白名单，并共享 PV 的光照数据
            elif p["type"] in ["RenewableSource", "SolarThermalCollector", "RenewableSource_PVT"]:
                s_type = p.get("source_type", "PV_out")
                if s_type == "PVT_out":
                    s_type = "PV_out"  # 强制将 PVT 的天气源重定向到光伏的日照曲线

                arr = scale_data.get(s_type, np.zeros(L))

                # 💡 抹除海象运算符 (:=)，兼容所有 Python 版本，彻底杜绝语法崩溃
                m_val = 1.0
                if s_type == "PV_out":
                    base_cap = self.sys_data['capacity']['PV_panels'] * self.sys_data['capacity']['PV_P0']
                    if base_cap > 0:
                        m_val = base_cap
                    else:
                        m_val = self._day_max('PV_out', arr)
                else:
                    m_val = self._day_max('Wind_out', arr) if s_type == "Wind_out" else (
                        np.max(arr) if np.max(arr) > 0 else 1.0)

                p["profile"] = arr / m_val

            if current_states and c_name in current_states:
                p["soc_init"] = current_states[c_name]

        return cfg

    def run_simulation(self):
        # 💡 静默注入外部氢气网络以支持电热氢场景
        if "HydrogenBus" in self.config.get("Buses", []):
            if "City_H2Net" not in self.config["Components"]:
                self.config["Components"]["City_H2Net"] = {"type": "HydrogenNetwork", "bus": "HydrogenBus"}

        print("\n[引擎] 1/4 正在执行 日前全局优化 (DA) ...")
        cfg_da = self._prepare_config(self.load_DA)
        builder_da = SystemBuilder(cfg_da, self.load_DA['T'], self.load_DA['dt'])
        builder_da.build()
        builder_da.model += builder_da.base_cost
        builder_da.solve(time_limit=120)

        da_results = {}
        for c_name, comp in builder_da.components.items():
            da_results[c_name] = {}
            for v_name, v_list in comp.vars.items():
                if isinstance(v_list[0], pulp.LpVariable):
                    da_results[c_name][v_name] = np.array([v.varValue for v in v_list])

        print("[引擎] 2/4 正在执行 日内滚动追踪优化 (ID) ...")
        T_id, dt_id = self.load_ID['T'], self.load_ID['dt']
        horizon_id = int(4 / dt_id)
        current_states_id = {}
        id_results = {c: {v: np.zeros(T_id) for v in da_results[c]} for c in da_results}
        t_da_center = np.arange(self.load_DA['T']) * self.load_DA['dt'] + self.load_DA['dt'] / 2

        for k in range(T_id):
            end_idx = min(k + horizon_id, T_id);
            L = end_idx - k
            window_data = {
                'T': L, 'dt': dt_id,
                'E_load': self.load_ID['E_load'][k:end_idx], 'C_load': self.load_ID['C_load'][k:end_idx],
                'H_load': self.load_ID['H_load'][k:end_idx],
                'G_load': self.load_ID.get('G_load', np.zeros(L))[k:end_idx],
                'H2_load': self.load_ID.get('H2_load', np.zeros(L))[k:end_idx],
                'PV_out': self.load_ID['PV_out'][k:end_idx],
                'Wind_out': self.load_ID.get('Wind_out', np.zeros(L))[k:end_idx]
            }

            cfg_id = self._prepare_config(window_data, current_states_id, step_idx=k)
            builder_id = SystemBuilder(cfg_id, L, dt_id)
            builder_id.build()

            lambda_track = 500;
            penalty = 0
            for c_name, comp in builder_id.components.items():
                if c_name not in da_results: continue
                for v_name, v_list in comp.vars.items():
                    if v_name in ['SOC', 'State', 'u_in', 'u_out'] or v_name not in da_results[c_name]: continue
                    f_ref = interp1d(t_da_center, da_results[c_name][v_name], kind='nearest', bounds_error=False,
                                     fill_value=(da_results[c_name][v_name][0], da_results[c_name][v_name][-1]))
                    for i in range(L):
                        t_center = (k + i) * dt_id + dt_id / 2
                        ref_val = f_ref(t_center).item()
                        dev = pulp.LpVariable(f"dev_id_{c_name}_{v_name}_{k}_{i}", lowBound=0)
                        builder_id.model += (dev >= v_list[i] - ref_val)
                        builder_id.model += (dev >= ref_val - v_list[i])
                        penalty += dev * lambda_track

            builder_id.model += builder_id.base_cost + penalty
            builder_id.solve(time_limit=30)

            if pulp.LpStatus[builder_id.model.status] == 'Optimal':
                for c_name, comp in builder_id.components.items():
                    if c_name in id_results:
                        for v_name, v_list in comp.vars.items():
                            if v_name in id_results[c_name] and isinstance(v_list[0], pulp.LpVariable):
                                id_results[c_name][v_name][k] = v_list[0].varValue
                                if v_name in ['SOC', 'State'] and len(v_list) > 1:
                                    c_max_val = max(getattr(comp, 'C_max', 1.0), 1e-6)
                                    current_states_id[c_name] = max(0.0, min(1.0, v_list[1].varValue / c_max_val))

        print("[引擎] 3/4 正在执行 实时滚动追踪优化 (RT) ...")
        T_rt, dt_rt = self.load_RT['T'], self.load_RT['dt']
        horizon_rt = max(1, int(0.25 / dt_rt))
        current_states_rt = {}
        rt_results = {c: {v: np.zeros(T_rt) for v in da_results[c]} for c in da_results}
        t_id_center = np.arange(self.load_ID['T']) * self.load_ID['dt'] + self.load_ID['dt'] / 2

        for k in range(T_rt):
            end_idx = min(k + horizon_rt, T_rt);
            L = end_idx - k
            window_data = {
                'T': L, 'dt': dt_rt,
                'E_load': self.load_RT['E_load'][k:end_idx], 'C_load': self.load_RT['C_load'][k:end_idx],
                'H_load': self.load_RT['H_load'][k:end_idx],
                'G_load': self.load_RT.get('G_load', np.zeros(L))[k:end_idx],
                'H2_load': self.load_RT.get('H2_load', np.zeros(L))[k:end_idx],
                'PV_out': self.load_RT['PV_out'][k:end_idx],
                'Wind_out': self.load_RT.get('Wind_out', np.zeros(L))[k:end_idx]
            }

            cfg_rt = self._prepare_config(window_data, current_states_rt, step_idx=k)
            builder_rt = SystemBuilder(cfg_rt, L, dt_rt)
            builder_rt.build()

            lambda_track_rt = 800;
            penalty_rt = 0
            for c_name, comp in builder_rt.components.items():
                if c_name not in id_results: continue
                for v_name, v_list in comp.vars.items():
                    if v_name in ['SOC', 'State', 'u_in', 'u_out'] or v_name not in id_results[c_name]: continue
                    f_ref = interp1d(t_id_center, id_results[c_name][v_name], kind='nearest', bounds_error=False,
                                     fill_value=(id_results[c_name][v_name][0], id_results[c_name][v_name][-1]))
                    for i in range(L):
                        t_center = (k + i) * dt_rt + dt_rt / 2
                        ref_val = f_ref(t_center).item()
                        dev = pulp.LpVariable(f"dev_rt_{c_name}_{v_name}_{k}_{i}", lowBound=0)
                        builder_rt.model += (dev >= v_list[i] - ref_val)
                        builder_rt.model += (dev >= ref_val - v_list[i])
                        penalty_rt += dev * lambda_track_rt

            builder_rt.model += builder_rt.base_cost + penalty_rt
            builder_rt.solve(time_limit=30)

            if pulp.LpStatus[builder_rt.model.status] == 'Optimal':
                for c_name, comp in builder_rt.components.items():
                    if c_name in rt_results:
                        for v_name, v_list in comp.vars.items():
                            if v_name in rt_results[c_name] and isinstance(v_list[0], pulp.LpVariable):
                                rt_results[c_name][v_name][k] = v_list[0].varValue
                                if v_name in ['SOC', 'State'] and len(v_list) > 1:
                                    c_max_val = max(getattr(comp, 'C_max', 1.0), 1e-6)
                                    current_states_rt[c_name] = max(0.0, min(1.0, v_list[1].varValue / c_max_val))

        print("[引擎] 4/4 多尺度调度完成！开始渲染全景图谱...")
        self.plot_multi_scale_tracking(da_results, id_results, rt_results, T_id, dt_id, T_rt, dt_rt)

    def plot_multi_scale_tracking(self, da_res, id_res, rt_res, T_id, dt_id, T_rt, dt_rt):
        t_da = np.arange(1, self.load_DA['T'] + 1)
        t_id = np.arange(1, T_id + 1) * dt_id
        t_rt = np.arange(1, T_rt + 1) * dt_rt

        # 🌟 修复关键：支持名称数组的鲁棒提取方法
        def get_vals(res, c_names, v_name, length):
            if isinstance(c_names, str):
                c_names = [c_names]
            for c_name in c_names:
                if c_name in res and v_name in res[c_name]:
                    return res[c_name][v_name]
            return np.zeros(length)

        # 💡 全局统一且匹配原论文的终极调色板
        c_map = {
            '光伏': '#0A562C', '风电': '#FFC000', '电网买电': '#00AEEF', '外部购电': '#00AEEF',
            '电池放电': '#7F7F7F', '蓄电池放电': '#7F7F7F', '电池充电': '#FF3399', '蓄电池充电': '#FF3399',
            '热泵耗电': '#8A2BE2', '电制冷机耗电': '#8A2BE2', '电锅炉耗电': '#BA55D3',
            '电解槽耗电': '#7030A0', '碳捕集耗电': '#92D050',
            'CHP发电': '#ED1C24', '氢燃料电池发电': '#99CCFF',
            'PVT发电': '#FF8C00', 'PVT产热': '#FF4500',
            'CHP产热': '#00B050', '燃气机产热': '#00B050', '燃气锅炉产热': '#ED1C24', '氢燃料电池产热': '#99CCFF',
            '热泵产热': '#FF69B4', '电锅炉产热': '#BA55D3',
            '蓄热罐放热': '#7F7F7F', '蓄热罐蓄热': '#FF3399',
            '热泵产冷': '#00B0F0', '电制冷机产冷': '#00B0F0', '吸收式产冷': '#00B050', '吸收式耗热': '#4B0082',
            '蓄冷罐放冷': '#7F7F7F', '蓄冷罐蓄冷': '#FF3399',
            '市政买气': '#00AEEF', '外部购气': '#00AEEF', '甲烷发生器产气': '#F4B183', '储气罐放气': '#7F7F7F',
            'CHP耗气': '#0700CD', '燃气机耗气': '#0700CD', '燃气锅炉耗气': '#7030A0', '储气罐充气': '#FF3399',
            '外部购氢': '#00AEEF', '电解槽产氢': '#00B050', '储氢罐放氢': '#7F7F7F',
            '氢燃料电池耗氢': '#7030A0', '甲烷发生器耗氢': '#C55A11', '储氢罐充氢': '#FF3399', '地源热泵耗电': '#6A5ACD', '地源热泵产热': '#FF1493', '地源热泵产冷': '#00CED1'
        }

        has_heat = self.load_DA.get('H_load', np.zeros(1)).sum() > 0.1 or any(
            k in da_res for k in ["Gas_CHP", "LiBr_Chiller", "Abs_Chiller", "Gas_Boiler"])
        has_cool = self.load_DA.get('C_load', np.zeros(1)).sum() > 0.1 or any(
            k in da_res for k in ["Elec_Chiller", "ElectricChiller", "LiBr_Chiller", "Abs_Chiller"])
        has_gas = self.load_DA.get('G_load', np.zeros(1)).sum() > 0.1 or "City_GasNet" in da_res
        has_h2 = self.load_DA.get('H2_load', np.zeros(1)).sum() > 0.1 or "Electrolyzer" in da_res

        # ============== 🚀 图0: 充放电与多尺度调度追踪折线图 ==============
        fig0, (ax_tr1, ax_tr2) = plt.subplots(2, 1, figsize=(12, 8))

        # 1. 购电网追踪
        da_grid = get_vals(da_res, "State_Grid", "P_buy", len(t_da))
        id_grid = get_vals(id_res, "State_Grid", "P_buy", len(t_id))
        rt_grid = get_vals(rt_res, "State_Grid", "P_buy", len(t_rt))
        ax_tr1.step(t_da, da_grid, where='mid', label='DA 日前电网购电 (1h)', linewidth=2.5, color='#00B0F0', alpha=0.8)
        ax_tr1.step(t_id, id_grid, where='mid', label='ID 日内追踪购电 (15min)', linestyle='--', linewidth=2,
                    color='red')
        ax_tr1.step(t_rt, rt_grid, where='mid', label='RT 实时调峰响应 (5min)', linestyle=':', linewidth=2,
                    color='#00B050')
        ax_tr1.set_title("追踪：电网购电净功率", fontsize=12, fontweight='bold');
        ax_tr1.grid(True, linestyle='--');

        handles, labels = ax_tr1.get_legend_handles_labels()
        if handles: ax_tr1.legend()

        # 2. 电池充放电追踪
        da_bat = get_vals(da_res, "Battery_Array", "Flow_in", len(t_da)) - get_vals(da_res, "Battery_Array", "Flow_out",
                                                                                    len(t_da))
        id_bat = get_vals(id_res, "Battery_Array", "Flow_in", len(t_id)) - get_vals(id_res, "Battery_Array", "Flow_out",
                                                                                    len(t_id))
        rt_bat = get_vals(rt_res, "Battery_Array", "Flow_in", len(t_rt)) - get_vals(rt_res, "Battery_Array", "Flow_out",
                                                                                    len(t_rt))
        ax_tr2.step(t_da, da_bat, where='mid', label='DA 日前电池预充放 (1h)', linewidth=2.5, color='#0070C0',
                    alpha=0.8)
        ax_tr2.step(t_id, id_bat, where='mid', label='ID 日内电池跟随补偿 (15min)', linestyle='--', linewidth=2,
                    color='black')
        ax_tr2.step(t_rt, rt_bat, where='mid', label='RT 实时平抑波动 (5min)', linestyle=':', linewidth=2.5,
                    color='#00B050')
        ax_tr2.set_title("追踪：电池净吞吐 (正=充, 负=放)", fontsize=12, fontweight='bold');
        ax_tr2.grid(True, linestyle='--');

        handles, labels = ax_tr2.get_legend_handles_labels()
        if handles: ax_tr2.legend()
        fig0.tight_layout()

        # ============== 图1: 电力平衡图 ==============
        fig1, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

        def plot_electricity(ax, res, t_arr, title, width):
            e_pv = get_vals(res, "Roof_PV", "P_out", len(t_arr))
            e_wind = get_vals(res, "Wind_Farm", "P_out", len(t_arr))
            e_grid_buy = get_vals(res, "State_Grid", "P_buy", len(t_arr))
            e_grid_sell = get_vals(res, "State_Grid", "P_sell", len(t_arr))
            e_bat_out = get_vals(res, "Battery_Array", "Flow_out", len(t_arr))
            e_chp = get_vals(res, ["Gas_CHP", "GasGen"], "P_elec_out", len(t_arr))
            e_hfc = get_vals(res, "HydrogenFuelCell", "P_elec_out", len(t_arr))
            e_pvt = get_vals(res, "PVT_Collector", "P_out", len(t_arr))
            e_load = self.load_DA['E_load'] if len(t_arr) == 24 else self.load_ID['E_load']

            e_bat_in = get_vals(res, "Battery_Array", "Flow_in", len(t_arr))
            e_ashp = get_vals(res, "Main_ASHP", "P_elec_in", len(t_arr))
            e_echiller = get_vals(res, ["Elec_Chiller", "ElectricChiller"], "P_elec_in", len(t_arr))
            e_eb = get_vals(res, "Elec_Boiler", "P_elec_in", len(t_arr))
            e_el = get_vals(res, "Electrolyzer", "P_elec_in", len(t_arr))
            e_ccs = get_vals(res, "Carbon_Capture", "P_elec_in", len(t_arr))
            e_gshp = get_vals(res, "Ground_Source_HP", "P_elec_in", len(t_arr))

            # 💡 强制计算隐含的"缺电(失负荷)"与"弃电"
            # 售电 (Grid_P_sell) 作为电力消费者：从系统流出换收益，非弃电
            e_supply_total = e_pv + e_pvt + e_wind + e_bat_out + e_chp + e_hfc + e_grid_buy
            e_consume_total = e_load + e_bat_in + e_ashp + e_gshp + e_echiller + e_eb + e_el + e_ccs + e_grid_sell
            e_short = np.maximum(0, e_consume_total - e_supply_total)  # 缺额
            e_dump = np.maximum(0, e_supply_total - e_consume_total)  # 弃电（售电后仍过剩的）

            bot_pos = np.zeros(len(t_arr))
            # 将 e_short 加入到正向堆叠柱状图中
            for d, l in zip([e_pv, e_pvt, e_wind, e_bat_out, e_chp, e_hfc, e_grid_buy, e_short],
                            ['光伏', 'PVT发电', '风电', '电池放电', 'CHP发电', '氢燃料电池发电', '电网买电', '失负荷(缺电)']):
                color_code = '#000000' if '缺' in l else c_map.get(l, 'gray')  # 用纯黑色代表失负荷
                if d.sum() > 0: ax.bar(t_arr, d, bottom=bot_pos, label=l, color=color_code, edgecolor='black',
                                       width=width, linewidth=0.5); bot_pos += d

            bot_neg = np.zeros(len(t_arr))
            # 负向堆叠：用电设备 + 余电上网 + 弃电
            for d, l in zip([-e_ashp, -e_gshp, -e_echiller, -e_eb, -e_bat_in, -e_el, -e_ccs, -e_grid_sell, -e_dump],
                            ['热泵耗电', '地源热泵耗电', '电制冷机耗电', '电锅炉耗电', '电池充电', '电解槽耗电', '碳捕集耗电',
                             '余电上网售电', '系统弃电']):
                if '售电' in l:
                    color_code = '#00B050'  # 绿色代表收益
                elif '弃' in l:
                    color_code = '#FFFF00'  # 弃电用纯黄警告
                else:
                    color_code = c_map.get(l, 'gray')
                if np.abs(d).sum() > 0: ax.bar(t_arr, d, bottom=bot_neg, label=l, color=color_code, edgecolor='black',
                                               width=width, linewidth=0.5); bot_neg += d

            ax.plot(t_arr, e_load, color='red', label='电负荷', linewidth=2, marker='o', markerfacecolor='none',
                    markersize=4)
            ax.set_title(title, fontsize=12, fontweight='bold')
            ax.set_ylabel("Power / kW")
            ax.set_xlim(0, 24)
            ax.grid(True, linestyle='--', alpha=0.5)
            ax.axhline(0, color='black', linewidth=1)

            handles, labels = ax.get_legend_handles_labels()
            if handles:
                ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=4, frameon=True, edgecolor='black',
                          fontsize=9)

        plot_electricity(ax1, da_res, t_da, "DA 电力平衡", 1.0);
        plot_electricity(ax2, id_res, t_id, "ID 电力平衡", dt_id)
        fig1.subplots_adjust(bottom=0.25, hspace=0.5)

        # ============== 图2: 冷力平衡图 ==============
        if has_cool:
            fig_cool, (ax_c1, ax_c2) = plt.subplots(2, 1, figsize=(12, 10))

            def plot_cool(ax, res, t_arr, title, width):
                c_ec = get_vals(res, ["Elec_Chiller", "ElectricChiller"], "Q_cool_out", len(t_arr))
                c_ashp = get_vals(res, "Main_ASHP", "Q_cool_out", len(t_arr))
                c_gshp = get_vals(res, "Ground_Source_HP", "Q_cool_out", len(t_arr))
                c_ac = get_vals(res, ["LiBr_Chiller", "Abs_Chiller", "AbsorptionChiller"], "Q_cool_out", len(t_arr))
                c_tank_out = get_vals(res, ["Thermal_Tank", "Cool_Tank", "CoolTank"], "Flow_out", len(t_arr))
                c_tank_in = get_vals(res, ["Thermal_Tank", "Cool_Tank", "CoolTank"], "Flow_in", len(t_arr))
                c_load = self.load_DA['C_load'] if len(t_arr) == 24 else self.load_ID['C_load']

                # 💡 新增核心逻辑：强制计算隐含的"缺冷(失负荷)"与"弃冷"
                c_supply_total = c_ashp + c_gshp + c_ec + c_ac + c_tank_out
                c_consume_total = c_load + c_tank_in
                c_short = np.maximum(0, c_consume_total - c_supply_total)
                c_dump = np.maximum(0, c_supply_total - c_consume_total)

                bot_pos = np.zeros(len(t_arr))
                for d, l in zip([c_ashp, c_gshp, c_ec, c_ac, c_tank_out, c_short],
                                ['热泵产冷', '地源热泵产冷', '电制冷机产冷', '吸收式产冷', '蓄冷罐放冷', '失负荷(缺冷)']):
                    color_code = '#000000' if '缺' in l else c_map.get(l, 'gray')  # 用纯黑色代表失负荷
                    if d.sum() > 0: ax.bar(t_arr, d, bottom=bot_pos, label=l, color=color_code, edgecolor='black',
                                           width=width, linewidth=0.5); bot_pos += d

                bot_neg = np.zeros(len(t_arr))
                for d, l in zip([-c_tank_in, -c_dump], ['蓄冷罐蓄冷', '系统弃冷']):
                    color_code = '#FFFF00' if '弃' in l else c_map.get(l, 'gray')
                    if np.abs(d).sum() > 0: ax.bar(t_arr, d, bottom=bot_neg, label=l, color=color_code,
                                                   edgecolor='black', width=width, linewidth=0.5); bot_neg += d

                if c_load.sum() > 0: ax.plot(t_arr, c_load, color='red', label='冷负荷', linewidth=2, marker='o',
                                             markerfacecolor='none', markersize=4)
                ax.set_title(title, fontsize=12, fontweight='bold')
                ax.set_ylabel("Power / kW")
                ax.set_xlim(0, 24)
                ax.grid(True, linestyle='--', alpha=0.5)
                ax.axhline(0, color='black', linewidth=1)

                handles, labels = ax.get_legend_handles_labels()
                if handles:
                    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=4, frameon=True, edgecolor='black',
                              fontsize=9)

            plot_cool(ax_c1, da_res, t_da, "DA 冷力平衡", 1.0);
            plot_cool(ax_c2, id_res, t_id, "ID 冷力平衡", dt_id)
            fig_cool.subplots_adjust(bottom=0.25, hspace=0.5)

        # ============== 图3: 热力平衡图 ==============
        if has_heat:
            fig_heat, (ax3, ax4) = plt.subplots(2, 1, figsize=(12, 10))

            def plot_thermal(ax, res, t_arr, title, width):
                h_chp = get_vals(res, ["Gas_CHP", "GasGen"], "Q_heat_out", len(t_arr));
                h_gb = get_vals(res, "Gas_Boiler", "Q_heat_out", len(t_arr))
                h_tank_out = get_vals(res, ["Thermal_Tank", "Heat_Tank"], "Flow_out", len(t_arr));
                h_tank_in = get_vals(res, ["Thermal_Tank", "Heat_Tank"], "Flow_in", len(t_arr))
                h_abs = get_vals(res, ["LiBr_Chiller", "Abs_Chiller", "AbsorptionChiller"], "Q_heat_in", len(t_arr));
                h_load = self.load_DA['H_load'] if len(t_arr) == 24 else self.load_ID['H_load']
                h_eb = get_vals(res, "Elec_Boiler", "Q_heat_out", len(t_arr));
                h_ashp = get_vals(res, "Main_ASHP", "Q_heat_out", len(t_arr))
                h_hfc = get_vals(res, "HydrogenFuelCell", "Q_heat_out", len(t_arr))
                h_pvt = get_vals(res, "PVT_Collector", "Q_out", len(t_arr))
                h_gshp = get_vals(res, "Ground_Source_HP", "Q_heat_out", len(t_arr))
                # 👇 1. 提取 WHB 产热
                h_whb = get_vals(res, "WHB", "Q_heat_out", len(t_arr))

                # 💡 计算热力不平衡量（缺热 / 弃热）
                h_supply_total = h_chp + h_gb + h_hfc + h_ashp + h_gshp + h_eb + h_pvt + h_tank_out + h_whb
                h_consume_total = h_load + h_tank_in + h_abs
                h_short = np.maximum(0, h_consume_total - h_supply_total)  # 缺热（失负荷）
                h_dump = np.maximum(0, h_supply_total - h_consume_total)  # 弃热

                bot_pos = np.zeros(len(t_arr))
                # 👇 2. 把 h_whb 加进堆叠循环里，并配上标签
                for d, l in zip([h_chp, h_gb, h_hfc, h_ashp, h_gshp, h_eb, h_pvt, h_tank_out, h_whb, h_short],
                                ['CHP产热', '燃气锅炉产热', '氢燃料电池产热', '热泵产热', '地源热泵产热', '电锅炉产热', 'PVT产热', '蓄热罐放热', '余热锅炉产热', '缺热(失负荷)']):
                    if d.sum() > 0: ax.bar(t_arr, d, bottom=bot_pos, label=l,
                                           color='#000000' if '缺' in l else c_map.get(l, 'gray'),
                                           edgecolor='black', width=width, linewidth=0.5); bot_pos += d

                bot_neg = np.zeros(len(t_arr))
                for d, l in zip([-h_tank_in, -h_abs, -h_dump], ['蓄热罐蓄热', '吸收式耗热', '系统弃热']):
                    color_code = '#FFFF00' if '弃' in l else c_map.get(l, 'gray')
                    if np.abs(d).sum() > 0: ax.bar(t_arr, d, bottom=bot_neg, label=l,
                                                   color=color_code, edgecolor='black', width=width, linewidth=0.5); bot_neg += d

                if h_load.sum() > 0: ax.plot(t_arr, h_load, color='red', label='热负荷', linewidth=2, marker='o',
                                             markerfacecolor='none', markersize=4)
                ax.set_title(title, fontsize=12, fontweight='bold');
                ax.set_ylabel("Power / kW");
                ax.set_xlim(0, 24)
                ax.grid(True, linestyle='--', alpha=0.5);
                ax.axhline(0, color='black', linewidth=1)

                handles, labels = ax.get_legend_handles_labels()
                if handles:
                    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=4, frameon=True, edgecolor='black',
                              fontsize=9)

            plot_thermal(ax3, da_res, t_da, "DA 热力平衡", 1.0);
            plot_thermal(ax4, id_res, t_id, "ID 热力平衡", dt_id)
            fig_heat.subplots_adjust(bottom=0.25, hspace=0.5)

        # ============== 图4: 天然气平衡图 ==============
        if has_gas:
            fig_gas, (ax5, ax6) = plt.subplots(2, 1, figsize=(12, 10))

            def plot_gas(ax, res, t_arr, title, width):
                lhv = 9.7
                g_buy = get_vals(res, "City_GasNet", "Gas_buy", len(t_arr)) * lhv
                g_mr = get_vals(res, "MethanationReactor", "V_Gas_out", len(t_arr)) * lhv
                g_tank_out = get_vals(res, "Gas_Tank", "Flow_out", len(t_arr)) * lhv
                g_chp = get_vals(res, ["Gas_CHP", "GasGen"], "V_gas_in", len(t_arr)) * lhv
                g_gb = get_vals(res, "Gas_Boiler", "V_gas_in", len(t_arr)) * lhv
                g_tank_in = get_vals(res, "Gas_Tank", "Flow_in", len(t_arr)) * lhv
                g_load = (self.load_DA['G_load'] if len(t_arr) == 24 else self.load_ID['G_load']) * lhv

                bot_pos = np.zeros(len(t_arr))
                for d, l in zip([g_buy, g_mr, g_tank_out], ['市政买气', '甲烷发生器产气', '储气罐放气']):
                    if d.sum() > 0: ax.bar(t_arr, d, bottom=bot_pos, label=l, color=c_map.get(l, 'gray'),
                                           edgecolor='black', width=width, linewidth=0.5); bot_pos += d

                bot_neg = np.zeros(len(t_arr))
                for d, l in zip([-g_chp, -g_gb, -g_tank_in], ['CHP耗气', '燃气锅炉耗气', '储气罐充气']):
                    if np.abs(d).sum() > 0: ax.bar(t_arr, d, bottom=bot_neg, label=l, color=c_map.get(l, 'gray'),
                                                   edgecolor='black', width=width, linewidth=0.5); bot_neg += d

                if g_load.sum() > 0: ax.plot(t_arr, g_load, color='red', label='天然气负荷', linewidth=2, marker='o',
                                             markerfacecolor='none', markersize=4)
                ax.set_title(title, fontsize=12, fontweight='bold');
                ax.set_ylabel("Power / kW (LHV eq)");
                ax.set_xlim(0, 24)
                ax.grid(True, linestyle='--', alpha=0.5);
                ax.axhline(0, color='black', linewidth=1)

                handles, labels = ax.get_legend_handles_labels()
                if handles:
                    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=4, frameon=True, edgecolor='black',
                              fontsize=9)

            plot_gas(ax5, da_res, t_da, "DA 天然气平衡", 1.0);
            plot_gas(ax6, id_res, t_id, "ID 天然气平衡", dt_id)
            fig_gas.subplots_adjust(bottom=0.25, hspace=0.5)

        # ============== 图5: 氢能平衡图 ==============
        if has_h2:
            fig_h2, (ax7, ax8) = plt.subplots(2, 1, figsize=(12, 10))

            def plot_hydrogen(ax, res, t_arr, title, width):
                h2_buy = get_vals(res, "City_H2Net", "H2_buy", len(t_arr))
                h2_el = get_vals(res, "Electrolyzer", "M_H2_out", len(t_arr));
                h2_tank_out = get_vals(res, "Hydrogen_Tank", "Flow_out", len(t_arr))
                h2_hfc = get_vals(res, "HydrogenFuelCell", "M_H2_in", len(t_arr));
                h2_mr = get_vals(res, "MethanationReactor", "M_H2_in", len(t_arr))
                h2_tank_in = get_vals(res, "Hydrogen_Tank", "Flow_in", len(t_arr))
                h2_load = self.load_DA['H2_load'] if len(t_arr) == 24 else self.load_ID['H2_load']

                bot_pos = np.zeros(len(t_arr))
                for d, l in zip([h2_buy, h2_el, h2_tank_out], ['外部购氢', '电解槽产氢', '储氢罐放氢']):
                    if d.sum() > 0: ax.bar(t_arr, d, bottom=bot_pos, label=l, color=c_map.get(l, 'gray'),
                                           edgecolor='black', width=width, linewidth=0.5); bot_pos += d

                bot_neg = np.zeros(len(t_arr))
                for d, l in zip([-h2_hfc, -h2_mr, -h2_tank_in], ['氢燃料电池耗氢', '甲烷发生器耗氢', '储氢罐充氢']):
                    if np.abs(d).sum() > 0: ax.bar(t_arr, d, bottom=bot_neg, label=l, color=c_map.get(l, 'gray'),
                                                   edgecolor='black', width=width, linewidth=0.5); bot_neg += d

                if h2_load.sum() > 0: ax.plot(t_arr, h2_load, color='red', label='氢气负荷', linewidth=2, marker='o',
                                              markerfacecolor='none', markersize=4)
                ax.set_title(title, fontsize=12, fontweight='bold');
                ax.set_ylabel("Mass / kg");
                ax.set_xlim(0, 24)
                ax.grid(True, linestyle='--', alpha=0.5);
                ax.axhline(0, color='black', linewidth=1)

                handles, labels = ax.get_legend_handles_labels()
                if handles:
                    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=4, frameon=True, edgecolor='black',
                              fontsize=9)

            plot_hydrogen(ax7, da_res, t_da, "DA 氢能平衡", 1.0);
            plot_hydrogen(ax8, id_res, t_id, "ID 氢能平衡", dt_id)
            fig_h2.subplots_adjust(bottom=0.25, hspace=0.5)

        plot_export.save_open_figures(f'mscale_{self.scenario}')
        plt.show()


if __name__ == "__main__":
    pass