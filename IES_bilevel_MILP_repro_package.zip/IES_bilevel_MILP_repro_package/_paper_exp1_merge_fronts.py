# -*- coding: utf-8 -*-
"""
小论文 实验1: 三种子合并前沿 + 合并 TOPSIS 推荐协议
====================================================
读取 seed42/43/44 的 `_paper_exp1_fronts[_43|_44].csv`, 取 MILP 臂:
  1) 去重合并   — 容量+目标完全相同的重复解只计一次
  2) 非支配筛选 — 合并前沿上不允许存在被支配点 (TA/AC/TG 全部最小化)
  3) 等权 TOPSIS — 与 sens.py knee_of 同式, 选合并前沿推荐拐点
输出: _paper_exp1_fronts_merged.csv  合并前沿 (含 seed 首发现来源 + found_by)
      _paper_exp1_knee_merged.json   合并 TOPSIS 推荐解
"""
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json
import numpy as np
import pandas as pd

SEEDS = [('', '42'), ('_43', '43'), ('_44', '44')]
COLS = ['TA', 'AC', 'TG', 'X_PV', 'X_Bat', 'X_Tank']


def nondominated_mask(f):
    """f: (n,3) 最小化目标矩阵 — 返回非支配点掩码。"""
    keep = np.ones(len(f), dtype=bool)
    for i in range(len(f)):
        a = f[i]
        dom = np.all(f <= a, axis=1) & np.any(f < a, axis=1)   # j 支配 i (含 i 自身恒 False)
        keep[i] = not dom.any()
    return keep


def main():
    fronts = {}
    for suffix, tag in SEEDS:
        d = pd.read_csv(f'_paper_exp1_fronts{suffix}.csv', encoding='utf-8-sig')
        fronts[tag] = d[d.arm == 'milp'][COLS].reset_index(drop=True)
        print(f'seed{tag}: MILP 前沿 {len(fronts[tag])} 点')

    pool = pd.concat([fronts[t].assign(seed=t) for t in ('42', '43', '44')],
                     ignore_index=True)
    n_raw = len(pool)
    uniq = pool.drop_duplicates(subset=COLS).reset_index(drop=True)
    n_uniq = len(uniq)
    f = uniq[COLS[:3]].to_numpy(dtype=float)
    keep = nondominated_mask(f)
    merged = uniq[keep].reset_index(drop=True)
    n_front = len(merged)

    # 各种子贡献 (首发现口径): 合并前沿每点归入最早发现它的种子
    merged['found_by'] = merged[COLS].round(9).apply(
        lambda row: sum(int((fronts[t][COLS].round(9) == row.to_numpy()).all(
            axis=1).any()) for t in ('42', '43', '44')), axis=1)
    contrib = {t: int((merged['seed'] == t).sum()) for t in ('42', '43', '44')}

    # 等权 TOPSIS (与 knee_of 同式): 三个目标均为最小化
    z = (f[keep] - f[keep].min(0)) / (f[keep].max(0) - f[keep].min(0) + 1e-12)
    d_b = np.sqrt(((z - z.max(0)) ** 2).sum(1))   # 距最差(反理想)
    d_w = np.sqrt(((z - z.min(0)) ** 2).sum(1))   # 距最优(理想)
    k = int(np.argmax(d_w / (d_b + d_w + 1e-12)))
    knee = {c: float(merged.loc[k, c]) for c in COLS}

    merged.to_csv('_paper_exp1_fronts_merged.csv', index=False,
                  encoding='utf-8-sig')
    with open('_paper_exp1_knee_merged.json', 'w', encoding='utf-8') as fp:
        json.dump(knee, fp, ensure_ascii=False, indent=1)

    print(f'\n合并池 {n_raw} 点 → 去重 {n_uniq} 点 → 非支配筛选 {n_front} 点')
    print(f'合并前沿种子贡献 (首发现): '
          f'seed42 {contrib["42"]} / seed43 {contrib["43"]} / seed44 {contrib["44"]}')
    print(f'重复发现度: found_by 分布 '
          f'{merged["found_by"].value_counts().sort_index().to_dict()}')
    print(f'合并 TOPSIS 推荐: PV={knee["X_PV"]:.0f} Bat={knee["X_Bat"]:.0f} '
          f'Tank={knee["X_Tank"]:.0f} | TA={knee["TA"]:,.0f} AC={knee["AC"]:.1f} '
          f'TG={knee["TG"]:,.0f}')
    print('已保存: _paper_exp1_fronts_merged.csv, _paper_exp1_knee_merged.json')


if __name__ == '__main__':
    main()
