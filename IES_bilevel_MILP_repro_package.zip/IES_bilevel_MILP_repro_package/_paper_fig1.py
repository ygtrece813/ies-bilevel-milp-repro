# -*- coding: utf-8 -*-
"""论文图1 (顶刊风格): Essie 全年三负荷 + 四典型日
参考 Liu et al. 2025 J. Energy Storage 图6 版式:
  (a) 全年 8760h 三负荷总览 (细线, 季节互补一目了然)
  (b)-(e) 四典型日 24h 曲线 (聚类命名按成员日月份分布)
Times New Roman, 英文标签, 无粗网格, 语义色全局固定。
轻量: 只读 csv + 聚类 + 画图, 不训练模型。"""
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ---------- 统一风格 (Energy 投稿) ----------
import _paper_figstyle  # noqa: F401

C_ELEC = '#1F77B4'   # 电 蓝
C_HEAT = '#D62728'   # 热 红
C_COOL = '#2CA02C'   # 冷 绿

data_dir = r'C:\Users\i5\load forecast\dataset'
b = 'Fox_office_Essie'
files = {'Electricity': 'electricity.csv', 'Heating': 'hotwater.csv', 'Cooling': 'chilledwater.csv'}
colors = {'Electricity': C_ELEC, 'Heating': C_HEAT, 'Cooling': C_COOL}

# ---------- 读数据: 预测管道重建年 + EUI 锚定重标定 (eui_harmonize.py 输出) ----------
# 与论文方法自洽: 图1 的曲线即 ML 重建 + 量纲校准后的正式输入, 不再直接画原始表计
_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ies_forecast_8760_eui.csv')
df = pd.read_csv(_csv)
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.set_index('timestamp')
m = pd.DataFrame({
    'Electricity': pd.to_numeric(df['Load_Elec'], errors='coerce'),
    'Heating': pd.to_numeric(df['Load_Heat'], errors='coerce'),
    'Cooling': pd.to_numeric(df['Load_Cool'], errors='coerce'),
}).dropna().clip(lower=0)
assert len(m) >= 8000, f'重建年数据不足: {len(m)}'
print(f'重建年数据 (EUI 锚定): {len(m)} h ({m.index[0].date()} ~ {m.index[-1].date()})')

# 各负荷按自身年峰值归一 (p.u.), 消除 BDG2 表计量纲差异; 论文数据处理节再统一单位
for c in m.columns:
    m[c] = m[c] / m[c].max()

# ---------- 聚类 4 典型日 ----------
n_days = len(m) // 24
feat = m.iloc[:n_days * 24].to_numpy().reshape(n_days, 24, 3).transpose(0, 2, 1).reshape(n_days, 72)
from sklearn.cluster import KMeans
km = KMeans(n_clusters=4, random_state=42, n_init=10)
labels = km.fit_predict(feat)
centers = km.cluster_centers_.reshape(4, 3, 24)   # (k, 3负荷, 24h)

# 按成员日的主导月份命名 (冬12-2 / 夏6-8 / 过渡3-5,9-11)
months = m.index.month.to_numpy()[:n_days * 24].reshape(n_days, 24)[:, 0]
def name_of(k):
    mm = months[labels == k]
    winter = np.isin(mm, [12, 1, 2]).mean()
    summer = np.isin(mm, [6, 7, 8]).mean()
    if winter >= 0.5: return 'Winter-type'
    if summer >= 0.5: return 'Summer-type'
    if winter > summer: return 'Transition-type (cold)'
    return 'Transition-type (warm)'
names = {k: name_of(k) for k in range(4)}
counts = {k: int((labels == k).sum()) for k in range(4)}
for k in range(4):
    print(f'  cluster {k}: {names[k]:26s} {counts[k]:3d} days')

# 排版顺序: 冬 → 冷过渡 → 夏 → 暖过渡
order = sorted(range(4), key=lambda k: {'Winter-type': 0, 'Transition-type (cold)': 1,
                                        'Summer-type': 2, 'Transition-type (warm)': 3}[names[k]])

# ---------- 画图: 上面全年总览 (a), 下面四典型日 (b)-(e) ----------
fig = plt.figure(figsize=(7.2, 8.2))
gs = fig.add_gridspec(3, 2, height_ratios=[1.15, 1, 1], hspace=0.45, wspace=0.28)

# (a) 全年日均值 + min-max 包络带 (365天尺度, 季节翻转清晰)
ax = fig.add_subplot(gs[0, :])
daily = m.resample('D').mean()          # (365, 3)
dmin = m.resample('D').min()
dmax = m.resample('D').max()
td = np.arange(len(daily))
for name in ['Heating', 'Cooling', 'Electricity']:
    ax.fill_between(td, dmin[name], dmax[name], color=colors[name], alpha=0.18, lw=0)
    ax.plot(td, daily[name], color=colors[name], lw=1.1, label=name)
ax.set_xlim(0, len(daily) - 1)
ax.set_ylim(0, 1.02)
# 图名置于横轴标签下方 (对齐 Liu et al. 2025 图6 版式: 顶部无标题, (a)…(e) 图名居中在下)
# 轴标题文字降两号 (10→8), 图名保持 10 并上移, 弥补轴标题缩小后的空隙
ax.set_xlabel('Day of year', fontsize=8)
ax.set_ylabel('Normalized load (p.u.)', fontsize=8)
ax.annotate('(a) Annual cooling, heating and electricity load',
            xy=(0.5, 0), xycoords='axes fraction', xytext=(0, -27),
            textcoords='offset points', ha='center', va='top', fontsize=10)
# 月刻度
ax.set_xticks([0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334])
ax.set_xticklabels(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
ax.legend(loc='upper center', bbox_to_anchor=(0.5, 1.22), ncol=3,
          handlelength=1.6, columnspacing=1.4)
ax.annotate('Heating season', xy=(28, daily['Heating'].iloc[20:50].max() + 0.10),
            fontsize=8.5, color=C_HEAT)
ax.annotate('Cooling season', xy=(190, daily['Cooling'].iloc[170:220].max() + 0.10),
            fontsize=8.5, color=C_COOL)

# (b)-(e) 四典型日
hours = np.arange(24)
panels = 'bcde'
for i, k in enumerate(order):
    ax = fig.add_subplot(gs[1 + i // 2, i % 2])
    for j, name in enumerate(['Electricity', 'Heating', 'Cooling']):
        ax.plot(hours, centers[k, j], color=colors[name], lw=1.4,
                label=name if i == 0 else None)
    ax.set_xlim(0, 23)
    ax.set_ylim(0, 1.02)
    ax.set_xticks(range(0, 25, 4))
    ax.set_xlabel('Time (h)', fontsize=8)
    ax.set_ylabel('Normalized load (p.u.)', fontsize=8)
    ax.annotate(f'({panels[i]}) {names[k]} typical day ({counts[k]} d)',
                xy=(0.5, 0), xycoords='axes fraction', xytext=(0, -27),
                textcoords='offset points', ha='center', va='top', fontsize=10)

handles, _ = ax.get_legend_handles_labels()
fig.legend(handles, ['Electricity', 'Heating', 'Cooling'], loc='upper center',
           ncol=3, bbox_to_anchor=(0.5, 0.985), handlelength=1.6)

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), '论文图片/图1_负荷特性与典型日.png')
fig.savefig(out, dpi=300, bbox_inches='tight')
print(f'已保存: {out}')

# 附: 簇-月份分布表 (论文正文用)
print('\n簇成员月份分布 (%):')
hdr = 'cluster'.ljust(28) + ''.join(f'{mo:>5d}' for mo in range(1, 13))
print(hdr)
for k in order:
    mm = months[labels == k]
    row = names[k].ljust(28)
    row += ''.join(f'{np.isin(mm, [mo]).mean()*100:5.0f}' for mo in range(1, 13))
    print(row)
