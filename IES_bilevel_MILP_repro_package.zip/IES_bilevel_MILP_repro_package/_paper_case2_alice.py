# -*- coding: utf-8 -*-
"""
小论文 补充实验 B: 第二案例 (Fox_office_Alice) 数据管道驱动
==========================================================
复刻 ies_load_forecast_bridge.py CLI --export 的 reconstruct 流程
(一步预测 + 真实滞后锚定重建最近整年, 与 Essie 主案例口径逐字一致),
但按输入名独立落盘, 不覆盖 Essie 主案例文件:

    ies_forecast_8760_alice.csv          ML 重建全年曲线 (原始量纲)
    ies_forecast_8760_alice_eui.csv      EUI 锚定重标定曲线
    ies_forecast_contract_alice_eui.pkl  重标定契约 (实验 1 双臂输入)

场址选择依据 (clean_target_pool.csv): Alice 为 Fox 办公建筑群中重建质量
最高的场址 (grade A, 电/冷/热 WAPE 0.6/2.0/1.4, R² 0.97/1.00/0.99,
优于 Essie 本身的 3.3/6.3/7.4), 面积 18,807 m² (Essie 的 1.54 倍) —
规模差异 + 更高质量, 适合作为第二验证案例。
"""
import sys
import os

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import ies_load_forecast_bridge as br
import eui_harmonize

BUILDING = 'Fox_office_Alice'
DATA_DIR = eui_harmonize.DATA_DIR


def main():
    print(f'===== 第二案例数据管道: {BUILDING} =====')

    # 1-2. 特征工程 + 训练 (reconstruct: 窗口前数据训练, 严格留出)
    df, hist_len, targets, scaler = br.build_feature_frame(DATA_DIR, BUILDING, 8760)
    train_end, window = br.compute_train_window(hist_len, 'reconstruct', 8760)
    print(f'负荷流: {targets} | 历史 {hist_len} 行 | 训练 {train_end} 行 | 重建 {window}h')
    model, features = br.train_model(df, train_end, targets, scaler)

    # 3. 全年重建曲线 (与 CLI --export 完全同参)
    preds, start = br.reconstruct_recent_year(model, scaler, targets, features,
                                              df, hist_len, window)
    import pandas as pd
    out = pd.DataFrame({'timestamp': df['timestamp'].iloc[start:start + len(preds)]
                        .reset_index(drop=True)})
    for j, t in enumerate(targets):
        out[t] = preds[:, j]
    csv_raw = 'ies_forecast_8760_alice.csv'
    out.to_csv(csv_raw, index=False, encoding='utf-8-sig')
    print(f'\nML 重建曲线: {csv_raw} ({len(out)}h, 列 {list(out.columns)})')

    # 4-5. EUI 锚定重标定 + 重聚类 + 风光合成 + 契约落盘 (输出名自动派生)
    contract = eui_harmonize.harmonize(csv_raw, data_dir=DATA_DIR, building=BUILDING)
    print(f'\n✅ 契约典型日权重: {contract["typical_days"]}')
    print('✅ 第二案例管道完成, 可交实验 1 双臂对照')


if __name__ == '__main__':
    main()
