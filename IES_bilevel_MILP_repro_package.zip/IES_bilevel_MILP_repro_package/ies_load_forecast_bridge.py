"""
IES 负荷预测桥接模块 (ies_load_forecast_bridge.py)
================================================================
把 load forecast 项目的多任务 XGBoost 冷热电联合负荷预测
接入 IES 综合能源优化与调度系统。

对外核心接口:
    generate_ies_dataset(data_dir, building) -> load_interface_data
    返回符合 IES 数据契约的典型日矩阵字典, 可直接赋给 GUI 的 self.custom_dataset。

流程:
    1. 读取 BDG2 格式数据集 (metadata.csv / weather.csv / 负荷 csv)
    2. 特征工程 (与 load-forecast/data_preprocessing.py 定稿方案完全一致)
    3. 训练多任务 XGBoost (multi_strategy='one_output_per_tree')
    4. 重建最近一个整年 8760 小时 电/冷/热(/气) 全年曲线 (一步预测 + 真实滞后锚定)
    5. KMeans 聚成 4 类典型日
    6. 组装 load_interface_data 契约

用法:
    python ies_load_forecast_bridge.py <dataset_dir> <building_id> [--export]
    python ies_load_forecast_bridge.py <dataset_dir> --list
    python ies_load_forecast_bridge.py "C:/Users/i5/load forecast/dataset" Fox_office_Essie --export

说明:
    - 默认 mode='reconstruct': 模型一步预测 + 真实滞后重建最近整年, 形状/量级
      与泛化定稿报告验证指标一致, 适合 IES 容量规划。纯递归外推对强季节性负荷
      会 regime 不翻转 (热锁死/冷塌缩), 故不默认使用。
    - 本模块自包含, 不依赖 load forecast 项目路径, 可独立运行。
"""
import os
import sys
import argparse
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from xgboost import XGBRegressor

# Windows GBK 控制台无法编码 emoji, 用 replace 兜底保证 CLI 不崩 (中文仍正常)
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(errors='replace')
    except Exception:
        pass

# ==================================================================
# 定稿方案: 与 load-forecast 完全一致的超参与特征工程
# ==================================================================
LOAD_SOURCES = [
    ('Load_Elec', 'electricity.csv'),
    ('Load_Cool', 'chilledwater.csv'),
    ('Load_Heat', 'hotwater.csv'),
    ('Load_Gas', 'gas.csv'),
]
BASE = ['airTemperature', 'dewTemperature', 'windSpeed', 'hour', 'day_of_week', 'is_weekend', 'month',
        'temp_lag_1h', 'temp_lag_2h', 'temp_rolling_3h_avg', 'temp_rolling_24h_avg', 'hdd', 'cdd',
        'relative_humidity', 'temp_x_hour', 'temp_change_24h']
LAG_SUFFIXES = ['lag1h', 'lag2h', 'lag24h', 'lag48h', 'lag168h', 'roll3h', 'roll6h']
PARAMS = dict(n_estimators=600, learning_rate=0.03, max_depth=8, subsample=0.9, colsample_bytree=0.8,
              min_child_weight=2, reg_lambda=1.0, random_state=42, tree_method='hist',
              multi_strategy='one_output_per_tree', n_jobs=1, verbosity=0)

# IES 默认分时电价 (0-6谷 0.25, 7-9平 0.5, 10-14峰 0.75, 15-17平 0.5, 18-20峰 0.75, 21-23平 0.5)
TOU_PRICE = np.array([0.25] * 7 + [0.50] * 3 + [0.75] * 5 + [0.50] * 3 + [0.75] * 3 + [0.50] * 3)

# 负荷 -> IES 母线
BUS_OF_TARGET = {'Load_Elec': 'ElectricityBus', 'Load_Heat': 'HeatBus',
                 'Load_Cool': 'CoolBus', 'Load_Gas': 'GasBus'}
ALL_BUSES = ['ElectricityBus', 'HeatBus', 'CoolBus', 'GasBus', 'HydrogenBus']


# ==================================================================
# 1. 数据与特征工程
# ==================================================================
def detect_targets(data_dir, building):
    """动态探测该建筑有哪些负荷流 (与 data_preprocessing 的探测逻辑一致)。"""
    targets = []
    for name, csv_file in LOAD_SOURCES:
        try:
            header = pd.read_csv(os.path.join(data_dir, csv_file), nrows=0).columns.tolist()
        except FileNotFoundError:
            continue
        if building in header:
            targets.append(name)
    return targets


def get_forecast_weather(weather_df, site_id, hist_end_ts, n=8760):
    """取目标站气象, 时间戳从历史末尾之后连续 n 小时。

    若该站气象记录不够长, 用自身季节模式循环补足 (容量规划只需形状)。
    """
    w = weather_df[weather_df['site_id'] == site_id].copy()
    w['timestamp'] = pd.to_datetime(w['timestamp'])
    w = w.sort_values('timestamp').reset_index(drop=True)
    if len(w) == 0:
        raise ValueError(f'site_id={site_id} 在 weather.csv 中无记录')
    tail = w[w['timestamp'] > hist_end_ts].reset_index(drop=True)
    src = tail if len(tail) > 0 else w
    cycles = (n // len(src)) + 1
    wf = pd.concat([src[['airTemperature', 'dewTemperature', 'windSpeed']]] * cycles,
                   ignore_index=True).iloc[:n].copy().reset_index(drop=True)
    wf['timestamp'] = pd.date_range(start=hist_end_ts + pd.Timedelta(hours=1), periods=n, freq='h')
    return wf


def build_feature_frame(data_dir, building, forecast_hours=8760):
    """构造 [历史 + 未来8760h] 合并特征帧。

    返回 (combined, hist_len, target_names, scaler):
      - combined: 含全部特征列; 历史行目标/滞后特征为真实值, 未来行目标为 NaN、滞后特征 NaN(待递归填充)
      - scaler: 只在历史目标上 fit, 供训练/反归一化使用
    """
    meta = pd.read_csv(os.path.join(data_dir, 'metadata.csv'))
    weather = pd.read_csv(os.path.join(data_dir, 'weather.csv'))

    targets = detect_targets(data_dir, building)
    if not targets:
        raise ValueError(f'建筑 {building} 在所有负荷文件里都不存在, 请检查建筑名。')

    # ---- 历史负荷 + 气象合并 ----
    hist = None
    for name in targets:
        csv_file = dict(LOAD_SOURCES)[name]
        sub = pd.read_csv(os.path.join(data_dir, csv_file), usecols=['timestamp', building])
        sub = sub.rename(columns={building: name})
        hist = sub if hist is None else pd.merge(hist, sub, on='timestamp', how='inner')
    hist['timestamp'] = pd.to_datetime(hist['timestamp'])

    site_id = meta.loc[meta['building_id'] == building, 'site_id'].values[0]
    w = weather[weather['site_id'] == site_id].copy()
    w['timestamp'] = pd.to_datetime(w['timestamp'])
    hist = pd.merge(hist, w[['timestamp', 'airTemperature', 'dewTemperature', 'windSpeed']],
                    on='timestamp', how='inner')
    hist = hist.sort_values('timestamp').reset_index(drop=True)

    # ---- 未来 8760h 气象 ----
    fw = get_forecast_weather(weather, site_id, hist['timestamp'].iloc[-1], forecast_hours)
    fut = pd.concat([fw, pd.DataFrame(np.nan, index=range(forecast_hours),
                                      columns=[t for t in targets if t not in fw.columns])], axis=1)

    # ---- 合并, 统一做特征工程 ----
    df = pd.concat([hist, fut], ignore_index=True)

    # 日历与时间特征
    df['hour'] = df['timestamp'].dt.hour
    df['day_of_week'] = df['timestamp'].dt.dayofweek
    df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)
    df['month'] = df['timestamp'].dt.month

    # 气象滞后/热惯性特征 (对未来段, 边界处自然衔接历史气象)
    df['temp_lag_1h'] = df['airTemperature'].shift(1)
    df['temp_lag_2h'] = df['airTemperature'].shift(2)
    df['temp_rolling_3h_avg'] = df['airTemperature'].rolling(3).mean()
    df['temp_rolling_24h_avg'] = df['airTemperature'].rolling(24).mean()

    # 度日数与湿度
    df['hdd'] = np.maximum(0, 18 - df['airTemperature'])
    df['cdd'] = np.maximum(0, df['airTemperature'] - 22)
    e_t = 6.1094 * np.exp(17.625 * df['airTemperature'] / (df['airTemperature'] + 243.04))
    e_d = 6.1094 * np.exp(17.625 * df['dewTemperature'] / (df['dewTemperature'] + 243.04))
    df['relative_humidity'] = 100 * e_d / e_t
    df['temp_x_hour'] = df['airTemperature'] * df['hour'] / 24
    df['temp_change_24h'] = df['airTemperature'] - df['airTemperature'].shift(24)

    # 自回归滞后特征 (未来段为 NaN, 递归时填充)
    for t in targets:
        df[f'{t}_lag1h'] = df[t].shift(1)
        df[f'{t}_lag2h'] = df[t].shift(2)
        df[f'{t}_lag24h'] = df[t].shift(24)
        df[f'{t}_lag48h'] = df[t].shift(48)
        df[f'{t}_lag168h'] = df[t].shift(168)
        df[f'{t}_roll3h'] = df[t].rolling(3).mean()
        df[f'{t}_roll6h'] = df[t].rolling(6).mean()

    # ---- 归一化: 只在历史目标上 fit (纯 numpy, 不带列名) ----
    hist_len = len(hist)
    scaler = MinMaxScaler()
    scaler.fit(df.iloc[:hist_len][targets].values)

    return df, hist_len, targets, scaler


def train_model(df, train_end, targets, scaler):
    """在 df.iloc[:train_end] 上训练多任务 XGBoost (one_output_per_tree)。"""
    features = BASE + [f'{t}_{s}' for t in targets for s in LAG_SUFFIXES]
    train = df.iloc[:train_end].copy()
    train[targets] = scaler.transform(train[targets].values)

    X = train[features]
    y = train[targets]
    mask = X.notna().all(axis=1) & y.notna().all(axis=1)
    X, y = X[mask], y[mask]

    model = XGBRegressor(**PARAMS)
    model.fit(X, y)
    return model, features


def reconstruct_recent_year(model, scaler, targets, features, df, hist_len, forecast_hours=8760):
    """【推荐】用模型一步预测重建最近一个整年的全年曲线 (真实滞后锚定)。

    为什么不用纯递归:
        递归把模型自己上一时刻的输出当滞后, 误差逐时累积。
        对强季节性负荷会热负荷锁死全年高输出、冷负荷塌缩到 0 (regime 永不翻转),
        量级/形状完全失真。一步预测 + 真实滞后是模型被验证过的能力
        (Fox_office_Essie: 电2.4% / 冷6.3% / 热6.5% WAPE), 重建年的形状与量级
        天然与验证指标一致 —— 正是 IES 容量规划需要的"全年情景"。

    window: 最近 min(8760, hist_len-200) 小时, 由历史中靠前的数据训练(严格留出)。
    返回 (preds_raw_kw, start_index)。
    """
    window = min(forecast_hours, hist_len - 200)
    start = hist_len - window
    X = df[features].iloc[start:hist_len].to_numpy(dtype=float)

    # 窗口内滞后特征已在 build_feature_frame 中用真实负荷算好, 理论上无 NaN, 做安全兜底
    preds = np.full((window, len(targets)), np.nan)
    valid = ~np.isnan(X).any(axis=1)
    if valid.any():
        p = np.asarray(model.predict(X[valid]))
        if p.ndim == 1:                              # 单负荷流建筑: xgboost predict 返回 1D
            p = p.reshape(-1, 1)
        p = np.clip(p, 0, None)
        preds[valid] = p
    preds = scaler.inverse_transform(preds)          # 还原真实 kW
    preds = np.clip(preds, 0, None)
    # 兜底: 若窗口头部因滞后不足出现 NaN, 用前一行回填
    for i in range(1, window):
        if np.isnan(preds[i]).any():
            preds[i] = preds[i - 1]
    return preds, start


def recursive_forecast(model, scaler, targets, features, df, hist_len, forecast_hours=8760):
    """【实验】逐小时纯递归外推 8760h。

    已知缺陷: 对强季节性负荷 regime 不翻转 (热锁死/冷塌缩), 仅供研究对比,
    GUI 默认走 reconstruct_recent_year。
    """
    feat_names = features
    X = df[feat_names].iloc[hist_len:hist_len + forecast_hours].to_numpy(dtype=float).copy()
    col_pos = {name: i for i, name in enumerate(feat_names)}
    lag_pos = {t: {s: col_pos[f'{t}_{s}'] for s in LAG_SUFFIXES} for t in targets}

    seed = df.iloc[hist_len - 168:hist_len][targets].to_numpy(dtype=float)
    recent = {t: [seed[i, j] for i in range(len(seed)) if not np.isnan(seed[i, j])]
              for j, t in enumerate(targets)}

    n = len(X)
    preds = np.zeros((n, len(targets)))
    for i in range(n):
        row = X[i]
        for j, t in enumerate(targets):
            r = recent[t]
            lp = lag_pos[t]
            row[lp['lag1h']] = r[-1] if len(r) >= 1 else 0.0
            row[lp['lag2h']] = r[-2] if len(r) >= 2 else 0.0
            row[lp['lag24h']] = r[-24] if len(r) >= 24 else 0.0
            row[lp['lag48h']] = r[-48] if len(r) >= 48 else 0.0
            row[lp['lag168h']] = r[-168] if len(r) >= 168 else 0.0
            row[lp['roll3h']] = np.mean(r[-3:]) if len(r) >= 3 else 0.0
            row[lp['roll6h']] = np.mean(r[-6:]) if len(r) >= 6 else 0.0
        p = np.asarray(model.predict(row[None, :]))
        if p.ndim == 1:                              # 单负荷流建筑: 补成 2D (1, n_targets)
            p = p.reshape(1, -1)
        p = np.clip(scaler.inverse_transform(p), 0, None)
        preds[i] = p[0]
        for j, t in enumerate(targets):
            recent[t].append(p[0, j])
    return preds


def cluster_typical_days(preds, targets):
    """把全年曲线按天 KMeans 聚类, 返回 (labels, centers)。

    centers: (K, 24*n_targets), 顺序 = targets 顺序, K = min(4, 实际天数)。
    """
    n_days = preds.shape[0] // 24
    if n_days == 0:
        n_days = 1
    arr = np.column_stack([preds[:n_days * 24, j].reshape(n_days, 24)
                           for j in range(len(targets))])
    n_clusters = min(4, n_days)
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = kmeans.fit_predict(arr)
    return labels, kmeans.cluster_centers_


# ==================================================================
# 2. 对外核心接口: 一键生成 IES 契约
# ==================================================================
def _wind_power_curve(ws):
    """风速(m/s) -> 归一化风机出力 (切入3 / 额定12 / 切出25)。"""
    ws = np.asarray(ws, dtype=float)
    p = np.zeros_like(ws)
    mid = (ws >= 3) & (ws < 12)
    p[mid] = (ws[mid] ** 3 - 27.0) / (12.0 ** 3 - 27.0)
    p[ws >= 12] = 1.0
    p[ws > 25] = 0.0
    return np.clip(p, 0, 1)


def _fit_length(arr, n):
    """截取/循环补齐到长度 n (优先取最近一段, 与重建窗口同期)。"""
    if len(arr) >= n:
        return arr[-n:]
    reps = int(np.ceil(n / max(len(arr), 1)))
    return np.tile(arr, reps)[:n]


def synth_pv_wind_hourly(data_dir, building, n_hours):
    """由场址逐时气象合成 PV/风机出力曲线 (归一化峰值1), 返回 (pv, wind)。

    工程背景: 真实落地项目拿不到现成的风光出力曲线, 容量规划必须由系统
    按场址气象自动合成 —— 负荷数据只决定需求侧, 资源侧来自气象:
      PV   = 晴空几何钟形 × 季节日照 × 云量衰减(Kasten) × 高温降额
      Wind = 风速 -> 功率曲线
    """
    meta = pd.read_csv(os.path.join(data_dir, 'metadata.csv'))
    site_id = meta.loc[meta['building_id'] == building, 'site_id'].values[0]
    w = pd.read_csv(os.path.join(data_dir, 'weather.csv'))
    w = w[w['site_id'] == site_id].copy()
    w['timestamp'] = pd.to_datetime(w['timestamp'])
    w = w.sort_values('timestamp').reset_index(drop=True)
    if len(w) == 0:
        raise ValueError(f'site_id={site_id} 在 weather.csv 中无记录')

    # ---- 风电: 风速插值补缺 -> 功率曲线 ----
    ws = w['windSpeed'].interpolate(limit_direction='both').fillna(0.0).clip(lower=0).to_numpy()
    wind = _wind_power_curve(ws)

    # ---- PV: 云量/气温插值补缺, 按 (月日照时长) 生成晴空钟形 ----
    cc = (w['cloudCoverage'].interpolate(limit_direction='both').fillna(0.0).clip(0, 1).to_numpy()
          if 'cloudCoverage' in w.columns else np.zeros(len(w)))
    ta = w['airTemperature'].interpolate(limit_direction='both').fillna(15.0).to_numpy()
    mon = w['timestamp'].dt.month.to_numpy()
    hr = w['timestamp'].dt.hour.to_numpy()

    daylight = {1: 9.8, 2: 10.7, 3: 12.0, 4: 13.2, 5: 14.2, 6: 14.7,
                7: 14.4, 8: 13.6, 9: 12.6, 10: 11.4, 11: 10.3, 12: 9.9}
    L = np.array([daylight[m] for m in mon])
    sun_alt = 0.45 + 0.55 * (L / 14.7)          # 季节太阳高度代理 (夏1.0/冬~0.82)
    sr = 12.0 - L / 2.0                          # 日出时刻
    x = (hr + 0.5 - sr) / L                      # 白天内相对位置 0~1
    day = (x > 0) & (x < 1)
    clear = np.zeros(len(w))
    clear[day] = np.sin(np.pi * x[day])
    cloud_f = 1.0 - 0.75 * cc ** 1.5             # Kasten-Czeplak 云量衰减
    temp_f = np.clip(1.0 - 0.003 * (ta - 25.0), 0.85, 1.0)   # 高温降额
    pv = clear * sun_alt * cloud_f * temp_f

    pv_n = pv.max()
    wind_n = wind.max()
    return (_fit_length(pv / pv_n, n_hours) if pv_n > 0 else np.zeros(n_hours),
            _fit_length(wind / wind_n, n_hours) if wind_n > 0 else np.zeros(n_hours))


def assemble_contract(preds, targets, labels, centers, pv_hourly=None, wind_hourly=None):
    """把全年曲线 + KMeans 结果组装成 load_interface_data 契约字典。

    pv_hourly/wind_hourly: 场址气象合成的全年归一化出力曲线 (峰值1, 长度>=n_days*24)。
      每个典型日的 profile = 该类成员日的 24h 均值 (保留晴/阴天差异)。
    """
    n_clusters = centers.shape[0]
    n_days = len(labels)
    data = {
        "typical_days": {},
        "price_elec": {},
        "profiles": {"PV": {}, "Wind": {}},
        "loads": {bus: {} for bus in ALL_BUSES},
    }
    for k in range(n_clusters):
        day_name = f"Typical_Season_{k + 1}"
        count = int(np.sum(labels == k))
        data["typical_days"][day_name] = count
        data["price_elec"][day_name] = TOU_PRICE.copy()
        for name, series in (("PV", pv_hourly), ("Wind", wind_hourly)):
            if series is not None and len(series) >= n_days * 24:
                member = series[:n_days * 24].reshape(n_days, 24)[labels == k]
                data["profiles"][name][day_name] = member.mean(axis=0)
            else:
                data["profiles"][name][day_name] = np.zeros(24)
        for j, t in enumerate(targets):
            data["loads"][BUS_OF_TARGET[t]][day_name] = centers[k, j * 24:(j + 1) * 24]
        for bus in ALL_BUSES:
            if day_name not in data["loads"][bus]:
                data["loads"][bus][day_name] = np.zeros(24)
    return data


def compute_train_window(hist_len, mode, forecast_hours=8760):
    """返回 (train_end, window): 训练截止行号 与 全年曲线窗口小时数。

    reconstruct: 用最近一个整年留出重建; 历史不足则退化为全量训练。
    """
    if mode == 'reconstruct':
        window = min(forecast_hours, hist_len - 200)
        train_end = hist_len - window
        if train_end < 500:  # 历史太短 (非整年楼), 退化为全量训练重建, 接受轻微泄漏
            train_end = hist_len
        return train_end, window
    return hist_len, forecast_hours


def generate_ies_dataset(data_dir, building, mode='reconstruct', forecast_hours=8760):
    """核心入口。输入数据集目录 + 建筑, 返回 load_interface_data 字典。

    mode:
      - 'reconstruct' (默认, 推荐): 模型一步预测重建最近一个整年, 真实滞后锚定,
        形状/量级与验证指标一致 (泛化定稿报告: 电中位WAPE 3.4% / 冷 7.3% / 热 14.5%)。
      - 'recursive' (实验): 纯递归外推下一年, 强季节性负荷会 regime 不翻转, 不推荐。
    """
    print(f'\n{"=" * 60}')
    print(f'🎯 [负荷预测桥接] 建筑: {building} ｜ 模式: {mode}')
    print(f'{"=" * 60}')

    # 1. 特征工程 + 2. 训练 (重建模式: 用窗口前数据训练, 严格留出, 不泄漏)
    df, hist_len, targets, scaler = build_feature_frame(data_dir, building, forecast_hours)
    train_end, window = compute_train_window(hist_len, mode, forecast_hours)
    train_msg = (f'训练 {train_end} 行 ｜ 重建最近 {window} 小时 (留出)'
                 if mode == 'reconstruct' else
                 f'训练 {train_end} 行 ｜ 递归外推 {window} 小时')
    print(f'  探测负荷流: {targets} ｜ 历史 {hist_len} 行 ｜ {train_msg}')
    model, features = train_model(df, train_end, targets, scaler)
    print('  多任务 XGBoost 训练完成 (one_output_per_tree)')

    # 3. 全年曲线
    if mode == 'reconstruct':
        preds, _start = reconstruct_recent_year(model, scaler, targets, features, df, hist_len, forecast_hours)
    else:
        preds = recursive_forecast(model, scaler, targets, features, df, hist_len, forecast_hours)
    year_curves = {t: preds[:, j] for j, t in enumerate(targets)}
    print(f'  全年 {len(preds)}h 曲线生成完毕')

    # 4. KMeans 典型日 + 4.5 场址气象合成风光 + 5. 组装契约
    labels, centers = cluster_typical_days(preds, targets)
    try:
        pv_h, wind_h = synth_pv_wind_hourly(data_dir, building, len(preds))
        print(f'  风光出力由场址气象自动合成: PV 峰值因子 {pv_h.max():.2f} | '
              f'风电容量因子 {wind_h.mean():.1%}')
    except Exception as e:
        pv_h = wind_h = None
        print(f'  ⚠ 风光合成失败({e}), profiles 置零')
    data = assemble_contract(preds, targets, labels, centers, pv_hourly=pv_h, wind_hourly=wind_h)

    # 汇总打印
    print(f'\n  典型日聚类: {data["typical_days"]}')
    for t in targets:
        c = year_curves[t]
        bus = BUS_OF_TARGET[t]
        print(f'  [{bus:<14s}] 年峰值 {c.max():9.1f} kW | 年均值 {c.mean():8.1f} kW | 峰值时刻 '
              f'{int(np.argmax(c) % 24):02d}:00')
    for name in ('PV', 'Wind'):
        peaks = {d: round(float(v.max()), 2) for d, v in data['profiles'][name].items()}
        print(f'  [profile {name:<4s}] 各典型日峰值因子: {peaks}')
    print(f'  ✅ 契约生成完毕, 典型日: {4} 类')
    return data


# ==================================================================
# 3. CLI 入口 (独立测试用)
# ==================================================================
def main():
    parser = argparse.ArgumentParser(description='IES 负荷预测桥接: 生成 load_interface_data')
    parser.add_argument('data_dir', help='BDG2 数据集目录 (含 metadata.csv/weather.csv/负荷csv)')
    parser.add_argument('building', help='建筑 ID, 如 Fox_office_Essie')
    parser.add_argument('--list', action='store_true', help='仅列出数据集内可用建筑')
    parser.add_argument('--export', action='store_true', help='额外落盘全年曲线与契约')
    parser.add_argument('--mode', default='reconstruct', choices=['reconstruct', 'recursive'],
                        help='全年曲线生成方式 (默认 reconstruct)')
    args = parser.parse_args()

    if args.list:
        meta = pd.read_csv(os.path.join(args.data_dir, 'metadata.csv'))
        buildings = sorted(meta['building_id'].tolist())
        print(f'数据集内共 {len(buildings)} 栋建筑:')
        for b in buildings:
            tg = detect_targets(args.data_dir, b)
            print(f'  {b:32s} 负荷流: {tg}')
        return

    data = generate_ies_dataset(args.data_dir, args.building, mode=args.mode)

    if args.export:
        df, hist_len, targets, scaler = build_feature_frame(args.data_dir, args.building)
        train_end, window = compute_train_window(hist_len, args.mode)
        model, features = train_model(df, train_end, targets, scaler)
        if args.mode == 'reconstruct':
            preds, start = reconstruct_recent_year(model, scaler, targets, features, df, hist_len, window)
            out = pd.DataFrame({'timestamp': df['timestamp'].iloc[start:start + len(preds)].reset_index(drop=True)})
        else:
            preds = recursive_forecast(model, scaler, targets, features, df, hist_len, window)
            out = pd.DataFrame({'timestamp': df['timestamp'].iloc[hist_len:hist_len + len(preds)].reset_index(drop=True)})
        for j, t in enumerate(targets):
            out[t] = preds[:, j]
        out.to_csv('ies_forecast_8760.csv', index=False, encoding='utf-8-sig')
        print(f'\n  全年曲线已保存: ies_forecast_8760.csv')
        joblib.dump(data, 'ies_forecast_contract.pkl')
        print(f'  契约已保存: ies_forecast_contract.pkl')


if __name__ == '__main__':
    main()
