# -*- coding: utf-8 -*-
"""
图2 (2D 投影) 重绘脚本 —— 免重跑实验
=====================================
从 `_paper_exp1_fronts[_TAG].csv` + `_paper_exp1_knee[_TAG].json` 直接重绘
图2 的三联 2D 投影 (TA-AC / TA-TG / AC-TG), 绘图代码与 _paper_exp1_compare.py
完全同式, 仅风格走 _paper_figstyle。用法:
  python _paper_fig2d_replot.py          # 主案例
  python _paper_fig2d_replot.py alice    # 第二案例
"""
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json
import pandas as pd
import _paper_figstyle  # noqa: F401  (统一风格)
import matplotlib.pyplot as plt

TAG = sys.argv[1] if len(sys.argv) > 1 else ''
_T = f'_{TAG}' if TAG else ''
df = pd.read_csv(f'_paper_exp1_fronts{_T}.csv', encoding='utf-8-sig')
front_rule = df[df.arm == 'rule'][['TA', 'AC', 'TG']].to_numpy()
front_milp = df[df.arm == 'milp'][['TA', 'AC', 'TG']].to_numpy()
knee = json.load(open(f'_paper_exp1_knee{_T}.json', encoding='utf-8'))

pairs = [(0, 1, 'TA (CNY)', 'AC (t)'),
         (0, 2, 'TA (CNY)', 'TG (kWh)'),
         (1, 2, 'AC (t)', 'TG (kWh)')]
KO = [knee['TA'], knee['AC'], knee['TG']]
fig, axes = plt.subplots(1, 3, figsize=(7.5, 2.9))
for ax, (i, j, xl, yl) in zip(axes, pairs):
    ax.scatter(front_rule[:, i], front_rule[:, j], s=22, facecolors='none',
               edgecolors='#D62728', linewidths=1.0, label='Fixed TOU strategy')
    ax.scatter(front_milp[:, i], front_milp[:, j], s=22, color='#1F77B4',
               label='Nested MILP (proposed)')
    ax.scatter([KO[i]], [KO[j]], marker='*', s=380, c='#FFD700',
               edgecolors='#8B6914', linewidths=0.8, zorder=6,
               label='TOPSIS recommended')
    ax.set_xlabel(xl)
    ax.set_ylabel(yl)
# 三面板共用一条顶部横排图例 (逐面板 loc='best' 会压住散点)
_h, _l = axes[0].get_legend_handles_labels()
fig.legend(_h, _l, ncol=3, loc='upper center', bbox_to_anchor=(0.5, 1.0),
           frameon=False, handlelength=1.2, columnspacing=1.2)
fig.tight_layout(rect=(0, 0, 1, 0.92))
fig.savefig(f'论文图片/图2_实验1_Pareto前沿对比{_T}.png', dpi=300,
            bbox_inches='tight')
print(f'已保存: 论文图片/图2_实验1_Pareto前沿对比{_T}.png '
      f'(规则 {len(front_rule)} 点 | MILP {len(front_milp)} 点)')
