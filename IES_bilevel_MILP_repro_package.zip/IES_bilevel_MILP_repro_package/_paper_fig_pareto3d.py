# -*- coding: utf-8 -*-
"""
小论文 图6/图9: 三维 Pareto 前沿对比 (Energy 投稿核心亮点图)
=============================================================
读取实验1种子42主运行输出 `_paper_exp1_fronts.csv`, 绘制规则基线 vs 嵌套MILP
两前沿的三维目标空间 (TA/AC/TG)。对应正文 5.1 节主实验 (单种子受控对照, 表5
同口径); 多种子合并前沿协议 (5.4节) 仅取数于合并 CSV/JSON, 不作图。

风格对齐顶刊范式 (Liu et al. 2025, J. Energy Storage 图8):
  - 小号密排散点构成前沿流形 (不加拉线/曲面修饰);
  - TOPSIS 推荐解以星标高亮, 并在其旁标注坐标三元组;
  - 浅灰 3D 箱体 + 细网格, 刻度朝内, 图例置左上。

案例变体 (argv[1], 如 alice): 读 _paper_exp1_fronts_<tag>.csv, 输出独立文件
(图9, 亦为单种子口径)。

输出: 论文图片/图2_实验1_Pareto前沿对比[_TAG]_3D.png (图6/图9 为其图号副本)
"""
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json
import numpy as np
import pandas as pd
import _paper_figstyle  # noqa: F401  (统一风格)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

df = pd.read_csv('_paper_exp1_fronts.csv', encoding='utf-8-sig')
r = df[df.arm == 'rule']
m = df[df.arm == 'milp']

# 案例标签 (argv[1], 如 alice): 读 _paper_exp1_fronts_<tag>.csv, 输出独立文件
TAG = sys.argv[1] if len(sys.argv) > 1 else ''
if TAG:
    df = pd.read_csv(f'_paper_exp1_fronts_{TAG}.csv', encoding='utf-8-sig')
    r = df[df.arm == 'rule']
    m = df[df.arm == 'milp']

FR = r[['TA', 'AC', 'TG']].to_numpy(float)
FM = m[['TA', 'AC', 'TG']].to_numpy(float)

fig = plt.figure(figsize=(7.4, 5.2))
ax = fig.add_subplot(111, projection='3d')

# ---- 浅灰背板 + 细网格 (顶刊 3D 箱体风格) ----
for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
    pane.set_facecolor('#F4F5F7')
    pane.set_alpha(1.0)
    pane.set_edgecolor('#FFFFFF')
for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
    axis._axinfo['grid'].update(color='#C9CDD4', linewidth=0.5, linestyle='-')

# ---- 两臂前沿: 小号密排散点 (不加拉线/曲面, 与图2 2D 同色同标记语言) ----
ax.scatter(FR[:, 0], FR[:, 1], FR[:, 2], s=16, facecolors='none',
           edgecolors='#D62728', linewidths=0.9, depthshade=False,
           label='Fixed TOU strategy')
ax.scatter(FM[:, 0], FM[:, 1], FM[:, 2], s=16, color='#1F77B4',
           depthshade=False, label='Nested MILP (proposed)')

# ---- TOPSIS 推荐解 (单种子 knee, 与表5/5.2节同口径) + 坐标标注 ----
_knee = f'_paper_exp1_knee{"_" + TAG if TAG else ""}.json'
try:
    knee = json.load(open(_knee, encoding='utf-8'))
    KT, KA, KG = knee['TA'], knee['AC'], knee['TG']
    ax.scatter([KT], [KA], [KG], marker='*', s=420, c='#FFD700',
               edgecolors='#8B6914', linewidths=0.9, depthshade=False,
               zorder=10, label='TOPSIS recommended')
    # 坐标三元组标注在星旁 (朝图内空白方向偏移, 视觉校验后定稿)
    span = np.vstack([FR, FM]).max(0) - np.vstack([FR, FM]).min(0)
    ax.text(KT - 0.10 * span[0], KA - 0.10 * span[1], KG + 0.08 * span[2],
            f'({KT:.0f}, {KA:.1f}, {KG:.0f})', fontsize=9, color='#333333',
            ha='center', zorder=11,
            bbox=dict(fc='white', ec='none', alpha=0.75, pad=1.2))
except FileNotFoundError:
    print(f'警告: 未找到 {_knee}, 跳过推荐解标注')

ax.set_xlabel('Total annual cost TA (CNY)', labelpad=10)
ax.set_ylabel('Annual carbon AC (t)', labelpad=10)
ax.set_zlabel('Grid interaction TG (kWh)', labelpad=12)
ax.view_init(elev=18, azim=-55)

# 图例中的五角星会继承图内 s=420 的尺寸, 过大; 图例改用小号代理句柄, 图内星标不变
_h, _l = ax.get_legend_handles_labels()
_h = [Line2D([0], [0], linestyle='none', marker='*', markersize=10.5,
             markerfacecolor='#FFD700', markeredgecolor='#8B6914',
             markeredgewidth=0.9) if lb.startswith('TOPSIS') else h
      for h, lb in zip(_h, _l)]
ax.legend(_h, _l, frameon=False, loc='upper left')

# 不用 tight: Axes3D 的 tight bbox 不含 zlabel, 会把 z 轴标题裁掉; 手动留右边距
fig.subplots_adjust(left=0.02, right=0.80, top=1.0, bottom=0.0)
fig.savefig(f'论文图片/图2_实验1_Pareto前沿对比{"_" + TAG if TAG else ""}_3D.png',
            dpi=300)
print(f'已保存: 论文图片/图2_实验1_Pareto前沿对比{"_" + TAG if TAG else ""}_3D.png '
      f'(规则前沿 {len(FR)} 点 | MILP 前沿 {len(FM)} 点)')
