# -*- coding: utf-8 -*-
"""
论文 (Energy 投稿) 图表统一风格模块
====================================
所有出图脚本 `import _paper_figstyle` 即得统一风格:
  - 字体 Times New Roman + STIX 数学符号 (公式与正文字体同族)
  - 统一字号: 基准 10 / 轴标题 10 / 刻度 9.5 / 图例 9.5
  - 刻度朝内 (direction='in'), 轴线 0.8 pt, 图例无框
  - 固定分类色序: 色随实体, 全文各图一致 (红=规则基线, 蓝=MILP, 金=TOPSIS)
"""
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman'],
    'mathtext.fontset': 'stix',
    'axes.unicode_minus': False,
    'font.size': 10,
    'axes.labelsize': 10,   # 全文基准字号 (= 负荷图纵坐标)
    'axes.linewidth': 0.8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'xtick.labelsize': 9,   # 小字降一号
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'legend.frameon': False,
    'savefig.dpi': 300,
})

# ---- 固定分类色 (全文共用的实体色, 禁止按图重排) ----
C_RULE = '#D62728'    # 固定 TOU 规则基线
C_MILP = '#1F77B4'    # 嵌套 MILP (proposed)
C_STAR = '#FFD700'    # TOPSIS 推荐解 (星标)
C_STAR_E = '#8B6914'  # 星标描边
C_ALT1 = '#DD8452'    # 备用系列色 (按序取用, 不循环)
C_ALT2 = '#55A868'
C_ALT3 = '#C44E52'
