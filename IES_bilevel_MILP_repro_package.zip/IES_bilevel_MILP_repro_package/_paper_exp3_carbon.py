# -*- coding: utf-8 -*-
"""
小论文实验 3: 阶梯碳交易机制消融 (自由容量, 成本单目标)
================================================================
同一拓扑/数据/经济参数, 仅切换碳排放核算机制, 观察 MILP 容量决策与碳排响应:
    A stepped : 论文 Eq.8-11 阶梯碳交易 (λ=250, l=100t, α=0.25) — 完整机制
    B flat    : 固定碳税 250 ¥/t (线性, 无阶梯增量)
    C none    : 无碳价 (CCT=0, 纯经济优化)
内层单目标 = 年总成本 TA (obj_cost only), 容量在 [0,2000] 内自由寻优。
ASHP 由 MILP 黑盒推导 (维度消减), 与平台双层架构一致。

输出: _paper_exp3_table.csv / 控制台对比表
"""
import sys
import copy
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import _paper_figstyle  # noqa: F401  (统一风格)

from milp_capacity_engine import MILPCapacityEngine
import pyomo.environ as pyo

BOUNDS = {'Roof_PV': 2000.0, 'Battery_Array': 2000.0, 'Thermal_Tank': 2000.0}
CCT_DEACT = ['Carbon_Buy_Def', 'z_seg_caps', 'CCT_buy_Def', 'CCT_sell_Def', 'CCT_Def']

# 案例标签 (argv, 如 alice): 契约与输出独立命名, 缺省 = Essie 主案例
# --fig-only: 跳过求解, 直接从已有 _paper_exp3_table*.csv 重绘图
_ARGS = [a for a in sys.argv[1:] if not a.startswith('-')]
FIG_ONLY = '--fig-only' in sys.argv
CASE = _ARGS[0] if _ARGS else ''
CONTRACT_PATH = f'ies_forecast_contract_{CASE}_eui.pkl' if CASE else 'ies_forecast_contract_eui.pkl'
_TAG = f'_{CASE}' if CASE else ''


def solve_variant(contract, mode):
    cfg = {"Scenario": "Custom", "Buses": ["ElectricityBus", "HeatBus", "CoolBus"],
           "obj_cost": True, "obj_carbon": False, "obj_grid": False,
           "Parameters": {"capacity_bounds": {k: [0.0, v] for k, v in BOUNDS.items()}},
           "Components": {"State_Grid": {"allow_sell": False}, "Roof_PV": {}, "Main_ASHP": {},
                          "Battery_Array": {}, "Thermal_Tank": {}}}
    eng = MILPCapacityEngine(cfg, contract)
    eng.build_model()
    m = eng.m
    if mode == 'none':
        for name in CCT_DEACT:
            getattr(m, name).deactivate()
        m.CCT_none = pyo.Constraint(expr=m.CCT == 0)
    elif mode == 'flat':
        for name in CCT_DEACT:
            getattr(m, name).deactivate()
        m.CCT_flat = pyo.Constraint(expr=m.CCT == 250.0 * m.Trade)
    opt = pyo.SolverFactory('asl:cbc')
    if not opt.available(exception_flag=False):
        opt = pyo.SolverFactory('asl:cbc', executable=r'C:\Users\i5\Desktop\.venv1\Scripts\cbc.exe')
    opt.solve(m, tee=False)
    caps = {}
    for k, vname in [('Roof_PV', 'PV_Cap'), ('Battery_Array', 'Battery_Array_Cap'),
                     ('Thermal_Tank', 'Thermal_Tank_Cap'), ('Main_ASHP', 'ASHP_Cap')]:
        try:
            caps[k] = float(pyo.value(getattr(m, vname)))
        except Exception:
            caps[k] = 0.0
    inv = float(pyo.value(m.Total_Inv)); ma = float(pyo.value(m.Total_Maintenance))
    op = float(pyo.value(m.Total_Op)); cct = float(pyo.value(m.CCT))
    carbon = float(pyo.value(m.Total_Carbon)); grid = float(pyo.value(m.Total_Grid))
    ta = inv * eng.CRF + ma + op + cct
    return dict(mode=mode, PV=caps['Roof_PV'], Battery=caps['Battery_Array'],
                Tank=caps['Thermal_Tank'], ASHP_el=caps['Main_ASHP'],
                C_inv=inv * eng.CRF, C_ma=ma, C_op=op, CCT=cct, TA=ta,
                Carbon=carbon, Grid=grid)


def make_figure(df, tag):
    """TA 分解堆积 + 碳排对比图 (可独立于求解重绘)。"""
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    names = {'stepped': 'Stepped CCT', 'flat': 'Flat tax\n(250 CNY/t)',
             'none': 'No carbon\nprice'}
    cols = ['#1F77B4', '#FF9D45', '#D62728']
    x = np.arange(3)
    bottom = np.zeros(3)
    for key, c in [('C_inv', '#4C72B0'), ('C_ma', '#DD8452'), ('C_op', '#55A868'), ('CCT', '#C44E52')]:
        vals = np.array([max(df.iloc[i][key], 0) for i in range(3)])
        axes[0].bar(x, vals, 0.55, bottom=bottom, color=c, label=key)
        bottom += vals
    axes[0].set_xticks(x); axes[0].set_xticklabels([names[m] for m in df['mode']])
    axes[0].set_ylabel('Annual cost TA (CNY)')
    # 图例置于面板上方横排, 避免压住堆积柱 (loc='best' 会落进左下柱区)
    axes[0].legend(frameon=False, ncol=4, loc='lower left',
                   bbox_to_anchor=(0.0, 1.02), handlelength=1.2,
                   columnspacing=1.0, handletextpad=0.5)
    axes[1].bar(x, df['Carbon'], 0.55, color=cols)
    axes[1].set_xticks(x); axes[1].set_xticklabels([names[m] for m in df['mode']])
    axes[1].set_ylabel('Annual carbon AC (t)')
    # 顶部留 12% 空间给柱顶数值, 否则最高标注 (368) 顶到上框线
    axes[1].set_ylim(0, float(df['Carbon'].max()) * 1.12)
    for i, v in enumerate(df['Carbon']):
        axes[1].text(i, v, f'{v:.1f}', ha='center', va='bottom')
    for ax in axes:
        ax.tick_params(direction='in')
    fig.tight_layout()
    fig.savefig(f'论文图片/图4_实验3_碳交易机制消融{tag}.png', dpi=300, bbox_inches='tight')
    print(f'\n已保存: 论文图片/图4_实验3_碳交易机制消融{tag}.png')


def main():
    if FIG_ONLY:
        df = pd.read_csv(f'_paper_exp3_table{_TAG}.csv', encoding='utf-8-sig')
        make_figure(df, _TAG)
        return
    contract = joblib.load(CONTRACT_PATH)
    rows = []
    for mode in ['stepped', 'flat', 'none']:
        print(f'\n===== 机制变体: {mode} =====')
        r = solve_variant(contract, mode)
        rows.append(r)
        print(f"  容量: PV={r['PV']:.0f} kW | Bat={r['Battery']:.0f} kWh | "
              f"Tank={r['Tank']:.0f} kWh | ASHP(电)={r['ASHP_el']:.0f} kW")
        print(f"  TA={r['TA']:,.0f} = 投资 {r['C_inv']:,.0f} + 维护 {r['C_ma']:,.0f} "
              f"+ 运行 {r['C_op']:,.0f} + 碳交易 {r['CCT']:,.0f}")
        print(f"  碳排 {r['Carbon']:.1f} t | 电网交互 {r['Grid']:,.0f} kWh")

    df = pd.DataFrame(rows)
    df.to_csv(f'_paper_exp3_table{_TAG}.csv', index=False, encoding='utf-8-sig')

    # 对比表打印
    base = df[df['mode'] == 'none'].iloc[0]
    print('\n===== 相对无碳价基线的碳减排 =====')
    for _, r in df.iterrows():
        if r['mode'] == 'none':
            continue
        print(f"  {r['mode']:>8s}: 碳排 {r['Carbon']:.1f} t "
              f"(↓{(1 - r['Carbon'] / base['Carbon']) * 100:.1f}%), "
              f"TA 增量 +{r['TA'] - base['TA']:,.0f} ¥, "
              f"减碳代价 {(r['TA'] - base['TA']) / max(base['Carbon'] - r['Carbon'], 1e-9):,.0f} ¥/t")

    make_figure(df, _TAG)
    print(f'已保存: _paper_exp3_table{_TAG}.csv')


if __name__ == '__main__':
    main()
