# -*- coding: utf-8 -*-
"""
EUI 锚定三负荷量纲校准 (eui_harmonize.py)
================================================================
小论文数据处理节的方法论环节:
  - BDG2 各表计单位存在场址级不一致 (Fox 场址实测: 电 EUI 12.7 / 冷 334 /
    热 2340 kWh/m²/年, 荒谬且互相矛盾), 直接用于容量规划会失真。
  - 校准哲学: **ML 重建曲线只提供时间结构 (24h 形状/季节翻转/峰时刻),
    绝对量级由物理统计锚定** —— 年能量 = CBECS 办公建筑 EUI × 建筑面积。
  - 重标定后重新 KMeans 聚典型日 (原始尺度下热负荷压制电负荷 400 倍,
    聚类被热流形主导, 重标定后三流权重才平衡)。

用法:
    python eui_harmonize.py [contract_pkl]        # 默认 ies_forecast_contract.pkl
输出:
    ies_forecast_8760_eui.csv / ies_forecast_contract_eui.pkl
"""
import sys
import os
import numpy as np
import pandas as pd
import joblib

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# ---- CBECS 办公建筑 EUI 锚点 (kWh/m²/年, site energy) ----
EUI = {'Load_Elec': 95.0, 'Load_Heat': 50.0, 'Load_Cool': 30.0}
EUI_SOURCE = 'CBECS 2012 office buildings (electricity 95 / heating 50 / cooling 30 kWh/m2-yr)'

DATA_DIR = r'C:\Users\i5\load forecast\dataset'
BUILDING = 'Fox_office_Essie'


def get_floor_area(data_dir=DATA_DIR, building=BUILDING):
    """从 metadata.csv 读建筑面积 (sqft → m²)。"""
    meta = pd.read_csv(os.path.join(data_dir, 'metadata.csv'))
    row = meta[meta['building_id'] == building].iloc[0]
    return float(row['sqft']) * 0.092903


def harmonize(csv_path='ies_forecast_8760.csv', data_dir=DATA_DIR, building=BUILDING):
    import ies_load_forecast_bridge as br

    df = pd.read_csv(csv_path)
    area = get_floor_area(data_dir, building)
    print(f'建筑 {building} | 面积 {area:,.0f} m² | EUI 锚点: {EUI_SOURCE}')

    # ---- 1. 各负荷整体缩放到 EUI 锚定年能量 (形状不变) ----
    targets = [c for c in ['Load_Elec', 'Load_Cool', 'Load_Heat', 'Load_Gas'] if c in df.columns]
    for t in targets:
        raw_year = df[t].clip(lower=0).sum()
        if raw_year <= 0:
            print(f'  [{t}] 全零, 跳过')
            continue
        anchor = EUI.get(t, None)
        if anchor is None:                     # 无锚点的流 (如燃气) 保持原量纲
            k = 1.0
        else:
            k = anchor * area / raw_year
        df[t] = df[t] * k
        new_peak = df[t].max()
        print(f'  [{t:<10s}] ×{k:9.4f} → 年能量 {df[t].sum()/1000:9,.0f} MWh '
              f'(EUI {EUI.get(t, float("nan")) if anchor else float("nan"):5.1f} kWh/m²) | 新峰值 {new_peak:8.1f} kW')

    # ---- 2. 重标定后的 8760 曲线重新聚类典型日 ----
    preds = df[targets].to_numpy(dtype=float)
    labels, centers = br.cluster_typical_days(preds, targets)
    print(f'  重新聚类: {dict(pd.Series(labels).value_counts().sort_index())}')

    # ---- 3. 场址气象合成风光 + 组装契约 ----
    pv_h, wind_h = br.synth_pv_wind_hourly(data_dir, building, len(preds))
    contract = br.assemble_contract(preds, targets, labels, centers,
                                    pv_hourly=pv_h, wind_hourly=wind_h)

    # ---- 4. 落盘 (命名规则: <stem>_eui.csv / <stem 去掉8760换contract>_eui.pkl,
    #         Essie 主案例与既有输出逐字节同名, 第二案例按输入名派生独立文件) ----
    stem = os.path.splitext(csv_path)[0]
    out_csv = stem + '_eui.csv'
    df.to_csv(out_csv, index=False, encoding='utf-8-sig')
    out_pkl = stem.replace('8760', 'contract') + '_eui.pkl'
    joblib.dump(contract, out_pkl)
    print(f'\n  ✅ 重标定曲线: {out_csv}')
    print(f'  ✅ 重标定契约: {out_pkl}')
    for j, t in enumerate(targets):
        c = preds[:, j]
        print(f'  [{t:<10s}] 峰值 {c.max():8.1f} kW | 均值 {c.mean():7.1f} kW')
    return contract


if __name__ == '__main__':
    csv_path = sys.argv[1] if len(sys.argv) > 1 else 'ies_forecast_8760.csv'
    building = sys.argv[2] if len(sys.argv) > 2 else BUILDING
    harmonize(csv_path, building=building)
