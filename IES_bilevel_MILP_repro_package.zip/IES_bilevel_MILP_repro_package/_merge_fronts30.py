# -*- coding: utf-8 -*-
"""30 种子 (42..71) 合并前沿 + 合并 TOPSIS 推荐 — _paper_exp1_merge_fronts.py 的 30 种子版。
输出写新文件 _paper_exp1_fronts_merged30.csv / _paper_exp1_knee_merged30.json,
不动论文现有 _merged 数据。协议与 3 种子版完全一致: 去重合并 → 非支配筛选 → 等权 TOPSIS。"""
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import json
import numpy as np
import pandas as pd

SEEDS = list(range(42, 72))          # 30 个种子
TAGS = [('' if s == 42 else f'_{s}', str(s)) for s in SEEDS]
COLS = ['TA', 'AC', 'TG', 'X_PV', 'X_Bat', 'X_Tank']


def nondominated_mask(f):
    keep = np.ones(len(f), dtype=bool)
    for i in range(len(f)):
        dom = np.all(f <= f[i], axis=1) & np.any(f < f[i], axis=1)
        keep[i] = not dom.any()
    return keep


def main():
    fronts = {}
    for suffix, tag in TAGS:
        d = pd.read_csv(f'_paper_exp1_fronts{suffix}.csv', encoding='utf-8-sig')
        fronts[tag] = d[d.arm == 'milp'][COLS].reset_index(drop=True)
    names = [t for _, t in TAGS]
    pool = pd.concat([fronts[t].assign(seed=t) for t in names], ignore_index=True)
    n_raw = len(pool)
    uniq = pool.drop_duplicates(subset=COLS).reset_index(drop=True)
    n_uniq = len(uniq)
    f = uniq[COLS[:3]].to_numpy(dtype=float)
    keep = nondominated_mask(f)
    merged = uniq[keep].reset_index(drop=True)
    n_front = len(merged)

    merged['found_by'] = merged[COLS].round(9).apply(
        lambda row: sum(int((fronts[t][COLS].round(9) == row.to_numpy()).all(axis=1).any())
                        for t in names), axis=1)
    contrib = {t: int((merged['seed'] == t).sum()) for t in names}

    z = (f[keep] - f[keep].min(0)) / (f[keep].max(0) - f[keep].min(0) + 1e-12)
    d_b = np.sqrt(((z - z.max(0)) ** 2).sum(1))
    d_w = np.sqrt(((z - z.min(0)) ** 2).sum(1))
    k = int(np.argmax(d_w / (d_b + d_w + 1e-12)))
    knee = {c: float(merged.loc[k, c]) for c in COLS}

    merged.to_csv('_paper_exp1_fronts_merged30.csv', index=False, encoding='utf-8-sig')
    with open('_paper_exp1_knee_merged30.json', 'w', encoding='utf-8') as fp:
        json.dump(knee, fp, ensure_ascii=False, indent=1)

    print(f'合并池 {n_raw} 点 → 去重 {n_uniq} 点 → 非支配筛选 {n_front} 点')
    print(f'合并前沿种子贡献 (首发现, 共{len(names)}种子): '
          + ' '.join(f's{t}:{contrib[t]}' for t in names))
    fbd = merged['found_by'].value_counts().sort_index().to_dict()
    print(f'重复发现度 found_by 分布: {fbd}')
    print(f'合并 TOPSIS 推荐: PV={knee["X_PV"]:.0f} Bat={knee["X_Bat"]:.0f} '
          f'Tank={knee["X_Tank"]:.0f} | TA={knee["TA"]:,.0f} AC={knee["AC"]:.1f} '
          f'TG={knee["TG"]:,.0f}')
    print('已保存: _paper_exp1_fronts_merged30.csv, _paper_exp1_knee_merged30.json '
          '(论文原 _merged 文件未动)')


if __name__ == '__main__':
    main()
