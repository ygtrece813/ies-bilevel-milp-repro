# -*- coding: utf-8 -*-
"""
小论文实验 1: 固定 TOU 规则基线 vs 嵌套精确 MILP — Pareto 前沿对比
================================================================
同一外层 NSGA-II (相同算子/种群/代数/边界/随机种子), 同一 Essie EUI 重标定
典型日数据, 同一经济参数与碳核算 (实际 1.08 kg/kWh / 配额 0.68 / 阶梯碳价),
唯一差异 = 内层容量评价方法:
    基线臂: fixed_strategy_engine.FixedTOUEvaluator (Liu et al. 2025 图3/图4 规则)
    本文臂: milp_capacity_engine.MILPCapacityEngine (精确 MILP, Pyomo+CBC)
两臂均不允许余电上网 (避免售电套利干扰, 与 multi_scale_engine 自定义场景约定一致)。

决策变量 (两臂一致): Roof_PV kW / Battery_Array kWh / Thermal_Tank kWh
目标 (两臂一致):     TA 年总成本 / AC 年碳排 t / TG 电网交互 kWh
输出: _paper_exp1_fronts.csv / 论文图片/图2_实验1_Pareto前沿对比.png / _paper_exp1_metrics.txt
"""
import sys
import time
import copy
import gc
import os
import pickle
import random
import joblib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import _paper_figstyle  # noqa: F401  (统一风格)

from fixed_strategy_engine import FixedTOUEvaluator
from milp_capacity_engine import MILPCapacityEngine
import pyomo.environ as pyo

# ---------------- 公共设定 ----------------
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 42
TANK_MAX = float(sys.argv[2]) if len(sys.argv) > 2 else 2000.0   # 蓄能罐上界敏感性 (argv[2])
CASE = sys.argv[3] if len(sys.argv) > 3 else ''                  # 案例标签 (argv[3], 如 alice)
_TAG = f'_{SEED}' if SEED != 42 else ''
if TANK_MAX != 2000.0:
    _TAG += f'_tk{int(TANK_MAX)}'      # 敏感性运行输出独立文件, 不覆盖论文主数据
if CASE:
    _TAG += f'_{CASE}'                 # 第二案例输出独立文件
CONTRACT_PATH = f'ies_forecast_contract_{CASE}_eui.pkl' if CASE else 'ies_forecast_contract_eui.pkl'
CHUNK = int(sys.argv[4]) if len(sys.argv) > 4 else 0   # 分块代数(argv[4]): >0 启用断点续存,
# 每次调用推进至多 CHUNK 代后退出 (退出码 2=未完/0=完成), 防长跑内存累积
STATE = f'_paper_exp1_state{_TAG}.pkl'
POP, GEN = 100, 100                   # 两臂一致的外层规模 (论文报告用; 提预算以增密前沿)
BOUNDS = {'PV': (0.0, 2000.0), 'Bat': (0.0, 2000.0), 'Tank': (0.0, TANK_MAX)}
VAR_NAMES = ['Roof_PV', 'Battery_Array', 'Thermal_Tank']
NO_SELL = False                       # 统一禁售

# 论文碳核算 (与 MILP 层一致): 实际 1.08 kg/kWh, 配额 0.68 kg/kWh, 阶梯碳价
CARBON_ACT, CARBON_QUOTA = 1.08, 0.68
SEG_SLOPES = [250 * (1 + 0.25 * k) for k in range(5)]     # 250/312.5/375/437.5/500
SEG_CAP = 100.0                                            # t, 前4段

random.seed(SEED)
np.random.seed(SEED)


def stepped_cct(net_t):
    """阶梯碳交易净成本 (¥): net_t>0 买配额走增量分段, <0 卖配额按基础价 250 回收。"""
    if net_t <= 0:
        return 250.0 * net_t
    cost, rem = 0.0, net_t
    for k in range(5):
        take = min(rem, SEG_CAP if k < 4 else rem)
        cost += take * SEG_SLOPES[k]
        rem -= take
        if rem <= 1e-9:
            break
    return cost


# ---------------- 臂 1: 固定 TOU 规则基线 ----------------
class BaselineArm:
    def __init__(self, contract):
        self.ev = FixedTOUEvaluator(contract, params={'allow_sell': NO_SELL})
        self.solve_time = 0.0
        self.n_eval = 0

    def evaluate(self, x):
        t0 = time.perf_counter()
        r = self.ev.evaluate(pv_kw=x[0], bat_kwh=x[1], tank_kwh=x[2])
        # 论文碳核算对齐: CCT 由净交易量走阶梯价, AC = 实际碳排
        net_t = (CARBON_ACT - CARBON_QUOTA) * r['TG'] / 1000.0     # 无售电 → TG=购电
        cct = stepped_cct(net_t)
        ta = r['C_inv'] + r['C_ma'] + r['C_oper'] + cct + r['unmet_kwh'] * 1e-2
        self.solve_time += time.perf_counter() - t0
        self.n_eval += 1
        return [ta, CARBON_ACT * r['TG'] / 1000.0, r['TG']]


# ---------------- 臂 2: 嵌套精确 MILP ----------------
class MILPArm:
    def __init__(self, contract):
        self.contract = contract
        self.base_config = {
            "Scenario": "Custom",
            "Buses": ["ElectricityBus", "HeatBus", "CoolBus"],
            "obj_cost": True, "obj_carbon": True, "obj_grid": True,
            "Components": {
                "State_Grid": {"allow_sell": NO_SELL},
                "Roof_PV": {}, "Main_ASHP": {},
                "Battery_Array": {}, "Thermal_Tank": {},
            },
        }
        self.extra_params = {}      # 场景敏感性注入位 (如 carbon_price), 主实验为空
        self.solve_time = 0.0
        self.n_eval = 0
        self.opt = pyo.SolverFactory('asl:cbc')   # 求解器句柄仅建一次, 防长跑内存累积
        if not self.opt.available(exception_flag=False):
            self.opt = pyo.SolverFactory('asl:cbc', executable=r'C:\Users\i5\Desktop\.venv1\Scripts\cbc.exe')

    def evaluate(self, x):
        t0 = time.perf_counter()
        cfg = copy.deepcopy(self.base_config)
        cfg["Parameters"] = {**self.extra_params, "capacity_bounds": {
            'Roof_PV': [x[0], x[0]], 'Battery_Array': [x[1], x[1]],
            'Thermal_Tank': [x[2], x[2]]}}
        try:
            eng = MILPCapacityEngine(cfg, self.contract)
            eng.build_model()
            self.opt.solve(eng.m, tee=False)
            fail = max(0.0, pyo.value(eng.m.Total_Fail))
            ta = (pyo.value(eng.m.Total_Inv) * eng.CRF + pyo.value(eng.m.Total_Maintenance)
                  + pyo.value(eng.m.Total_Op) + pyo.value(eng.m.CCT) + fail)
            ac = pyo.value(eng.m.Total_Carbon)
            tg = pyo.value(eng.m.Total_Grid)
            del eng, cfg
            gc.collect()               # 逐体释放 Pyomo 模型, 防长跑内存累积
            self.solve_time += time.perf_counter() - t0
            self.n_eval += 1
            return [ta, ac, tg]
        except Exception as e:
            # 求解崩溃视为致命错误: 抛出使本分块以非零码退出,
            # 由外层驱动从最近断点重试——绝不将失效评价记入种群
            raise RuntimeError(f'MILP求解崩溃: {e}') from e


# ---------------- 精简 NSGA-II (与 nsga2_capacity_engine 同算子) ----------------
def dominates(a, b):
    return all(u <= v for u, v in zip(a, b)) and any(u < v for u, v in zip(a, b))


def nondominated_sort(objs):
    n = len(objs)
    S = [[] for _ in range(n)]; cnt = [0] * n; rank = [0] * n; fronts = [[]]
    for p in range(n):
        for q in range(n):
            if dominates(objs[p], objs[q]): S[p].append(q)
            elif dominates(objs[q], objs[p]): cnt[p] += 1
        if cnt[p] == 0: rank[0] = 0; fronts[0].append(p)
    i = 0
    while len(fronts[i]) > 0:
        nxt = []
        for p in fronts[i]:
            for q in S[p]:
                cnt[q] -= 1
                if cnt[q] == 0: rank[q] = i + 1; nxt.append(q)
        i += 1; fronts.append(nxt)
    return rank, fronts[:-1]


def crowding(objs, front):
    d = [0.0] * len(front)
    if len(front) <= 2: return [float('inf')] * len(front)
    for m in range(3):
        idx = sorted(range(len(front)), key=lambda k: objs[front[k]][m])
        d[idx[0]] = d[idx[-1]] = float('inf')
        lo, hi = objs[front[idx[0]]][m], objs[front[idx[-1]]][m]
        scale = (hi - lo) or 1.0
        for i in range(1, len(front) - 1):
            d[idx[i]] += (objs[front[idx[i + 1]]][m] - objs[front[idx[i - 1]]][m]) / scale
    return d


def sbx_poly(pop, bounds_arr, rank):
    """SBX 交叉 + 多项式变异 (参数与 nsga2_capacity_engine 一致: pc .8 / pm .2 / eta 20)。"""
    nv = pop.shape[1]
    children = []
    while len(children) < POP:
        i1, i2 = random.sample(range(POP), 2)
        p1 = pop[i1] if rank[i1] < rank[i2] else pop[i2]
        i1, i2 = random.sample(range(POP), 2)
        p2 = pop[i1] if rank[i1] < rank[i2] else pop[i2]
        c1, c2 = p1.copy(), p2.copy()
        if random.random() < 0.8:
            for j in range(nv):
                if random.random() < 0.5 and abs(p1[j] - p2[j]) > 1e-6:
                    y1, y2 = min(p1[j], p2[j]), max(p1[j], p2[j])
                    rand = random.random()
                    beta = 1.0 + 2.0 * (y1 - bounds_arr[j][0]) / (y2 - y1)
                    alpha = 2.0 - beta ** -21
                    beta_q = (1.0 / (2.0 - rand * alpha)) ** 21 if rand <= 1.0 / alpha else \
                             (rand * alpha - 1.0) ** 21
                    c1[j] = 0.5 * ((y1 + y2) - beta_q * (y2 - y1))
        for c in (c1, c2):
            if random.random() < 0.2:
                for j in range(nv):
                    if random.random() < 1.0 / nv:
                        yl, yu = bounds_arr[j]
                        if yl == yu: continue
                        rand = random.random()
                        d1, d2 = (c[j] - yl) / (yu - yl), (yu - c[j]) / (yu - yl)
                        if rand <= 0.5:
                            val = 2.0 * rand + (1.0 - 2.0 * rand) * (1.0 - d1) ** 21
                            dq = val ** 21 - 1.0
                        else:
                            val = 2.0 * (1.0 - rand) + 2.0 * (rand - 0.5) * (1.0 - d2) ** 21
                            dq = 1.0 - val ** 21
                        c[j] = max(yl, min(c[j] + dq * (yu - yl), yu))
        children.append(c)
    return np.array(children[:POP])


def run_arm(arm, label, st=None, full=False):
    """跑一个臂的 NSGA-II。CHUNK>0 且非 full 时, 单次调用最多推进 CHUNK 代:
    返回 (done, result, new_st) — done=False 时 new_st 为断点, 由调用方落盘并以退出码 2 结束。"""
    bounds_arr = np.array(list(BOUNDS.values()))
    if st is not None:
        pop = np.array(st['pop'])
        random.setstate(st['py_rng'])
        np.random.set_state(st['np_rng'])
        arm.n_eval = st['n_eval']
        arm.solve_time = st['solve_time']
        start = st['gen']
    else:
        pop = np.array([[random.uniform(bo[0], bo[1]) for bo in bounds_arr] for _ in range(POP)])
        start = 0
    end = GEN if (full or not CHUNK) else min(start + CHUNK, GEN)
    for gen in range(start, end):
        objs = [arm.evaluate(ind) for ind in pop]
        rank, _ = nondominated_sort(objs)
        children = sbx_poly(pop, bounds_arr, rank)
        merged = np.vstack((pop, children))
        m_objs = [arm.evaluate(ind) for ind in merged]
        m_rank, m_fronts = nondominated_sort(m_objs)
        keep = []
        for fr in m_fronts:
            if len(keep) + len(fr) <= POP:
                keep.extend(fr)
            else:
                cd = crowding(m_objs, fr)
                for idx in sorted(range(len(fr)), key=lambda k: cd[k], reverse=True):
                    if len(keep) < POP: keep.append(fr[idx])
                break
        pop = merged[keep]
        print(f'  [{label}] gen {gen + 1}/{GEN} done (累计评价 {arm.n_eval}, '
              f'内层耗时 {arm.solve_time:.0f}s)', flush=True)
    if CHUNK and not full and end < GEN:
        new_st = {'gen': end, 'pop': pop.tolist(), 'py_rng': random.getstate(),
                  'np_rng': np.random.get_state(), 'n_eval': arm.n_eval,
                  'solve_time': arm.solve_time}
        print(f'>> [{label}] 断点已存: {end}/{GEN} 代 (内层累计 {arm.solve_time:.0f}s)',
              flush=True)
        return False, None, new_st
    objs = [arm.evaluate(ind) for ind in pop]
    _, fronts = nondominated_sort(objs)
    front = np.array([objs[i] for i in fronts[0]])
    front_x = pop[fronts[0]]
    print(f'>> [{label}] 完成: 前沿 {len(front)} 点 | '
          f'内层累计 {arm.solve_time:.0f}s ({arm.n_eval} 次, 单次 {arm.solve_time / arm.n_eval:.4f}s)',
          flush=True)
    return True, (front, front_x, arm), None


def main():
    contract = joblib.load(CONTRACT_PATH)

    print('=' * 64)
    print(f'实验 1: 固定 TOU 规则基线 vs 嵌套精确 MILP '
          f'({"Essie" if not CASE else CASE}, EUI 锚定)')
    print(f'外层: NSGA-II pop={POP} gen={GEN} seed={SEED} | 变量: PV/电池/蓄能罐'
          + (f' | 分块续存 CHUNK={CHUNK}' if CHUNK else ''))
    print(f'边界: {BOUNDS} | 两臂统一禁售电 | 目标: TA/AC/TG')
    print('=' * 64)

    import pandas as pd
    st = None
    if CHUNK and os.path.exists(STATE):
        with open(STATE, 'rb') as f:
            st = pickle.load(f)
        print(f'>> 断点续存: arm{st["arm_idx"]} @ gen {st.get("gen", 0)}', flush=True)

    # ---- 臂 1: 固定 TOU 规则基线 (评价开销极小, 不分块) ----
    if st is None or st['arm_idx'] == 0:
        use_st = st if (st is not None and st['arm_idx'] == 0
                        and st.get('pop') is not None) else None
        done, res, new_st = run_arm(BaselineArm(contract), '规则基线', use_st, full=True)
        if not done:
            new_st['arm_idx'] = 0
            with open(STATE, 'wb') as f:
                pickle.dump(new_st, f)
            sys.exit(2)
        front_rule, fx_rule, arm_rule = res
        rule_n, rule_t = arm_rule.n_eval, arm_rule.solve_time
        if CHUNK:
            st = {'arm_idx': 1, 'gen': 0, 'pop': None, 'py_rng': None, 'np_rng': None,
                  'n_eval': 0, 'solve_time': 0.0, 'rule': {'n': rule_n, 't': rule_t}}
    else:
        front_rule = np.array(st['rule']['front'])
        fx_rule = np.array(st['rule']['fx'])
        rule_n, rule_t = st['rule']['n'], st['rule']['t']

    df_r = pd.DataFrame(front_rule, columns=['TA', 'AC', 'TG'])
    df_r['X_PV'], df_r['X_Bat'], df_r['X_Tank'] = fx_rule[:, 0], fx_rule[:, 1], fx_rule[:, 2]
    df_r['arm'] = 'rule'

    # ---- 臂 2: 嵌套精确 MILP (分块续存) ----
    if st is None or st['arm_idx'] == 1:
        use_st = st if (st is not None and st['arm_idx'] == 1
                        and st.get('pop') is not None) else None
        done, res, new_st = run_arm(MILPArm(contract), '嵌套MILP', use_st)
        if not done:
            new_st['arm_idx'] = 1
            if st is not None and 'rule' in st:
                new_st['rule'] = {**st['rule'], 'front': front_rule.tolist(),
                                  'fx': fx_rule.tolist()}
            with open(STATE, 'wb') as f:
                pickle.dump(new_st, f)
            sys.exit(2)
        front_milp, fx_milp, arm_milp = res
        if CHUNK:
            os.remove(STATE)
    milp_n, milp_t = arm_milp.n_eval, arm_milp.solve_time

    df_m = pd.DataFrame(front_milp, columns=['TA', 'AC', 'TG'])
    df_m['X_PV'], df_m['X_Bat'], df_m['X_Tank'] = fx_milp[:, 0], fx_milp[:, 1], fx_milp[:, 2]
    df_m['arm'] = 'milp'
    df_r.to_csv(f'_paper_exp1_fronts{_TAG}.csv', index=False, encoding='utf-8-sig')
    pd.concat([df_r, df_m]).to_csv(f'_paper_exp1_fronts{_TAG}.csv', index=False, encoding='utf-8-sig')

    # TOPSIS 拐点配置 (供实验 2 使用)
    Z = (df_m[['TA', 'AC', 'TG']] - df_m[['TA', 'AC', 'TG']].min()) / \
        (df_m[['TA', 'AC', 'TG']].max() - df_m[['TA', 'AC', 'TG']].min() + 1e-12)
    d_b = np.sqrt(((Z - Z.max()) ** 2).sum(axis=1))
    d_w = np.sqrt(((Z - Z.min()) ** 2).sum(axis=1))
    knee = int(np.argmax(d_w / (d_b + d_w + 1e-12)))
    knee_cfg = {'X_PV': float(df_m.iloc[knee]['X_PV']), 'X_Bat': float(df_m.iloc[knee]['X_Bat']),
                'X_Tank': float(df_m.iloc[knee]['X_Tank']),
                'TA': float(df_m.iloc[knee]['TA']), 'AC': float(df_m.iloc[knee]['AC']),
                'TG': float(df_m.iloc[knee]['TG'])}
    import json
    with open(f'_paper_exp1_knee{_TAG}.json', 'w', encoding='utf-8') as f:
        json.dump(knee_cfg, f, ensure_ascii=False, indent=2)
    print(f'>> TOPSIS 拐点: PV={knee_cfg["X_PV"]:.0f} Bat={knee_cfg["X_Bat"]:.0f} '
          f'Tank={knee_cfg["X_Tank"]:.0f}')

    # ---------------- 指标 ----------------
    def dominated_frac(front_a, front_b):
        """front_a 中被 front_b 任一点严格支配的比例。"""
        hit = 0
        for a in front_a:
            if any(all(mb <= ma for mb, ma in zip(b, a)) and
                   any(mb < ma for mb, ma in zip(b, a)) for b in front_b):
                hit += 1
        return hit / max(len(front_a), 1)

    frac = dominated_frac(front_rule, front_milp)
    lines = [
        f'规则基线前沿 {len(front_rule)} 点 | MILP 前沿 {len(front_milp)} 点',
        f'被 MILP 前沿支配的基线前沿点比例: {frac:.1%}',
        f'内层单次评价耗时: 规则 {rule_t / rule_n:.4f}s | '
        f'MILP {milp_t / milp_n:.4f}s '
        f'({rule_n} / {milp_n} 次)',
        '',
        '各目标最优值对比 (前沿上最小):',
        f'  TA   : 规则 {front_rule[:, 0].min():>13,.0f}  | MILP {front_milp[:, 0].min():>13,.0f}',
        f'  AC(t): 规则 {front_rule[:, 1].min():>13.1f}  | MILP {front_milp[:, 1].min():>13.1f}',
        f'  TG   : 规则 {front_rule[:, 2].min():>13,.0f}  | MILP {front_milp[:, 2].min():>13,.0f}',
    ]
    metrics = '\n'.join(lines)
    print('\n' + metrics)

    # ---------------- 落盘 ----------------
    with open(f'_paper_exp1_metrics{_TAG}.txt', 'w', encoding='utf-8') as f:
        f.write(metrics + '\n')

    # ---------------- 2D 投影图 (顶刊风格; 字号按页宽缩放后与图5纵轴一致, ★=TOPSIS推荐解) ----
    pairs = [(0, 1, 'TA (CNY)', 'AC (t)'),
             (0, 2, 'TA (CNY)', 'TG (kWh)'),
             (1, 2, 'AC (t)', 'TG (kWh)')]
    KO = [knee_cfg['TA'], knee_cfg['AC'], knee_cfg['TG']]
    fig, axes = plt.subplots(1, 3, figsize=(7.5, 2.9))
    for ax, (i, j, xl, yl) in zip(axes, pairs):
        ax.scatter(front_rule[:, i], front_rule[:, j], s=22, facecolors='none',
                   edgecolors='#D62728', linewidths=1.0, label='Fixed TOU strategy')
        ax.scatter(front_milp[:, i], front_milp[:, j], s=22, color='#1F77B4',
                   label='Nested MILP (proposed)')
        ax.scatter([KO[i]], [KO[j]], marker='*', s=380, c='#FFD700',
                   edgecolors='#8B6914', linewidths=0.8, zorder=6,
                   label='TOPSIS recommended')
        ax.set_xlabel(xl); ax.set_ylabel(yl)
    # 三面板共用一条顶部横排图例 (逐面板 loc='best' 会压住散点)
    _h, _l = axes[0].get_legend_handles_labels()
    fig.legend(_h, _l, ncol=3, loc='upper center', bbox_to_anchor=(0.5, 1.0),
               frameon=False, fontsize=9.5, handlelength=1.2, columnspacing=1.2)
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    fig.savefig(f'论文图片/图2_实验1_Pareto前沿对比{_TAG}.png', dpi=300, bbox_inches='tight')
    print('已保存: _paper_exp1_fronts.csv / 论文图片/图2_实验1_Pareto前沿对比.png / _paper_exp1_metrics.txt')


if __name__ == '__main__':
    main()
