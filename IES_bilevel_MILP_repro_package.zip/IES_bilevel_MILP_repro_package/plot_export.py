"""出图自动落盘 (供带视觉的模型审阅多尺度调度/容量规划图)。

用法: 在引擎的 plt.show() 之前调用 save_open_figures(prefix):
    plot_export.save_open_figures(f'mscale_{self.scenario}')

每次调用把当前已打开的所有 matplotlib figure 存为
figures/<YYYYmmdd_HHMMSS>/<prefix>_<n>.png, 并按运行时间建子目录防止互相覆盖,
原有 plt.show() 弹窗不受影响。
"""
import os
import time
import matplotlib.pyplot as plt


def save_open_figures(prefix, out_dir=None):
    """把当前所有已打开的 figure 存为 PNG, 返回保存的文件路径列表。"""
    if out_dir is None:
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'figures')
        stamp = time.strftime('%Y%m%d_%H%M%S')
        out_dir = os.path.join(base, stamp)
    os.makedirs(out_dir, exist_ok=True)

    # 前缀里不允许出现文件系统非法字符
    safe = ''.join(c if c.isalnum() or c in '-_' else '_' for c in str(prefix))

    saved = []
    for num in plt.get_fignums():
        fig = plt.figure(num)
        path = os.path.join(out_dir, f'{safe}_{num}.png')
        fig.savefig(path, dpi=150, bbox_inches='tight')
        saved.append(path)

    if saved:
        print(f'[出图落盘] {len(saved)} 张 -> {out_dir}')
    return saved
