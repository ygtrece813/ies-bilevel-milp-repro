# -*- coding: utf-8 -*-
"""30 种子批量驱动 (老师要求: 种子 42..71)
- 队列: seeds 45..71 (42/43/44 已完成), 3 个 worker 并行
- 每个种子用分块续存模式跑: CHUNK=25 代/进程, 退出码 2=未完(自动续), 0=完成
- 幂等: 前沿 CSV 已存在的种子直接跳过; 有断点状态文件的自动续跑
  => 中断(关机/关窗)后重新运行本脚本即可, 从断点继续, 已完成的不会重跑
日志: _seeds30_log.txt
"""
import os
import sys
import time
import queue
import threading
import subprocess
import datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)
LOG = os.path.join(ROOT, '_seeds30_log.txt')
SEEDS = list(range(45, 72))          # 27 个新种子
NWORKERS = 2
CHUNK = '25'                          # 代/进程, 崩溃最多损失约 20 分钟
TANK = '2000'                         # 与论文主实验口径一致
CHUNK_TIMEOUT = 5400                  # 单进程 90 min 兜底(正常约 20 min)


def log(msg):
    line = f"[{datetime.datetime.now():%m-%d %H:%M:%S}] {msg}"
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write(line + '\n')
    print(line, flush=True)


def fronts_csv(seed):
    return f'_paper_exp1_fronts_{seed}.csv'


def run_seed(seed):
    """跑完一个种子, 返回 'done'/'failed'。幂等可重启。"""
    if os.path.exists(fronts_csv(seed)):
        log(f'seed {seed}: 前沿已存在, 跳过')
        return 'done'
    fail = 0
    t0 = time.time()
    while True:
        if os.path.exists(fronts_csv(seed)):
            log(f'seed {seed}: 完成, 用时 {(time.time() - t0) / 60:.0f} min')
            return 'done'
        env = dict(os.environ, PYTHONIOENCODING='utf-8')
        cmd = [sys.executable, '_paper_exp1_compare.py', str(seed), TANK, '', CHUNK]
        with open(LOG, 'a', encoding='utf-8') as lf:
            lf.write(f"\n----- seed {seed} chunk start "
                     f"{datetime.datetime.now():%H:%M:%S} -----\n")
            lf.flush()
            try:
                r = subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT,
                                   timeout=CHUNK_TIMEOUT, env=env, cwd=ROOT)
                code = r.returncode
            except subprocess.TimeoutExpired:
                code = -99
                log(f'seed {seed}: 单进程超时(90min), 已杀掉, 重试')
        if code in (0, 2):
            if fail:
                log(f'seed {seed}: 重试成功 (退出码 {code})')
            fail = 0
        else:
            fail += 1
            log(f'seed {seed}: 异常退出码 {code}, 连续失败 {fail}/5')
            if fail >= 5:
                log(f'seed {seed}: 连续失败 5 次, 标记失败, 跳过')
                return 'failed'
            time.sleep(30)


def worker(q, wid):
    while True:
        try:
            seed = q.get_nowait()
        except queue.Empty:
            return
        log(f'worker{wid} 领取 seed {seed}')
        st = run_seed(seed)
        log(f'worker{wid}: seed {seed} -> {st}')


def main():
    q = queue.Queue()
    for s in SEEDS:
        q.put(s)
    log(f'=== 30种子批量启动: seeds {SEEDS[0]}..{SEEDS[-1]} (共{len(SEEDS)}个), '
        f'{NWORKERS} 并行, CHUNK={CHUNK} ===')
    t0 = time.time()
    ths = [threading.Thread(target=worker, args=(q, i + 1), daemon=True)
           for i in range(NWORKERS)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    done = [s for s in SEEDS if os.path.exists(fronts_csv(s))]
    failed = [s for s in SEEDS if s not in done]
    log(f'=== 全部结束: 用时 {(time.time() - t0) / 3600:.1f} h; '
        f'完成 {len(done)} 个: {done}; 失败/未完: {failed} ===')


if __name__ == '__main__':
    main()
