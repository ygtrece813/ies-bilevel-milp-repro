# -*- coding: utf-8 -*-
"""
小论文 补充实验 A: 电价结构 × 碳价水平 场景敏感性 (3×3 全因子, seed 42)
======================================================================
问题动机 (审稿视角): 实验 1 结论是否只在单一电价/碳价场景下成立?
设计: 电价结构 {T0 基准TOU 0.25/0.5/0.75, T1 拉大峰谷差 0.15/0.50/0.85,
      T2 平稳电价 0.50 全平} × 基础碳价 λ {150, 250, 500} 元/t,
      共 9 组合; (T0, 250) 即论文主实验, 直接复用 `_paper_exp1_fronts.csv`。
每场景双臂 (固定TOU规则 / 嵌套MILP) 各跑完整 NSGA-II (pop100 gen100 seed42),
调用加 --one 参数: 每进程只推进一个待跑场景后退出, 由外层循环换新进程
续跑 (防长跑内存累积, 单场景进度由前沿 CSV + 指标增量落盘保证);
协议与实验 1 完全一致; 基线臂阶梯碳价同步 λ (SEG_SLOPES), MILP 臂经
Parameters.economic.carbon_price 注入 (已验证: 默认路径逐位不变, λ 弹性精确)。

电价注入口径: 两臂均从契约 price_elec 读取 (FixedTOUEvaluator :79 /
MILPCapacityEngine :135), 故直接重写契约即可, 无需改动引擎。
T1/T2 通过档位映射保持 T0 的谷/平/峰时段结构, 只改价格水平
(T2 平价下 _price_classes 全档判为平段, 规则退化为简单策略 — 预期行为)。

输出: _paper_exp1_sens_T{t}_lam{l}.csv   每场景双臂前沿点
      _paper_exp1_sens_metrics.csv      汇总指标 (增量落盘, 可中断续跑)
"""
import sys
import os
import time
import copy
import random
import json
import joblib
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
ONE = '--one' in sys.argv   # 每进程只跑一个场景 (须在清空 argv 前捕获)

# 清空 argv 再 import, 使 compare 模块以默认 seed42/Tank2000 初始化
sys.argv = [sys.argv[0]]
import _paper_exp1_compare as E

SEED = 42
LAMS = [150.0, 250.0, 500.0]
TARIFFS = {
    'T0': None,                  # 基准 TOU 0.25/0.5/0.75 (主实验口径)
    'T1': (0.15, 0.50, 0.85),    # 拉大峰谷差 (均值不变 0.5)
    'T2': (0.50,),               # 平稳电价 (全平段)
}
FRONT_TPL = '_paper_exp1_sens_{t}_lam{l:.0f}.csv'
METRICS_CSV = '_paper_exp1_sens_metrics.csv'


def make_tariff(contract, spec):
    """按档位映射重写契约电价: 保持 T0 的谷/平/峰时段结构, 只改价格水平。
    spec 长度 = 3: 逐档 (谷/平/峰) 给价; = 1: 全档同一价 (平稳电价)。"""
    c = copy.deepcopy(contract)
    if spec is None:
        return c
    assert len(spec) in (1, 3), f'电价规格长度须为 1 或 3, 收到 {spec}'
    allp = np.concatenate([np.asarray(p, dtype=float) for p in c['price_elec'].values()])
    uniq = np.unique(np.round(allp, 6))
    assert len(uniq) == 3, f'基准契约应为 3 档电价, 实际 {uniq}'
    mids = (uniq[:-1] + uniq[1:]) / 2.0
    for d in c['price_elec']:
        p = np.asarray(c['price_elec'][d], dtype=float)
        cls = np.digitize(p, mids)          # 0/1/2 = 谷/平/峰
        lvl = spec[0] if len(spec) == 1 else np.take(np.asarray(spec), cls)
        c['price_elec'][d] = [float(v) for v in np.broadcast_to(lvl, p.shape)]
    return c


def dominated_frac(front_a, front_b):
    """front_a 中被 front_b 任一点严格支配的比例。"""
    hit = 0
    for a in front_a:
        if any(all(mb <= ma for mb, ma in zip(b, a)) and
               any(mb < ma for mb, ma in zip(b, a)) for b in front_b):
            hit += 1
    return hit / max(len(front_a), 1)


def knee_of(front, x):
    """TOPSIS (等权) 拐点配置, 与 compare.main 同式。"""
    f = np.asarray(front, dtype=float)
    z = (f - f.min(0)) / (f.max(0) - f.min(0) + 1e-12)
    d_b = np.sqrt(((z - z.max(0)) ** 2).sum(1))
    d_w = np.sqrt(((z - z.min(0)) ** 2).sum(1))
    k = int(np.argmax(d_w / (d_b + d_w + 1e-12)))
    return [float(v) for v in np.asarray(x)[k]]


def run_scenario(t_name, spec, lam, contract, reuse):
    """跑一个 (电价, 碳价) 场景双臂, 返回汇总指标行。"""
    tag = f'T{t_name} λ={lam:.0f}'
    t_wall = time.perf_counter()
    if reuse:
        df = pd.read_csv('_paper_exp1_fronts.csv', encoding='utf-8-sig')
        print(f'[{tag}] 复用主实验前沿 (rule {int((df.arm == "rule").sum())} 点 / '
              f'milp {int((df.arm == "milp").sum())} 点)', flush=True)
    else:
        random.seed(SEED)
        np.random.seed(SEED)
        E.SEG_SLOPES = [lam * (1 + 0.25 * k) for k in range(5)]   # 基线臂阶梯价同步 λ
        arm_r = E.BaselineArm(contract)
        done, res, _ = E.run_arm(arm_r, f'规则 {tag}', full=True)
        assert done, '规则臂未完成 (CHUNK 应为 0)'
        front_r, fx_r = res[0], res[1]
        arm_m = E.MILPArm(contract)
        arm_m.extra_params = {'economic': {'carbon_price': lam}}  # MILP 臂 λ 注入
        done, res, _ = E.run_arm(arm_m, f'MILP {tag}')
        assert done, 'MILP 臂未完成 (CHUNK 应为 0)'
        front_m, fx_m = res[0], res[1]
        df_r = pd.DataFrame(front_r, columns=['TA', 'AC', 'TG'])
        df_r['X_PV'], df_r['X_Bat'], df_r['X_Tank'] = fx_r[:, 0], fx_r[:, 1], fx_r[:, 2]
        df_r['arm'] = 'rule'
        df_m = pd.DataFrame(front_m, columns=['TA', 'AC', 'TG'])
        df_m['X_PV'], df_m['X_Bat'], df_m['X_Tank'] = fx_m[:, 0], fx_m[:, 1], fx_m[:, 2]
        df_m['arm'] = 'milp'
        pd.concat([df_r, df_m]).to_csv(
            FRONT_TPL.format(t=t_name, l=lam), index=False, encoding='utf-8-sig')
        df = pd.concat([df_r, df_m])

    fr = df[df.arm == 'rule'][['TA', 'AC', 'TG']].to_numpy()
    fm = df[df.arm == 'milp'][['TA', 'AC', 'TG']].to_numpy()
    xm = df[df.arm == 'milp'][['X_PV', 'X_Bat', 'X_Tank']].to_numpy()
    knee = knee_of(fm, xm)
    row = {
        'tariff': t_name, 'lam': lam,
        'frac_dom': dominated_frac(fr, fm),
        'TA_rule': fr[:, 0].min(), 'TA_milp': fm[:, 0].min(),
        'AC_rule': fr[:, 1].min(), 'AC_milp': fm[:, 1].min(),
        'TG_rule': fr[:, 2].min(), 'TG_milp': fm[:, 2].min(),
        'imp_TA': (fr[:, 0].min() - fm[:, 0].min()) / fr[:, 0].min(),
        'imp_AC': (fr[:, 1].min() - fm[:, 1].min()) / fr[:, 1].min(),
        'imp_TG': (fr[:, 2].min() - fm[:, 2].min()) / fr[:, 2].min(),
        'knee_PV': knee[0], 'knee_Bat': knee[1], 'knee_Tank': knee[2],
        'wall_min': (time.perf_counter() - t_wall) / 60.0,
    }
    return row


def main(one=False):
    base = joblib.load('ies_forecast_contract_eui.pkl')
    # 电价档位预检: T0 契约应恰为 3 档
    allp = np.concatenate([np.asarray(p, dtype=float) for p in base['price_elec'].values()])
    print(f'契约电价唯一档位: {np.unique(np.round(allp, 6))} | 典型日 {len(base["price_elec"])} 个')
    print(f'场景: {list(TARIFFS)} × λ={LAMS} | seed={SEED} pop={E.POP} gen={E.GEN}')
    print('=' * 72, flush=True)

    tariffs = {k: make_tariff(base, v) for k, v in TARIFFS.items()}
    # 增量续跑: 载入已有指标行, 避免覆写丢失历史场景
    if os.path.exists(METRICS_CSV):
        rows = pd.read_csv(METRICS_CSV, encoding='utf-8-sig').to_dict('records')
        print(f'载入已有指标 {len(rows)} 行 (增量续跑)')
    else:
        rows = []
    for t_name in TARIFFS:
        for lam in LAMS:
            reuse = (t_name == 'T0' and lam == 250.0)
            out = FRONT_TPL.format(t=t_name, l=lam)
            if not reuse and os.path.exists(out):
                print(f'[{t_name} λ={lam:.0f}] 前沿已存在, 跳过重跑 (增量续跑模式)')
                continue
            try:
                row = run_scenario(t_name, TARIFFS[t_name], lam, tariffs[t_name], reuse)
            except Exception as e:
                print(f'!! 场景 {t_name} λ={lam} 失败: {e}', flush=True)
                raise
            # 增量续跑防重复行: 复用/跳过的场景每次启动都会重算指标, 已有则不追加
            if not any(r['tariff'] == t_name and float(r['lam']) == lam for r in rows):
                rows.append(row)
            pd.DataFrame(rows).to_csv(METRICS_CSV, index=False, encoding='utf-8-sig')
            print(f'>> [{t_name} λ={lam:.0f}] 被支配比例 {row["frac_dom"]:.0%} | '
                  f'TA改善 {row["imp_TA"]:.1%} | AC改善 {row["imp_AC"]:.1%} | '
                  f'TG改善 {row["imp_TG"]:.1%} | 墙钟 {row["wall_min"]:.1f} min\n'
                  f'   拐点 PV={row["knee_PV"]:.0f} Bat={row["knee_Bat"]:.0f} '
                  f'Tank={row["knee_Tank"]:.0f}', flush=True)
            if one:
                break   # 防长跑内存累积: 每进程只推进一个场景, 由外层循环换新进程

    print('=' * 72)
    print('全部场景完成, 汇总:')
    print(pd.DataFrame(rows).to_string(index=False))
    print(f'指标已落盘: {METRICS_CSV}')


if __name__ == '__main__':
    main(one=ONE)
