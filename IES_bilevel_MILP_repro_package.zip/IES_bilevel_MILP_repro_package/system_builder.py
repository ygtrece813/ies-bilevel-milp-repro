import pulp
from energy_network import EnergyBus
from core_components import *
import numpy as np

# 💡 新增拓展设备类：光热光电一体化板
class PVTCollector:
    def __init__(self, name, capacity, profile_1kw):
        self.name = name
        self.capacity = capacity
        self.profile = profile_1kw
        self.vars = {}

    def build_variables(self, T):
        # 💡 核心修复：强制使用 List 列表推导式，与底层画图引擎的遍历逻辑保持绝对一致！
        self.vars['P_out'] = [pulp.LpVariable(f"{self.name}_P_out_{t}", lowBound=0) for t in range(T)]
        self.vars['Q_out'] = [pulp.LpVariable(f"{self.name}_Q_out_{t}", lowBound=0) for t in range(T)]

    def build_constraints(self, model, T, dt):
        for t in range(T):
            # 电力输出受限于光照
            model += self.vars['P_out'][t] <= self.capacity * self.profile[t]
            # 热力输出恒为电力的 3 倍
            model += self.vars['Q_out'][t] == self.vars['P_out'][t] * 3.0

# 💡 新增虚拟设备类：柔性需求响应 (IDR)
class VirtualDR:
    def __init__(self, name, dr_ratio, base_load):
        self.name = name
        self.dr_ratio = dr_ratio
        self.base_load = base_load
        self.vars = {}

    def build_variables(self, T):
        self.vars['P_shift_in'] = [pulp.LpVariable(f"{self.name}_shift_in_{t}", lowBound=0) for t in range(T)]
        self.vars['P_shift_out'] = [pulp.LpVariable(f"{self.name}_shift_out_{t}", lowBound=0) for t in range(T)]

    def build_constraints(self, model, T, dt):
        for t in range(T):
            # 严格受限于该时刻的原始负荷比例
            model += self.vars['P_shift_out'][t] <= self.base_load[t] * self.dr_ratio
            model += self.vars['P_shift_in'][t] <= self.base_load[t] * self.dr_ratio * 1.5


# 💡 新增拓展设备类：地源热泵 (超高 COP)
class GroundSourceHeatPump:
    def __init__(self, name, p_max, COP_H=4.80, COP_C=6.20):
        self.name = name
        self.p_max = p_max
        self.COP_H = COP_H
        self.COP_C = COP_C
        self.vars = {}

    def build_variables(self, T):
        # 严格使用列表推导式，与画图引擎完美兼容
        self.vars['P_elec_in'] = [pulp.LpVariable(f"{self.name}_P_in_{t}", lowBound=0) for t in range(T)]
        self.vars['Q_heat_out'] = [pulp.LpVariable(f"{self.name}_Q_h_out_{t}", lowBound=0) for t in range(T)]
        self.vars['Q_cool_out'] = [pulp.LpVariable(f"{self.name}_Q_c_out_{t}", lowBound=0) for t in range(T)]

    def build_constraints(self, model, T, dt):
        for t in range(T):
            model += self.vars['P_elec_in'][t] <= self.p_max
            # 严格热力学耦合：耗电 = 供热/制热COP + 供冷/制冷COP
            model += self.vars['P_elec_in'][t] == self.vars['Q_heat_out'][t] / self.COP_H + self.vars['Q_cool_out'][t] / self.COP_C

class SystemBuilder:
    def __init__(self, config_dict, T, dt):
        self.config = config_dict
        self.T = T
        self.dt = dt
        self.model = pulp.LpProblem("IES_Auto_Routing", pulp.LpMinimize)
        self.buses = {}
        self.components = {}
        self.base_cost = 0

    def build(self):
        for b in ["ElectricityBus", "HeatBus", "CoolBus", "GasBus", "HydrogenBus", "WasteHeatBus"]:
            self.buses[b] = EnergyBus(b)

        for comp_name, p in self.config["Components"].items():
            c_type = p["type"]

            if c_type == "PowerGrid":
                comp = PowerGrid(comp_name, p_max=p.get("p_max", 1e6), buy_price=0, p_sell_max=p.get("p_sell_max", 0))
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses[p.get("bus", "ElectricityBus")].connect_input(comp.vars['P_buy'])
                self.buses[p.get("bus", "ElectricityBus")].connect_output(comp.vars['P_sell'])

                buy_price = p.get("buy_price", 0.5);
                sell_price = p.get("sell_price", 0.3)
                env_cost = p.get("env_cost", 0.0)

                if isinstance(buy_price, (list, np.ndarray)):
                    self.base_cost += pulp.lpSum(
                        [comp.vars['P_buy'][t] * (buy_price[t] + env_cost) * self.dt for t in range(self.T)])
                    self.base_cost -= pulp.lpSum(
                        [comp.vars['P_sell'][t] * sell_price[t] * self.dt for t in range(self.T)])
                else:
                    self.base_cost += pulp.lpSum(
                        [comp.vars['P_buy'][t] * (buy_price + env_cost) * self.dt for t in range(self.T)])
                    self.base_cost -= pulp.lpSum([comp.vars['P_sell'][t] * sell_price * self.dt for t in range(self.T)])

            elif c_type == "GasNetwork":
                comp = GasNetwork(comp_name)
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses[p.get("bus", "GasBus")].connect_input(comp.vars['Gas_buy'])
                self.base_cost += pulp.lpSum(
                    [comp.vars['Gas_buy'][t] * comp.gas_price * self.dt for t in range(self.T)])

            # 💡 挂载外部氢能网络
            elif c_type == "HydrogenNetwork":
                comp = HydrogenNetwork(comp_name)
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses[p.get("bus", "HydrogenBus")].connect_input(comp.vars['H2_buy'])
                self.base_cost += pulp.lpSum([comp.vars['H2_buy'][t] * comp.h2_price * self.dt for t in range(self.T)])


            elif c_type == "WasteHeatBoiler":
                cap = p.get("capacity", 100000)
                comp = WasteHeatBoiler(comp_name, capacity=cap)
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.components[comp_name] = comp
                # 💡 动态母线挂载：从 GUI 画布连线中自动读取 input/output 目标
                in_buses = list(p.get("inputs", {}).values())
                out_buses = list(p.get("outputs", {}).values())
                if in_buses and in_buses[0] in self.buses:
                    self.buses[in_buses[0]].connect_output(comp.vars['Q_waste_in'])
                else:
                    print(f"⚠️ [WHB] 未检测到废热输入端连线，请检查画布")
                if out_buses and out_buses[0] in self.buses:
                    self.buses[out_buses[0]].connect_input(comp.vars['Q_heat_out'])
                else:
                    print(f"⚠️ [WHB] 未检测到热输出端连线，请检查画布")

            elif c_type == "RenewableSource":
                comp = RenewableSource(comp_name, capacity=p["capacity"], profile_1kw=p["profile"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses[p.get("bus", "ElectricityBus")].connect_input(comp.vars['P_out'])
                self.base_cost += pulp.lpSum([comp.vars['P_cut'][t] * 0.2 * self.dt for t in range(self.T)])

            elif c_type == "RenewableSource_PVT":
                comp = PVTCollector(comp_name, capacity=p["capacity"], profile_1kw=p["profile"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                # 注入电母线和热母线
                # 💡 核心修复：切断 GUI 传来的 "None" 幽灵参数，强行将其焊死在交流电母线上！
                self.buses["ElectricityBus"].connect_input(comp.vars['P_out'])
                self.buses["HeatBus"].connect_input(comp.vars['Q_out'])
                # 运维成本
                self.base_cost += pulp.lpSum([comp.vars['P_out'][t] * 0.05 * self.dt for t in range(self.T)])

            elif c_type == "AirSourceHeatPump":
                comp = AirSourceHeatPump(comp_name, p_max=p["capacity"], COP_H=4.18, COP_C=5.45)
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["ElectricityBus"].connect_output(comp.vars['P_elec_in'])
                self.buses["HeatBus"].connect_input(comp.vars['Q_heat_out'])
                self.buses["CoolBus"].connect_input(comp.vars['Q_cool_out'])
                self.base_cost += pulp.lpSum([comp.vars['P_elec_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "GroundSourceHeatPump":
                comp = GroundSourceHeatPump(comp_name, p_max=p["capacity"], COP_H=4.80, COP_C=6.20)
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                # 挂载到电、热、冷三维母线上
                self.buses["ElectricityBus"].connect_output(comp.vars['P_elec_in'])
                self.buses["HeatBus"].connect_input(comp.vars['Q_heat_out'])
                self.buses["CoolBus"].connect_input(comp.vars['Q_cool_out'])
                self.base_cost += pulp.lpSum([comp.vars['P_elec_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "Virtual_DR":
                dr_ratio = float(p.get("capacity", 15)) / 100.0
                base_load = p.get("profile", np.zeros(self.T))
                comp = VirtualDR(comp_name, dr_ratio, base_load)
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                # 💡 虚拟负荷接入电母线：Shift_out 相当于系统凭空多了电 (Supply)，Shift_in 相当于系统多耗了电 (Consume)
                self.buses["ElectricityBus"].connect_input(comp.vars['P_shift_out'])
                self.buses["ElectricityBus"].connect_output(comp.vars['P_shift_in'])

            elif c_type == "GasGenerator_CHP":
                comp = GasGenerator_CHP(comp_name, p_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["ElectricityBus"].connect_input(comp.vars['P_elec_out'])
                # 👇 尊重画布连线: CHP→废热母线→WHB 时走 WasteHeatBus, 默认行为不变
                chp_out = list(p.get("outputs", {}).values())
                chp_heat_target = chp_out[0] if (chp_out and chp_out[0] in self.buses) else "WasteHeatBus"
                self.buses[chp_heat_target].connect_input(comp.vars['Q_heat_out'])
                self.buses["GasBus"].connect_output(comp.vars['V_gas_in'])
                self.base_cost += pulp.lpSum([comp.vars['P_elec_out'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "ElectricBoiler":
                comp = ElectricBoiler(comp_name, p_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["ElectricityBus"].connect_output(comp.vars['P_elec_in'])
                self.buses["HeatBus"].connect_input(comp.vars['Q_heat_out'])
                self.base_cost += pulp.lpSum([comp.vars['P_elec_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "GasBoiler":
                comp = GasBoiler(comp_name, q_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["GasBus"].connect_output(comp.vars['V_gas_in'])
                self.buses["HeatBus"].connect_input(comp.vars['Q_heat_out'])
                self.base_cost += pulp.lpSum([comp.vars['Q_heat_out'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "ElectricChiller":
                comp = ElectricChiller(comp_name, q_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["ElectricityBus"].connect_output(comp.vars['P_elec_in'])
                self.buses["CoolBus"].connect_input(comp.vars['Q_cool_out'])
                self.base_cost += pulp.lpSum([comp.vars['P_elec_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "AbsorptionChiller":
                comp = AbsorptionChiller(comp_name, q_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["HeatBus"].connect_output(comp.vars['Q_heat_in'])
                self.buses["CoolBus"].connect_input(comp.vars['Q_cool_out'])
                self.base_cost += pulp.lpSum([comp.vars['Q_heat_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "Electrolyzer":
                comp = Electrolyzer(comp_name, p_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["ElectricityBus"].connect_output(comp.vars['P_elec_in'])
                self.buses["HydrogenBus"].connect_input(comp.vars['M_H2_out'])
                self.base_cost += pulp.lpSum([comp.vars['P_elec_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "HydrogenFuelCell":
                comp = HydrogenFuelCell(comp_name, m_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["HydrogenBus"].connect_output(comp.vars['M_H2_in'])
                self.buses["ElectricityBus"].connect_input(comp.vars['P_elec_out'])
                self.buses["HeatBus"].connect_input(comp.vars['Q_heat_out'])
                self.base_cost += pulp.lpSum([comp.vars['M_H2_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "MethanationReactor":
                comp = MethanationReactor(comp_name, m_max=p["capacity"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["HydrogenBus"].connect_output(comp.vars['M_H2_in'])
                self.buses["GasBus"].connect_input(comp.vars['V_Gas_out'])
                self.base_cost += pulp.lpSum([comp.vars['M_H2_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "CarbonCaptureSystem":
                comp = CarbonCaptureSystem(comp_name)
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["ElectricityBus"].connect_output(comp.vars['P_elec_in'])
                self.base_cost += pulp.lpSum([comp.vars['P_elec_in'][t] * 1e-4 * self.dt for t in range(self.T)])

            # 💡 统一将以下五类储能的 init_state 修改为 0.5 激活 DA 循环
            elif c_type == "Storage_Battery":
                e_cap = p.get("capacity", 1000);
                p_cap = p.get("power", e_cap * 0.2)
                comp = GenericStorage(comp_name, capacity=e_cap, power=p_cap, loss_rate=0.0, eta_in=0.95, eta_out=0.95,
                                      init_state=p.get("soc_init", 0.5))
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses[p.get("bus", "ElectricityBus")].connect_input(comp.vars['Flow_out'])
                self.buses[p.get("bus", "ElectricityBus")].connect_output(comp.vars['Flow_in'])
                aging_cost = p.get("aging_cost", 0.0)
                if aging_cost > 0:
                    self.base_cost += pulp.lpSum(
                        [(comp.vars['Flow_in'][t] + comp.vars['Flow_out'][t]) * aging_cost * self.dt for t in
                         range(self.T)])

            elif c_type == "Storage_CoolTank":
                e_cap = p.get("capacity", 15000);
                p_cap = p.get("power", e_cap * 0.2)
                comp = GenericStorage(comp_name, capacity=e_cap, power=p_cap, loss_rate=0.001, eta_in=0.99,
                                      eta_out=0.99, init_state=p.get("soc_init", 0.5))
                comp.build_variables(self.T);
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["CoolBus"].connect_input(comp.vars['Flow_out']);
                self.buses["CoolBus"].connect_output(comp.vars['Flow_in'])
                self.base_cost += pulp.lpSum(
                    [(comp.vars['Flow_in'][t] + comp.vars['Flow_out'][t]) * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "Storage_HeatTank":
                e_cap = p.get("capacity", 2000);
                p_cap = p.get("power", e_cap * 0.2)
                comp = GenericStorage(comp_name, capacity=e_cap, power=p_cap, loss_rate=0.002, eta_in=0.98,
                                      eta_out=0.98, init_state=p.get("soc_init", 0.5))
                comp.build_variables(self.T);
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["HeatBus"].connect_input(comp.vars['Flow_out']);
                self.buses["HeatBus"].connect_output(comp.vars['Flow_in'])
                self.base_cost += pulp.lpSum(
                    [(comp.vars['Flow_in'][t] + comp.vars['Flow_out'][t]) * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "Storage_ThermalTank":
                e_cap = p.get("capacity", 3000);
                p_cap = p.get("power", e_cap * 0.2)
                comp = GenericStorage(comp_name, capacity=e_cap, power=p_cap, loss_rate=0.001, eta_in=0.98,
                                      eta_out=0.98, init_state=p.get("soc_init", 0.5))
                comp.build_variables(self.T);
                comp.build_constraints(self.model, self.T, self.dt)
                # 根据config中的负荷数据判断接入冷/热母线
                active_bus = "CoolBus"
                for cn, ci in self.config.get("Components", {}).items():
                    if ci.get("type") == "EnergyLoad" and ci.get("target_bus") == "HeatBus":
                        if sum(ci.get("profile", [0])) > 0:
                            active_bus = "HeatBus"
                            break
                self.buses[active_bus].connect_input(comp.vars['Flow_out']);
                self.buses[active_bus].connect_output(comp.vars['Flow_in'])
                self.base_cost += pulp.lpSum(
                    [(comp.vars['Flow_in'][t] + comp.vars['Flow_out'][t]) * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "Storage_GasTank":
                e_cap = p.get("capacity", 2000);
                p_cap = p.get("power", e_cap * 0.2)
                comp = GenericStorage(comp_name, capacity=e_cap, power=p_cap, loss_rate=0.001, eta_in=0.98,
                                      eta_out=0.98, init_state=p.get("soc_init", 0.5))
                comp.build_variables(self.T);
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["GasBus"].connect_input(comp.vars['Flow_out']);
                self.buses["GasBus"].connect_output(comp.vars['Flow_in'])
                self.base_cost += pulp.lpSum(
                    [(comp.vars['Flow_in'][t] + comp.vars['Flow_out'][t]) * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "Storage_HydrogenTank":
                e_cap = p.get("capacity", 500);
                p_cap = p.get("power", e_cap * 0.2)
                comp = GenericStorage(comp_name, capacity=e_cap, power=p_cap, loss_rate=0.001, eta_in=0.98,
                                      eta_out=0.98, init_state=p.get("soc_init", 0.5))
                comp.build_variables(self.T);
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses["HydrogenBus"].connect_input(comp.vars['Flow_out']);
                self.buses["HydrogenBus"].connect_output(comp.vars['Flow_in'])
                self.base_cost += pulp.lpSum(
                    [(comp.vars['Flow_in'][t] + comp.vars['Flow_out'][t]) * 1e-4 * self.dt for t in range(self.T)])

            elif c_type == "EnergyLoad":
                comp = EnergyLoad(comp_name, load_profile=p["profile"])
                comp.build_variables(self.T)
                comp.build_constraints(self.model, self.T, self.dt)
                self.buses[p["target_bus"]].connect_output(comp.vars['P_demand'])
                # 💡 新增这部分：拦截所有未知组件，防止变量污染！
            else:
                print(f"⚠️ 警告：跳过未知类型组件 [{comp_name}] ({c_type})")
                continue

            self.components[comp_name] = comp

        # ⚠️ 此处只做软惩罚, 不做零失负荷硬约束!
        # 执行层 (DA/ID/RT 滚动调度) 面对带噪声的实际负荷, 物理上无法保证 100% 满供
        # (装机有限 + RT 扰动), 硬约束会导致窗口模型不可行 → 结果全零 → 图表全失负荷.
        # 零失负荷硬约束只属于规划层 (milp_capacity_engine 的 no_shortage_buses).
        for b in self.buses.values():
            b.build_balance_constraints(self.model, self.T)
            # ========================================================
            # 🚀 终极防呆：对“缺额(Short)”施加天价惩罚，杜绝求解器偷懒！
            # 注意：这里的变量名必须是 b
            # ========================================================
            for t in range(self.T):
                # 每断供 1kW 罚款 10000 元，确保求解器宁愿烧气也不敢断供
                self.base_cost += b.short_vars[t] * 10000

                # 给弃能(Dump)加上惩罚(0.5元/kWh, 与 config_params penalty.dump 对齐):
                # 旧值0.01太低, 仿真层同样会放任"超建光伏→大量弃电"
                self.base_cost += b.dump_vars[t] * 0.5

        # 删除原有的 self.base_cost += pulp.lpSum(...) 那一行

        # =======================================================
        # 💡 终极防白嫖补丁：强制典型日储能始末状态守恒 (End-of-Horizon Constraint)
        # =======================================================
        # 仅在日前 DA (24h) 阶段施加严厉的环形约束，确保不会凭空消耗初始能量
        if self.T * self.dt >= 24:
            for c_name, comp in self.components.items():
                # 遍历扫描所有带 SOC 或 State 的储能设备（电池、水罐、氢罐、气罐）
                if 'SOC' in comp.vars:
                    self.model += (comp.vars['SOC'][self.T - 1] == comp.vars['SOC'][0])
                elif 'State' in comp.vars:
                    self.model += (comp.vars['State'][self.T - 1] == comp.vars['State'][0])

        if self.config.get("Enable_Carbon_Trading", False):
            self._build_carbon_network()

    def _build_carbon_network(self):
        T = self.T;
        dt = self.dt
        E_quota = pulp.LpVariable("Total_Quota", 0)
        E_actual_gross = pulp.LpVariable("Total_Actual_Gross", 0)
        q_terms, a_terms = [], []

        if "State_Grid" in self.components:
            grid = self.components["State_Grid"]
            q_terms.append(pulp.lpSum(grid.vars['P_buy'][t] * 0.68 * dt for t in range(T)))
            a_terms.append(pulp.lpSum(grid.vars['P_buy'][t] * 1.08 * dt for t in range(T)))

        if "Gas_CHP" in self.components:
            chp = self.components["Gas_CHP"]
            q_terms.append(pulp.lpSum(chp.vars['V_gas_in'][t] * 9.7 * 0.612 * dt for t in range(T)))
            a_terms.append(pulp.lpSum(
                (chp.vars['P_elec_out'][t] * 0.195 + chp.vars['Q_heat_out'][t] * 0.39) * dt for t in range(T)))

        if "Gas_Boiler" in self.components:
            gb = self.components["Gas_Boiler"]
            q_terms.append(pulp.lpSum(gb.vars['V_gas_in'][t] * 9.7 * 0.306 * dt for t in range(T)))
            a_terms.append(pulp.lpSum(gb.vars['Q_heat_out'][t] * 0.195 * dt for t in range(T)))

        self.model += (E_quota == pulp.lpSum(q_terms))
        self.model += (E_actual_gross == pulp.lpSum(a_terms))

        E_captured = pulp.LpVariable("Total_Captured", 0)
        E_mr_used = pulp.LpVariable("Total_MR_Used", 0)
        E_stored = pulp.LpVariable("Total_Stored", 0)

        if "Carbon_Capture" in self.components:
            ccs = self.components["Carbon_Capture"]
            for t in range(T):
                co2_gen_t = 0
                if "Gas_CHP" in self.components:
                    co2_gen_t += (self.components["Gas_CHP"].vars['P_elec_out'][t] * 0.195 +
                                  self.components["Gas_CHP"].vars['Q_heat_out'][t] * 0.39) * dt
                if "Gas_Boiler" in self.components:
                    co2_gen_t += (self.components["Gas_Boiler"].vars['Q_heat_out'][t] * 0.195) * dt
                self.model += (ccs.vars['M_CO2_cap'][t] == 0.65 * co2_gen_t / dt)
            self.model += (E_captured == pulp.lpSum(ccs.vars['M_CO2_cap'][t] * dt for t in range(T)))
        else:
            self.model += (E_captured == 0)

        if "MethanationReactor" in self.components:
            mr = self.components["MethanationReactor"]
            self.model += (E_mr_used == pulp.lpSum(mr.vars['M_H2_in'][t] * 1.35 * dt for t in range(T)))
            self.model += (E_mr_used <= E_captured)
        else:
            self.model += (E_mr_used == 0)

        self.model += (E_stored == E_captured - E_mr_used)
        self.base_cost += E_stored * 0.0014

        E_env = E_actual_gross - E_captured
        E_net = pulp.LpVariable("Net_Carbon_Emissions", cat='Continuous')
        self.model += (E_net == E_env - E_quota)

        E_buy = pulp.LpVariable("Carbon_Buy", lowBound=0)
        E_sell = pulp.LpVariable("Carbon_Sell", lowBound=0)
        y_buy = pulp.LpVariable("Carbon_Is_Buy", cat='Binary')
        self.model += (E_buy <= 1e8 * y_buy)
        self.model += (E_sell <= 1e8 * (1 - y_buy))
        self.model += (E_net == E_buy - E_sell)

        z1 = pulp.LpVariable("z1", 0, 100000);
        z2 = pulp.LpVariable("z2", 0, 100000)
        z3 = pulp.LpVariable("z3", 0, 100000);
        z4 = pulp.LpVariable("z4", 0, 100000)
        z5 = pulp.LpVariable("z5", 0)
        self.model += (E_buy == z1 + z2 + z3 + z4 + z5)

        lam = 0.25;
        alpha = 0.25
        C_buy = lam * z1 + lam * (1 + alpha) * z2 + lam * (1 + 2 * alpha) * z3 + lam * (1 + 3 * alpha) * z4 + lam * (
                    1 + 4 * alpha) * z5
        C_sell = lam * E_sell

        self.base_cost += (C_buy - C_sell)

    def solve(self, time_limit=60):
        if not self.model.objective:
            self.model += self.base_cost
        self.model.solve(pulp.PULP_CBC_CMD(msg=0, timeLimit=time_limit))
        return pulp.LpStatus[self.model.status], pulp.value(self.model.objective)