import pyomo.environ as pyo
import numpy as np
import time
from config_params import DEFAULT_PARAMS, merge_params


class MILPCapacityEngine:
    """
    IES 旗舰版：全场景通用 MILP 容量规划引擎
    支持：电、热、冷、气、氢 五维母线自动路由，全设备矩阵自适应生成
    """

    def __init__(self, project_config, load_data_interface):
        self.config = project_config
        self.load_data = load_data_interface
        self.m = pyo.ConcreteModel()

        user_params = self.config.get("Parameters", {})
        scenario = self.config.get("Scenario", "Microgrid")
        self.params = merge_params(user_params, scenario)
        eco = self.params['economic']
        r = eco['interest_rate']
        N = eco['project_life']
        self.CRF = (r * (1 + r) ** N) / ((1 + r) ** N - 1) if r > 0 else 1.0 / N
        self.carbon_factor_grid = eco['carbon_factor_grid']
        self.carbon_tax_rate = eco['carbon_tax']

        raw_aging_cost = self.params.get('battery_aging', 0.015)
        if raw_aging_cost > 1.0:
            self.battery_aging_cost = raw_aging_cost / (2 * 1000.0)
        else:
            self.battery_aging_cost = raw_aging_cost

        # 零失负荷模式: 指定母线的 Short 变量直接锁 0 (硬约束, 优先级高于惩罚软约束)
        self.no_shortage_buses = set(self.params.get('no_shortage_buses') or [])

        typical_days = self.load_data.get('typical_days', {'Typical_1': 365})
        self.m.Days = pyo.Set(initialize=list(typical_days.keys()))
        self.m.T = pyo.Set(initialize=range(24))
        self.weights = typical_days

        self.active_goals = []
        if self.config.get("obj_cost", True): self.active_goals.append("Cost")
        if self.config.get("obj_opcost", False): self.active_goals.append("OpCost")
        if self.config.get("obj_carbon", False): self.active_goals.append("Carbon")
        if self.config.get("obj_grid", False): self.active_goals.append("Grid")

        if not self.active_goals:
            self.active_goals.append("Cost")

        self.active_buses = self.config.get("Buses", ["ElectricityBus", "HeatBus", "CoolBus", "GasBus", "HydrogenBus"])

        self.bus_supply = {b: {d: {t: [] for t in self.m.T} for d in self.m.Days} for b in self.active_buses}
        self.bus_consume = {b: {d: {t: [] for t in self.m.T} for d in self.m.Days} for b in self.active_buses}
        self.investment_costs = []
        self.maintenance_costs = []
        self._dev_inv = {}
        self._warned_buses = set()
        self.battery_throughputs = {d: {t: [] for t in self.m.T} for d in self.m.Days}
        self.operation_costs = {d: {t: [] for t in self.m.T} for d in self.m.Days}
        self.carbon_actual = {d: {t: [] for t in self.m.T} for d in self.m.Days}       # 实际碳排放 (kg)
        self.carbon_quota = {d: {t: [] for t in self.m.T} for d in self.m.Days}       # 免费碳配额 (kg)
        self.grid_interactions = {d: {t: [] for t in self.m.T} for d in self.m.Days}

        self._compute_reference_values()
        self._compute_replacement_factors()

    def _track_inv(self, dev_name, cap_var, unit_cost):
        inv_expr = cap_var * unit_cost
        self.investment_costs.append(inv_expr)
        mult = self.replacement_mult.get(dev_name, 1.0)
        if mult > 1.0:
            self.investment_costs.append(inv_expr * (mult - 1.0))

    def _add_supply(self, bus, var_obj, d, t, multiplier=1.0):
        if bus in self.active_buses:
            self.bus_supply[bus][d][t].append(var_obj * multiplier)
        elif bus not in self._warned_buses:
            self._warned_buses.add(bus)
            print(f"⚠️ [MILP引擎] 有设备接入未注册母线 [{bus}], 该能流被忽略, 请检查画布连线")

    def _add_consume(self, bus, var_obj, d, t, multiplier=1.0):
        if bus in self.active_buses:
            self.bus_consume[bus][d][t].append(var_obj * multiplier)
        elif bus not in self._warned_buses:
            self._warned_buses.add(bus)
            print(f"⚠️ [MILP引擎] 有设备接入未注册母线 [{bus}], 该能流被忽略, 请检查画布连线")

    def _compute_reference_values(self):
        total_kwh = 0.0
        for d_name, weight in self.weights.items():
            for bus in self.active_buses:
                loads = self.load_data.get('loads', {}).get(bus, {}).get(d_name, [])
                if len(loads) > 0:
                    total_kwh += sum(loads) * weight

        avg_price = 0.5
        prices = self.load_data.get('price_elec', {})
        all_prices = []
        for d_name in self.weights:
            if d_name in prices:
                all_prices.extend(list(prices[d_name]))
        if all_prices:
            avg_price = np.mean(all_prices)

        self.ref_cost = max(total_kwh * avg_price * 1.5, 5e5)
        self.ref_carbon = max(total_kwh * self.carbon_factor_grid / 1000.0, 50.0)
        self.ref_grid = max(total_kwh, 1e5)
        print(
            f"[MILP引擎] 自适应归一化参考值: cost={self.ref_cost / 1e4:.1f}万元, carbon={self.ref_carbon:.0f}吨, grid={self.ref_grid / 1e3:.0f}MWh")

    def _compute_replacement_factors(self):
        self.replacement_mult = {}
        repl = self.params.get('replacements', {})
        r = self.params['economic']['interest_rate']
        N = self.params['economic']['project_life']
        if not repl: return
        for dev, life in repl.items():
            mult = 1.0
            for yr in range(life, N, life):
                mult += 1.0 / ((1 + r) ** yr)
            self.replacement_mult[dev] = mult

    def build_model(self):
        m = self.m
        comps = self.config.get("Components", {})

        print("\n[MILP引擎] 正在编译数学模型拓扑矩阵...")

        if "State_Grid" in comps:
            allow_sell = bool(comps["State_Grid"].get("allow_sell", False))
            grid_limit_kw = self.params.get('grid_limit', 50000)

            m.Grid_P_buy = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            prices = self.load_data.get('price_elec', {d: [0.5] * 24 for d in m.Days})
            for d in m.Days:
                for t in m.T:
                    self._add_supply("ElectricityBus", m.Grid_P_buy[d, t], d, t)
                    self.operation_costs[d][t].append(m.Grid_P_buy[d, t] * prices[d][t])
                    self.carbon_actual[d][t].append(m.Grid_P_buy[d, t] * 1.08)     # κ_buy,a = 1.08
                    self.carbon_quota[d][t].append(m.Grid_P_buy[d, t] * 0.68)     # κ_buy = 0.68
                    self.grid_interactions[d][t].append(m.Grid_P_buy[d, t])

            if allow_sell:
                # 售电：从电母线消费（等同于向外送电），获得收益（负成本）
                m.Grid_P_sell = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
                for d in m.Days:
                    for t in m.T:
                        self._add_consume("ElectricityBus", m.Grid_P_sell[d, t], d, t)
                        self.operation_costs[d][t].append(-m.Grid_P_sell[d, t] * prices[d][t])
                        # 售电不产生碳排放（只是余电外送）
                        self.grid_interactions[d][t].append(m.Grid_P_sell[d, t])

                # 售电容量约束
                def rule_sell_limit(m, d, t):
                    return m.Grid_P_sell[d, t] <= grid_limit_kw
                m.Grid_sell_limit = pyo.Constraint(m.Days, m.T, rule=rule_sell_limit)

        if "City_GasNet" in comps:
            m.Gas_buy = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            price_gas = self.params['fuel_prices']['gas']
            for d in m.Days:
                for t in m.T:
                    self._add_supply("GasBus", m.Gas_buy[d, t], d, t, multiplier=9.7)
                    self.operation_costs[d][t].append(m.Gas_buy[d, t] * price_gas)
                    # 碳配额/实际追踪落在设备级 (CHP/GB)，不在气网级重复计数

        if "City_H2Net" in comps:
            m.H2_buy = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            price_h2 = self.params['fuel_prices']['h2']
            for d in m.Days:
                for t in m.T:
                    self._add_supply("HydrogenBus", m.H2_buy[d, t], d, t)
                    self.operation_costs[d][t].append(m.H2_buy[d, t] * price_h2)

        if "Roof_PV" in comps:
            pv_bounds = self.params['capacity_bounds'].get('Roof_PV', [0, None])
            m.PV_Cap = pyo.Var(within=pyo.NonNegativeReals,
                               bounds=(pv_bounds[0], pv_bounds[1] if pv_bounds[1] is not None else None))
            m.PV_P_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            pv_cost = self.params['device_costs']['Roof_PV']
            self._track_inv("Roof_PV", m.PV_Cap, pv_cost)
            pv_maint = self.params['maintenance_rates']['Roof_PV']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.PV_P_out[d, t] * pv_maint * self.weights[d])

            def rule_pv(m, d, t):
                return m.PV_P_out[d, t] <= m.PV_Cap * self.load_data['profiles']['PV'][d][t]

            m.PV_lim = pyo.Constraint(m.Days, m.T, rule=rule_pv)
            for d in m.Days:
                for t in m.T: self._add_supply("ElectricityBus", m.PV_P_out[d, t], d, t)

        # =====================================================================
        # 💡 新增拓展设备：光热光电一体化板 (PVT) 的双能流矩阵约束
        # =====================================================================
        if "PVT_Collector" in comps:
            pvt_bounds = self.params['capacity_bounds'].get('PVT_Collector', [0, None])
            # 定义决策变量：装机容量 (电功率基准)
            m.PVT_Cap = pyo.Var(within=pyo.NonNegativeReals,
                                bounds=(pvt_bounds[0], pvt_bounds[1] if pvt_bounds[1] is not None else None))
            # 定义状态变量：产电量 和 产热量
            m.PVT_P_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.PVT_Q_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

            # 投资与维护成本核算
            pvt_cost = self.params['device_costs'].get('PVT_Collector', 3500)
            self._track_inv("PVT_Collector", m.PVT_Cap, pvt_cost)
            pvt_maint = self.params['maintenance_rates'].get('PVT_Collector', 0.02)
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append((m.PVT_P_out[d, t] + m.PVT_Q_out[d, t]) * pvt_maint * self.weights[d])

            # 物理边界约束 1：电功率受限于环境光照曲线
            def rule_pvt_elec(m, d, t):
                return m.PVT_P_out[d, t] <= m.PVT_Cap * self.load_data['profiles']['PV'][d][t]

            # 物理边界约束 2：热电耦合强约束 (产热量恒定为产电量的 3 倍)
            def rule_pvt_heat(m, d, t):
                return m.PVT_Q_out[d, t] == m.PVT_P_out[d, t] * 3.0

            m.PVT_elec_lim = pyo.Constraint(m.Days, m.T, rule=rule_pvt_elec)
            m.PVT_heat_conv = pyo.Constraint(m.Days, m.T, rule=rule_pvt_heat)

            # 将能量注入电、热双母线
            for d in m.Days:
                for t in m.T:
                    self._add_supply("ElectricityBus", m.PVT_P_out[d, t], d, t)
                    self._add_supply("HeatBus", m.PVT_Q_out[d, t], d, t)

        if "Wind_Farm" in comps:
            w_bounds = self.params['capacity_bounds'].get('Wind_Farm', [0, None])
            m.Wind_Cap = pyo.Var(within=pyo.NonNegativeReals,
                                 bounds=(w_bounds[0], w_bounds[1] if w_bounds[1] is not None else None))
            m.Wind_P_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            wc = self.params['device_costs']['Wind_Farm']
            self._track_inv("Wind_Farm", m.Wind_Cap, wc)
            wind_maint = self.params['maintenance_rates']['Wind_Farm']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.Wind_P_out[d, t] * wind_maint * self.weights[d])

            def rule_wind(m, d, t):
                return m.Wind_P_out[d, t] <= m.Wind_Cap * self.load_data['profiles']['Wind'][d][t]

            m.Wind_lim = pyo.Constraint(m.Days, m.T, rule=rule_wind)
            for d in m.Days:
                for t in m.T: self._add_supply("ElectricityBus", m.Wind_P_out[d, t], d, t)

        if "Main_ASHP" in comps:
            cop_h = 4.18  # 制热 COP
            cop_c = 5.45  # 制冷 COP

            # 1. 定义三个连续变量
            m.ASHP_P_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.ASHP_Heat_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.ASHP_Cool_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)  # 💡 新增制冷输出

            # 2. 统一容量上限
            ashp_b = self.params['capacity_bounds'].get('Main_ASHP', [0, None])
            m.ASHP_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(ashp_b[0], ashp_b[1] if ashp_b[1] is not None else None))

            # 投资与维护
            ac = self.params['device_costs']['Main_ASHP']
            self._track_inv("Main_ASHP", m.ASHP_Cap, ac)
            ashp_maint = self.params['maintenance_rates']['Main_ASHP']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.ASHP_P_in[d, t] * ashp_maint * self.weights[d])

            # 3. 核心物理叠加方程：总耗电 = 制热耗电 + 制冷耗电
            def rule_ashp_power(m, d, t):
                return m.ASHP_P_in[d, t] == (m.ASHP_Heat_out[d, t] / cop_h) + (m.ASHP_Cool_out[d, t] / cop_c)
            m.ASHP_power_eq = pyo.Constraint(m.Days, m.T, rule=rule_ashp_power)

            # 4. 核心容量约束：总输入功率不能超过设备容量
            def rule_ashp_cap_limit(m, d, t):
                return m.ASHP_P_in[d, t] <= m.ASHP_Cap
            m.ASHP_cap_eq = pyo.Constraint(m.Days, m.T, rule=rule_ashp_cap_limit)

            # 5. 接驳三大母线 (强行兜底接驳，防止 GUI 空连线导致断流！)
            in_buses = list(comps["Main_ASHP"].get("inputs", {}).values())
            out_buses = list(comps["Main_ASHP"].get("outputs", {}).values())

            # 防御性回退: 连线母线未注册时退回 ElectricityBus, 避免耗电凭空消失
            bus_in = in_buses[0] if (in_buses and in_buses[0] in self.active_buses) else "ElectricityBus"

            for d in m.Days:
                for t in m.T:
                    self._add_consume(bus_in, m.ASHP_P_in[d, t], d, t)

                    # 💡 核心修复：不要管 GUI 传没传线，强行把它的输出管子插进冷热母线！
                    # （如果在微电网场景不需要冷，冷负荷为0，m.ASHP_Cool_out 会被矩阵自动压死为0，绝对不影响！）
                    self._add_supply("HeatBus", m.ASHP_Heat_out[d, t], d, t)
                    self._add_supply("CoolBus", m.ASHP_Cool_out[d, t], d, t)

        # =====================================================================
        # 💡 新增拓展设备：地源热泵 (GSHP) 的强能流矩阵约束
        # =====================================================================
        if "Ground_Source_HP" in comps:
            gshp_b = self.params['capacity_bounds'].get('Ground_Source_HP', [0, None])
            # 定义决策变量：装机容量 (输入电功率基准)
            m.GSHP_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(gshp_b[0], gshp_b[1] if gshp_b[1] is not None else None))
            # 定义状态变量：耗电量、产热量、产冷量
            m.GSHP_P_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.GSHP_Q_h = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.GSHP_Q_c = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

            # 投资与维护费用计算
            gc = self.params['device_costs']['Ground_Source_HP']
            self._track_inv("Ground_Source_HP", m.GSHP_Cap, gc)
            gshp_maint = self.params['maintenance_rates']['Ground_Source_HP']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.GSHP_P_in[d, t] * gshp_maint * self.weights[d])

            # 物理耦合约束：凸显地源热泵的极高能效优势 (制热 COP = 4.80，制冷 COP = 6.20)
            def rule_gshp_conv(m, d, t):
                return m.GSHP_P_in[d, t] == m.GSHP_Q_h[d, t] / 4.80 + m.GSHP_Q_c[d, t] / 6.20

            def rule_gshp_cap(m, d, t):
                return m.GSHP_P_in[d, t] <= m.GSHP_Cap

            m.GSHP_conv = pyo.Constraint(m.Days, m.T, rule=rule_gshp_conv)
            m.GSHP_lim = pyo.Constraint(m.Days, m.T, rule=rule_gshp_cap)

            # 将多维能量流网络顺畅并入大母线网络
            for d in m.Days:
                for t in m.T:
                    self._add_consume("ElectricityBus", m.GSHP_P_in[d, t], d, t)
                    self._add_supply("HeatBus", m.GSHP_Q_h[d, t], d, t)
                    self._add_supply("CoolBus", m.GSHP_Q_c[d, t], d, t)

        if "Gas_CHP" in comps:
            chp_b = self.params['capacity_bounds'].get('Gas_CHP', [0, None])
            m.CHP_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(chp_b[0], chp_b[1] if chp_b[1] is not None else None))
            m.CHP_Gas_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.CHP_P_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

            if self.config.get("Scenario", "Microgrid") == "Hydrogen":
                m.CHP_Heat_waste = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

                def rule_chp_conv1(m, d, t):
                    return m.CHP_P_out[d, t] == m.CHP_Gas_in[d, t] * 9.7 * 0.35

                def rule_chp_waste(m, d, t):
                    return m.CHP_Heat_waste[d, t] == m.CHP_P_out[d, t] * 1.571428

                def rule_chp_cap(m, d, t):
                    return m.CHP_P_out[d, t] <= m.CHP_Cap

                m.CHP_conv1 = pyo.Constraint(m.Days, m.T, rule=rule_chp_conv1)
                m.CHP_waste = pyo.Constraint(m.Days, m.T, rule=rule_chp_waste)
                m.CHP_lim = pyo.Constraint(m.Days, m.T, rule=rule_chp_cap)

                for d in m.Days:
                    for t in m.T:
                        self._add_consume("GasBus", m.CHP_Gas_in[d, t], d, t, multiplier=9.7)
                        self._add_supply("ElectricityBus", m.CHP_P_out[d, t], d, t)
                        # 👇 核心：把原本直连的 HeatBus 改为排入 WasteHeatBus！
                        self._add_supply("WasteHeatBus", m.CHP_Heat_waste[d, t], d, t)
                        # 论文 Eq.(9): E_GT,a = κ_e_GT × P_GT,e + κ_h_GT × P_GT,h
                        self.carbon_actual[d][t].append(
                            m.CHP_P_out[d, t] * 0.195 + m.CHP_Heat_waste[d, t] * 0.39)
                        # 论文 Eq.(8) 修正: 免费配额 = ρ × 原始实际排放, ρ = κ_q/κ_a = 0.68/1.08
                        # (统一基准率规则: 排放低于基准线→可售余量; 绝不复超实际排放的配额,
                        #  旧口径 κ_GT=0.612/单位气 = 2.5×实际, 会虚增可售配额)
                        self.carbon_quota[d][t].append(
                            (0.68 / 1.08) * (m.CHP_P_out[d, t] * 0.195 + m.CHP_Heat_waste[d, t] * 0.39))
            else:
                # 仅当用户真的画了 CHP→废热母线→WHB 时才改道, 默认仍进 HeatBus
                chp_out = list(comps["Gas_CHP"].get("outputs", {}).values())
                chp_heat_target = "WasteHeatBus" if ("WHB" in comps and "WasteHeatBus" in chp_out) else "HeatBus"

                m.CHP_Q_h = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

                def rule_chp_conv1(m, d, t):
                    return m.CHP_P_out[d, t] == m.CHP_Gas_in[d, t] * 9.7 * 0.35

                def rule_chp_conv2(m, d, t):
                    return m.CHP_Q_h[d, t] == m.CHP_Gas_in[d, t] * 9.7 * 0.45

                def rule_chp_cap(m, d, t):
                    return m.CHP_P_out[d, t] <= m.CHP_Cap

                m.CHP_conv1 = pyo.Constraint(m.Days, m.T, rule=rule_chp_conv1)
                m.CHP_conv2 = pyo.Constraint(m.Days, m.T, rule=rule_chp_conv2)
                m.CHP_lim = pyo.Constraint(m.Days, m.T, rule=rule_chp_cap)
                for d in m.Days:
                    for t in m.T:
                        self._add_consume("GasBus", m.CHP_Gas_in[d, t], d, t, multiplier=9.7)
                        self._add_supply("ElectricityBus", m.CHP_P_out[d, t], d, t)
                        self._add_supply(chp_heat_target, m.CHP_Q_h[d, t], d, t)
                        # 论文 Eq.(9): GT 实际碳排放 (电 + 热)
                        self.carbon_actual[d][t].append(
                            m.CHP_P_out[d, t] * 0.195 + m.CHP_Q_h[d, t] * 0.39)
                        # 论文 Eq.(8) 修正: 免费配额 = ρ × 原始实际排放 (ρ = 0.68/1.08, 同上)
                        self.carbon_quota[d][t].append(
                            (0.68 / 1.08) * (m.CHP_P_out[d, t] * 0.195 + m.CHP_Q_h[d, t] * 0.39))

            cc = self.params['device_costs']['Gas_CHP']
            self._track_inv("Gas_CHP", m.CHP_Cap, cc)
            chp_maint = self.params['maintenance_rates']['Gas_CHP']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.CHP_P_out[d, t] * chp_maint * self.weights[d])

        if "Gas_Boiler" in comps:
            gbb = self.params['capacity_bounds'].get('Gas_Boiler', [0, None])
            m.GB_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(gbb[0], gbb[1] if gbb[1] is not None else None))
            m.GB_Gas_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            gb_c = self.params['device_costs'].get('Gas_Boiler', 400)
            self._track_inv("Gas_Boiler", m.GB_Cap, gb_c)
            gb_maint = self.params['maintenance_rates'].get('Gas_Boiler', 0.015)
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.GB_Gas_in[d, t] * 9.7 * 0.75 * gb_maint * self.weights[d])

            def rule_gb_cap(m, d, t):
                return m.GB_Gas_in[d, t] * 9.7 * 0.75 <= m.GB_Cap

            m.GB_lim = pyo.Constraint(m.Days, m.T, rule=rule_gb_cap)
            for d in m.Days:
                for t in m.T:
                    self._add_consume("GasBus", m.GB_Gas_in[d, t], d, t, multiplier=9.7)
                    self._add_supply("HeatBus", m.GB_Gas_in[d, t], d, t, multiplier=(9.7 * 0.75))
                    # 论文 Eq.(9): E_GB,a = κ_GB,a × P_GB,h = 0.195 × (Gas × 9.7 × 0.75)
                    self.carbon_actual[d][t].append(m.GB_Gas_in[d, t] * 9.7 * 0.75 * 0.195)
                    # 论文 Eq.(8) 修正: 免费配额 = ρ × 原始实际排放 (ρ = 0.68/1.08, 同 CHP;
                    #  旧口径 0.306/单位气 = 2.1×实际, 同样虚增可售配额)
                    self.carbon_quota[d][t].append(
                        (0.68 / 1.08) * (m.GB_Gas_in[d, t] * 9.7 * 0.75 * 0.195))

        # =======================================================
        # 💡 余热锅炉 (WHB) 的专属 MILP 物理矩阵
        # =======================================================
        if "WHB" in comps:
            m.WHB_Heat_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.WHB_Heat_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

            # 提取容量变量 (接收 NSGA-II 传递的值)
            whb_b = self.params['capacity_bounds'].get('WHB', [0, None])
            m.WHB_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(whb_b[0], whb_b[1] if whb_b[1] is not None else None))

            whb_cost = self.params['device_costs'].get('WHB', 400)
            self._track_inv("WHB", m.WHB_Cap, whb_cost)
            whb_maint = self.params['maintenance_rates'].get('WHB', 0.015)
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.WHB_Heat_out[d, t] * whb_maint * self.weights[d])

            def rule_whb_conv(m, d, t):
                return m.WHB_Heat_out[d, t] == m.WHB_Heat_in[d, t] * 0.75  # 废热回收效率
            m.WHB_conv_eq = pyo.Constraint(m.Days, m.T, rule=rule_whb_conv)

            def rule_whb_cap(m, d, t):
                return m.WHB_Heat_out[d, t] <= m.WHB_Cap
            m.WHB_cap_eq = pyo.Constraint(m.Days, m.T, rule=rule_whb_cap)

            for d in m.Days:
                for t in m.T:
                    # 极其冷血的物理闭环：从废热母线抽废热，转化为有效热注入热母线
                    self._add_consume("WasteHeatBus", m.WHB_Heat_in[d, t], d, t)
                    self._add_supply("HeatBus", m.WHB_Heat_out[d, t], d, t)

        # ===============================================================
        # 碳捕集系统 CCS (论文 Eq.7, GUI 勾选"阶梯碳交易与碳捕集"触发)
        # η=0.65, e_ccs=0.269 MWh/t, 无容量上限(理想跟随型)
        # ===============================================================
        if "Carbon_Capture" in comps:
            has_chp = "Gas_CHP" in comps
            has_gb = "Gas_Boiler" in comps
            is_h2 = self.config.get("Scenario", "Microgrid") == "Hydrogen"

            m.CCS_Captured = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            m.CCS_P_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

            def rule_ccs_capture(m, d, t):
                total_emis = 0.0
                if has_chp:
                    if is_h2:
                        total_emis += m.CHP_P_out[d, t] * 0.195 + m.CHP_Heat_waste[d, t] * 0.39
                    else:
                        total_emis += m.CHP_P_out[d, t] * 0.195 + m.CHP_Q_h[d, t] * 0.39
                if has_gb:
                    total_emis += m.GB_Gas_in[d, t] * 9.7 * 0.75 * 0.195
                return m.CCS_Captured[d, t] == 0.65 * total_emis

            def rule_ccs_power(m, d, t):
                return m.CCS_P_in[d, t] == 0.269 * m.CCS_Captured[d, t]

            m.CCS_capture_eq = pyo.Constraint(m.Days, m.T, rule=rule_ccs_capture)
            m.CCS_power_eq = pyo.Constraint(m.Days, m.T, rule=rule_ccs_power)

            for d in m.Days:
                for t in m.T:
                    self._add_consume("ElectricityBus", m.CCS_P_in[d, t], d, t)
                    # 捕集的 CO2 不进入大气 → 从碳排放中扣除
                    self.carbon_actual[d][t].append(-m.CCS_Captured[d, t])

            # CCS 维护: 55 ¥/MWh = 0.055 ¥/kWh
            ccs_maint_rate = 0.055
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.CCS_P_in[d, t] * ccs_maint_rate * self.weights[d])

        if "Elec_Boiler" in comps:
            eb_b = self.params['capacity_bounds'].get('Elec_Boiler', [0, None])
            m.EB_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(eb_b[0], eb_b[1] if eb_b[1] is not None else None))
            m.EB_P_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            ec_eb = self.params['device_costs']['Elec_Boiler']
            self._track_inv("Elec_Boiler", m.EB_Cap, ec_eb)
            eb_maint = self.params['maintenance_rates']['Elec_Boiler']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.EB_P_in[d, t] * 0.95 * eb_maint * self.weights[d])

            def rule_eb_cap(m, d, t):
                return m.EB_P_in[d, t] <= m.EB_Cap

            m.EB_lim = pyo.Constraint(m.Days, m.T, rule=rule_eb_cap)
            for d in m.Days:
                for t in m.T:
                    self._add_consume("ElectricityBus", m.EB_P_in[d, t], d, t)
                    self._add_supply("HeatBus", m.EB_P_in[d, t], d, t, multiplier=0.95)

        if "Elec_Chiller" in comps:
            ecb = self.params['capacity_bounds'].get('Elec_Chiller', [0, None])
            m.EC_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(ecb[0], ecb[1] if ecb[1] is not None else None))
            m.EC_P_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            ec_cost = self.params['device_costs']['Elec_Chiller']
            self._track_inv("Elec_Chiller", m.EC_Cap, ec_cost)
            ec_maint = self.params['maintenance_rates']['Elec_Chiller']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.EC_P_in[d, t] * 4.0 * ec_maint * self.weights[d])

            def rule_ec_cap(m, d, t):
                return m.EC_P_in[d, t] * 4.0 <= m.EC_Cap

            m.EC_lim = pyo.Constraint(m.Days, m.T, rule=rule_ec_cap)
            for d in m.Days:
                for t in m.T:
                    self._add_consume("ElectricityBus", m.EC_P_in[d, t], d, t)
                    self._add_supply("CoolBus", m.EC_P_in[d, t], d, t, multiplier=4.0)

        if "MethanationReactor" in comps:
            mrb = self.params['capacity_bounds'].get('MethanationReactor', [0, None])
            m.MR_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(mrb[0], mrb[1] if mrb[1] is not None else None))
            m.MR_P_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            mr_c = self.params['device_costs'].get('MethanationReactor', 5000)
            self._track_inv("MethanationReactor", m.MR_Cap, mr_c)
            mr_maint = self.params['maintenance_rates'].get('MethanationReactor', 0.02)
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.MR_P_in[d, t] * mr_maint * self.weights[d])

            def rule_mr_cap(m, d, t):
                return m.MR_P_in[d, t] <= m.MR_Cap

            m.MR_lim = pyo.Constraint(m.Days, m.T, rule=rule_mr_cap)
            for d in m.Days:
                for t in m.T:
                    self._add_consume("HydrogenBus", m.MR_P_in[d, t], d, t)
                    self._add_supply("GasBus", m.MR_P_in[d, t], d, t, multiplier=(39.54 * 0.6))
                    self._add_supply("HeatBus", m.MR_P_in[d, t], d, t, multiplier=(39.54 * 0.15))

                    if self.config.get("Scenario", "Microgrid") == "Hydrogen":
                        self.carbon_actual[d][t].append(-m.MR_P_in[d, t] * 1.35)

        if "Abs_Chiller" in comps:
            acb = self.params['capacity_bounds'].get('Abs_Chiller', [0, None])
            m.AC_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(acb[0], acb[1] if acb[1] is not None else None))
            m.AC_Q_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            ac_cost = self.params['device_costs']['Abs_Chiller']
            self._track_inv("Abs_Chiller", m.AC_Cap, ac_cost)
            ac_maint = self.params['maintenance_rates']['Abs_Chiller']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.AC_Q_in[d, t] * 1.2 * ac_maint * self.weights[d])

            def rule_ac_cap(m, d, t):
                return m.AC_Q_in[d, t] * 1.2 <= m.AC_Cap

            m.AC_lim = pyo.Constraint(m.Days, m.T, rule=rule_ac_cap)
            for d in m.Days:
                for t in m.T:
                    self._add_consume("HeatBus", m.AC_Q_in[d, t], d, t)
                    self._add_supply("CoolBus", m.AC_Q_in[d, t], d, t, multiplier=1.2)

        if "Electrolyzer" in comps:
            elb = self.params['capacity_bounds'].get('Electrolyzer', [0, None])
            m.EL_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(elb[0], elb[1] if elb[1] is not None else None))
            m.EL_P_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            el_c = self.params['device_costs']['Electrolyzer']
            self._track_inv("Electrolyzer", m.EL_Cap, el_c)
            el_maint = self.params['maintenance_rates']['Electrolyzer']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.EL_P_in[d, t] * el_maint * self.weights[d])

            def rule_el_cap(m, d, t):
                return m.EL_P_in[d, t] <= m.EL_Cap

            m.EL_lim = pyo.Constraint(m.Days, m.T, rule=rule_el_cap)
            for d in m.Days:
                for t in m.T:
                    self._add_consume("ElectricityBus", m.EL_P_in[d, t], d, t)
                    self._add_supply("HydrogenBus", m.EL_P_in[d, t], d, t, multiplier=(0.75 / 39.54))
                    self._add_supply("HeatBus", m.EL_P_in[d, t], d, t, multiplier=0.20)

        if "HydrogenFuelCell" in comps:
            hfcb = self.params['capacity_bounds'].get('HydrogenFuelCell', [0, None])
            m.HFC_Cap = pyo.Var(within=pyo.NonNegativeReals, bounds=(hfcb[0], hfcb[1] if hfcb[1] is not None else None))
            m.HFC_H2_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
            hfc_c = self.params['device_costs']['HydrogenFuelCell']
            self._track_inv("HydrogenFuelCell", m.HFC_Cap, hfc_c)
            hfc_maint = self.params['maintenance_rates']['HydrogenFuelCell']
            for d in m.Days:
                for t in m.T:
                    self.maintenance_costs.append(m.HFC_H2_in[d, t] * 39.54 * hfc_maint * self.weights[d])

            def rule_hfc_cap(m, d, t):
                return m.HFC_H2_in[d, t] * 39.54 * 0.8 <= m.HFC_Cap

            m.HFC_lim = pyo.Constraint(m.Days, m.T, rule=rule_hfc_cap)
            for d in m.Days:
                for t in m.T:
                    self._add_consume("HydrogenBus", m.HFC_H2_in[d, t], d, t)
                    self._add_supply("ElectricityBus", m.HFC_H2_in[d, t], d, t, multiplier=(39.54 * 0.8))
                    self._add_supply("HeatBus", m.HFC_H2_in[d, t], d, t, multiplier=(39.54 * 0.15))

        # =====================================================================
        # 💡 核心升级：模块 4 储能模型矩阵 (动态接入 GUI 参数，并修复 SOC 下限约束漏洞)
        # =====================================================================
        storage_bus_map = {
            "Battery_Array": ["ElectricityBus"],
            "Heat_Tank": ["HeatBus"],
            "Cool_Tank": ["CoolBus"],
            "Thermal_Tank": ["HeatBus", "CoolBus"],
            "Hydrogen_Tank": ["HydrogenBus"],
            "Gas_Tank": ["GasBus"],
        }

        for s_name, bus_list in storage_bus_map.items():
            if s_name in comps:
                # 👉 这里现在会严格读取由 GUI 面板强行灌入进来的动态数据
                sp = self.params['storage_params'].get(s_name, {})
                s_bounds = self.params['capacity_bounds'].get(s_name, [0, None])
                lb = s_bounds[0] if s_bounds[0] is not None else 0
                ub = s_bounds[1] if s_bounds[1] is not None else None
                cap_var = pyo.Var(within=pyo.NonNegativeReals, bounds=(lb, ub))
                p_in = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
                p_out = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)
                state = pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals)

                setattr(m, f"{s_name}_Cap", cap_var)
                setattr(m, f"{s_name}_P_in", p_in)
                setattr(m, f"{s_name}_P_out", p_out)
                setattr(m, f"{s_name}_State", state)

                dev_c = self.params['device_costs'].get(s_name, 1000)
                self._track_inv(s_name, cap_var, dev_c)
                store_maint = self.params['maintenance_rates'].get(s_name, 0.015)
                for d in m.Days:
                    for t in m.T:
                        self.maintenance_costs.append((p_in[d, t] + p_out[d, t]) * store_maint * self.weights[d])

                if s_name == "Battery_Array":
                    for d in m.Days:
                        for t in m.T:
                            self.battery_throughputs[d][t].append(p_in[d, t] + p_out[d, t])

                # 💡 挖出所有魔法参数
                c_rate = sp.get('charge_rate', 0.2)
                d_rate = sp.get('discharge_rate', 0.2)
                max_soc = sp.get('max_soc', 0.95)
                min_soc = sp.get('min_soc', 0.10) # 💡 这里现在直接由 GUI 发号施令
                eta_c = sp.get('eta_ch', 0.95)
                eta_d = sp.get('eta_dis', 0.95)
                loss = sp.get('loss_rate', 0.001)

                def make_rules(c, p_i, p_o, s, lr, e_c, e_d, cr, dr, m_max, m_min):
                    def r_pin(m, d, t): return p_i[d, t] <= c * cr
                    def r_pout(m, d, t): return p_o[d, t] <= c * dr
                    def r_smax(m, d, t): return s[d, t] <= c * m_max
                    # 💡 核心漏洞修复：填补原本缺失的最小放电深度保护方程式！
                    def r_smin(m, d, t): return s[d, t] >= c * m_min
                    def r_dyn(m, d, t):
                        prev = 23 if t == 0 else t - 1
                        return s[d, t] == s[d, prev] * (1 - lr) + p_i[d, t] * e_c - p_o[d, t] / e_d
                    return r_pin, r_pout, r_smax, r_smin, r_dyn

                r1, r2, r3, r3_min, r4 = make_rules(cap_var, p_in, p_out, state, loss, eta_c, eta_d, c_rate, d_rate, max_soc, min_soc)
                setattr(m, f"{s_name}_pin_lim", pyo.Constraint(m.Days, m.T, rule=r1))
                setattr(m, f"{s_name}_pout_lim", pyo.Constraint(m.Days, m.T, rule=r2))
                setattr(m, f"{s_name}_smax", pyo.Constraint(m.Days, m.T, rule=r3))
                # 💡 将新生的下界方程挂载进入矩阵运算体系
                setattr(m, f"{s_name}_smin", pyo.Constraint(m.Days, m.T, rule=r3_min))
                setattr(m, f"{s_name}_dyn", pyo.Constraint(m.Days, m.T, rule=r4))

                if len(bus_list) > 1:
                    for d in m.Days:
                        h_load = sum(self.load_data['loads'].get('HeatBus', {}).get(d, [0]))
                        c_load = sum(self.load_data['loads'].get('CoolBus', {}).get(d, [0]))
                        active_bus = "HeatBus" if h_load > 0 else "CoolBus" if c_load > 0 else bus_list[0]
                        for t in m.T:
                            self._add_consume(active_bus, p_in[d, t], d, t)
                            self._add_supply(active_bus, p_out[d, t], d, t)
                else:
                    for d in m.Days:
                        for t in m.T:
                            self._add_consume(bus_list[0], p_in[d, t], d, t)
                            self._add_supply(bus_list[0], p_out[d, t], d, t)

        # =====================================================================
        # 模块 5：通用母线基尔霍夫方程 (KCL)
        # =====================================================================
        if self.no_shortage_buses:
            print(f"[MILP引擎] 零失负荷模式已启用, 硬约束母线: {sorted(self.no_shortage_buses)}")
        for bus in self.active_buses:
            # 零失负荷母线: Short 上界=0 (等效硬约束缺额恒为 0); 其余母线走天价惩罚软约束
            _hard = bus in self.no_shortage_buses
            setattr(m, f"{bus}_Short", pyo.Var(
                m.Days, m.T, within=pyo.NonNegativeReals,
                bounds=(0, 0) if _hard else (0, None)))
            setattr(m, f"{bus}_Dump", pyo.Var(m.Days, m.T, within=pyo.NonNegativeReals))

            def make_bus_rule(b_name):
                def rule_balance(m, d, t):
                    sum_supply = sum(v for v in self.bus_supply[b_name][d][t])
                    sum_consume = sum(v for v in self.bus_consume[b_name][d][t])
                    # 👇 核心免疫抗体：如果数据源里没有这条母线的负荷，自动视为 0 负荷
                    try:
                        load_val = self.load_data['loads'][b_name][d][t]
                    except KeyError:
                        load_val = 0.0
                    short = getattr(m, f"{b_name}_Short")[d, t]
                    dump = getattr(m, f"{b_name}_Dump")[d, t]
                    return sum_supply + short == sum_consume + load_val + dump

                return rule_balance

            setattr(m, f"{bus}_Balance", pyo.Constraint(m.Days, m.T, rule=make_bus_rule(bus)))

        # =====================================================================
        # 模块 6：受控于 GUI 勾选的多目标自适应目标函数
        # =====================================================================
        # =========================================================================
        # 💡 终极天衣无缝补丁：全自动投资造价动态收集器
        # 强行重新编译 m.Total_Inv，彻底解决新设备、外层寻优设备投资造价漏算沦为 0 的 Bug！
        # =========================================================================
        all_var_map = {
            "Main_ASHP": "ASHP_Cap", "Gas_CHP": "CHP_Cap",
            "Ground_Source_HP": "GSHP_Cap", "Elec_Boiler": "EB_Cap",
            "Gas_Boiler": "GB_Cap", "Elec_Chiller": "EC_Cap",
            "Abs_Chiller": "AC_Cap", "Electrolyzer": "EL_Cap",
            "HydrogenFuelCell": "HFC_Cap", "MethanationReactor": "MR_Cap",
            "WHB": "WHB_Cap", "Roof_PV": "PV_Cap", "Wind_Farm": "Wind_Cap",
            "Battery_Array": "Battery_Array_Cap", "Thermal_Tank": "Thermal_Tank_Cap",
            "Heat_Tank": "Heat_Tank_Cap", "Cool_Tank": "Cool_Tank_Cap",
            "Hydrogen_Tank": "Hydrogen_Tank_Cap", "Gas_Tank": "Gas_Tank_Cap"
        }

        device_costs = self.params.get("device_costs", {})
        total_inv_expr = 0

        # 动态扫描当前场景激活的所有物理设备
        for comp_name, var_attr in all_var_map.items():
            cap_var = getattr(self.m, var_attr, None)
            if cap_var is not None:
                cost_per_kw = device_costs.get(comp_name, 0)
                total_inv_expr += cap_var * cost_per_kw

        # 强行粉碎旧的残缺组件，让真神财务公式归位
        if hasattr(self.m, "Total_Inv"):
            self.m.del_component("Total_Inv")
        self.m.Total_Inv = pyo.Expression(expr=total_inv_expr)

        m.Total_Maintenance = pyo.Expression(expr=sum(self.maintenance_costs))

        def op_cost_rule(m):
            return sum(sum(sum(v for v in self.operation_costs[d][t]) for t in m.T) * self.weights[d] for d in m.Days)

        m.Total_Op = pyo.Expression(rule=op_cost_rule)

        # ===================================================================
        # 碳交易配额模型 (论文 Eq.8-11)
        # ===================================================================
        # 实际碳排放总量 (吨/年, 多目标用)
        m.Total_Carbon = pyo.Var(within=pyo.NonNegativeReals, bounds=(0, 1e6))
        def actual_rule(m):
            return m.Total_Carbon == sum(
                sum(sum(v for v in self.carbon_actual[d][t]) for t in m.T) * self.weights[d] / 1000.0 for d in m.Days)
        m.Actual_Def = pyo.Constraint(rule=actual_rule)

        # 免费碳配额总量 (吨/年)
        m.Total_Quota = pyo.Var(within=pyo.NonNegativeReals, bounds=(0, 1e6))
        def quota_rule(m):
            return m.Total_Quota == sum(
                sum(sum(v for v in self.carbon_quota[d][t]) for t in m.T) * self.weights[d] / 1000.0 for d in m.Days)
        m.Quota_Def = pyo.Constraint(rule=quota_rule)

        # 净交易量 (吨/年, 正=买, 负=卖)
        m.Trade = pyo.Var(within=pyo.Reals, bounds=(-1e6, 1e6))
        m.Trade_Def = pyo.Constraint(expr=m.Trade == m.Total_Carbon - m.Total_Quota)

        # 拆分为买/卖 (优化器自然不会同时买+卖)
        m.Carbon_Buy = pyo.Var(within=pyo.NonNegativeReals, bounds=(0, 1e6))
        m.Carbon_Sell = pyo.Var(within=pyo.NonNegativeReals, bounds=(0, 1e6))
        m.BuySell_Def = pyo.Constraint(expr=m.Carbon_Buy - m.Carbon_Sell == m.Trade)

        # 阶梯碳价 (论文 Eq.11): l=100t, α=0.25, 基础碳价 λ 可经
        # Parameters.economic.carbon_price 注入 (场景敏感性实验用),
        # 未配置时默认 250¥/t — 与论文主实验口径一致
        # 💡 套利漏洞修复: 原方案 CCT_buy 用 Piecewise 'LB'、CCT_sell 用 'UB',
        #    凸阶梯函数的 UB 表示是整域弦线, 求解器可"低价买+虚高卖"凭空赚差价
        #    (实测: 净买86.9t时 买400t/卖313.1t, CCT=-1.9万元)。
        #    现改为与仿真层 system_builder 同构的 LP 纯净公式:
        #    买侧 = 增量分段 z1..z5 (最小化下精确取 f(x)); 卖侧 = 基础碳价线性回收。
        l, lam, alpha = 100, self.params['economic'].get('carbon_price', 250), 0.25
        seg_slopes = [lam * (1 + k * alpha) for k in range(5)]   # 250/312.5/375/437.5/500

        m.CCT_buy = pyo.Var(within=pyo.Reals)
        m.z_seg = pyo.Var(pyo.RangeSet(0, 4), within=pyo.NonNegativeReals)
        m.Carbon_Buy_Def = pyo.Constraint(expr=m.Carbon_Buy == sum(m.z_seg[k] for k in range(5)))
        m.z_seg_caps = pyo.ConstraintList()
        for k in range(4):   # 前4段每段容量 l=100t, 第5段无上限
            m.z_seg_caps.add(m.z_seg[k] <= l)
        m.CCT_buy_Def = pyo.Constraint(
            expr=m.CCT_buy == sum(seg_slopes[k] * m.z_seg[k] for k in range(5)))

        # CCT_sell: 卖配额按基础碳价线性赚取
        m.CCT_sell = pyo.Var(within=pyo.NonNegativeReals)
        m.CCT_sell_Def = pyo.Constraint(expr=m.CCT_sell == lam * m.Carbon_Sell)

        # 碳交易净成本 (负=赚钱)
        m.CCT = pyo.Var(within=pyo.Reals)
        m.CCT_Def = pyo.Constraint(expr=m.CCT == m.CCT_buy - m.CCT_sell)

        def grid_rule(m):
            return sum(sum(sum(v for v in self.grid_interactions[d][t]) for t in m.T) * self.weights[d] for d in m.Days)

        m.Total_Grid = pyo.Expression(rule=grid_rule)

        def battery_aging_rule(m):
            return sum(
                sum(sum(v for v in self.battery_throughputs[d][t]) for t in m.T) * self.weights[d] for d in m.Days)

        m.Total_BatteryThroughput = pyo.Expression(rule=battery_aging_rule)

        def fail_rule(m):
            pen = 0.0
            shortage_p = self.params['penalty']['shortage']
            dump_p = self.params['penalty']['dump']
            for d in m.Days:
                w = self.weights[d]
                for bus in self.active_buses:
                    short_var = getattr(m, f"{bus}_Short")
                    dump_var = getattr(m, f"{bus}_Dump")
                    pen += sum(short_var[d, t] * shortage_p + dump_var[d, t] * dump_p for t in m.T) * w
            return pen

        m.Total_Fail = pyo.Expression(rule=fail_rule)

        def objective_rule(m):
            CRF = self.CRF
            w = self.params['objective_weights']
            ref_c, ref_carb, ref_g = self.ref_cost, self.ref_carbon, self.ref_grid

            C_inv_annual = m.Total_Inv * CRF
            C_ma_annual = m.Total_Maintenance
            C_op_annual = m.Total_Op
            C_aging_annual = m.Total_BatteryThroughput * self.battery_aging_cost
            C_tax_annual = m.CCT  # 阶梯碳价 (论文 Eq.11)
            TA = C_inv_annual + C_ma_annual + C_op_annual + C_aging_annual + C_tax_annual

            OP_COST = C_op_annual + C_aging_annual + C_tax_annual

            OBJ = 0.0
            if "Cost" in self.active_goals:
                OBJ += (TA / ref_c) * w.get('cost', 1.0)
            if "OpCost" in self.active_goals:
                OBJ += (OP_COST / ref_c) * w.get('cost', 1.0)
            if "Carbon" in self.active_goals:
                OBJ += (m.Total_Carbon / ref_carb) * w.get('carbon', 1.0)
            if "Grid" in self.active_goals:
                OBJ += (m.Total_Grid / ref_g) * w.get('grid', 1.0)

            regularization = m.Total_Inv * 1e-8
            return OBJ + m.Total_Fail * 1e-4 + regularization

        m.OBJ = pyo.Objective(rule=objective_rule, sense=pyo.minimize)

    def optimize(self, solver_name='cbc'):
        print(
            f"\n[MILP引擎] 拓扑构建完毕，启动 ASL-{solver_name.upper()} 求解器寻优 (规模：{len(list(self.m.component_objects(pyo.Var)))}个变量簇)...")
        start_time = time.time()

        solver = pyo.SolverFactory(f'asl:{solver_name}')
        res = solver.solve(self.m, tee=False)

        print(f"[MILP引擎] 求解完成，耗时 {time.time() - start_time:.2f} 秒。状态: {res.solver.termination_condition}")

        if res.solver.termination_condition in [pyo.TerminationCondition.optimal,
                                                pyo.TerminationCondition.maxTimeLimit]:
            print("\n" + "=" * 50)
            print("🏆 MILP 全局唯一最优容量配置：")

            inv_val = pyo.value(self.m.Total_Inv)
            ma_val = pyo.value(self.m.Total_Maintenance)
            op_val = pyo.value(self.m.Total_Op)
            aging_val = pyo.value(self.m.Total_BatteryThroughput) * self.battery_aging_cost
            carbon_tons = pyo.value(self.m.Total_Carbon)
            tax_val = pyo.value(self.m.CCT)
            ta_val = inv_val * self.CRF + ma_val + op_val + aging_val + tax_val
            grid_val = pyo.value(self.m.Total_Grid)

            print(f"🎯 综合目标函数最优值 (加权): {pyo.value(self.m.OBJ):.4f}")
            print(f"   💰 年总成本 TA (完整): {ta_val:,.2f} 元")
            print(f"       ├─ 年化投资 C_inv (含置换, CRF={self.CRF:.4f}): {inv_val * self.CRF:,.2f} 元")
            print(f"       ├─ 年维护成本 C_ma:            {ma_val:,.2f} 元")
            print(f"       ├─ 年运行成本 C_op:            {op_val:,.2f} 元")
            print(f"       ├─ 电池老化成本 C_aging:       {aging_val:,.2f} 元")
            print(f"       └─ 阶梯碳交易 CCT (论文Eq.8-11):     {tax_val:,.2f} 元 (负=卖配额盈利)")
            if self.config.get("obj_lifecycle", False):
                lcc_val = ta_val / self.CRF if self.CRF > 0 else ta_val * self.params['economic']['project_life']
                print(f"   📅 全生命周期总成本 LCC ({self.params['economic']['project_life']}年): {lcc_val:,.2f} 元")
            print(f"   🌱 年碳排放量: {carbon_tons:.2f} 吨")
            print(f"   ⚡ 年电网交互量: {grid_val:,.2f} kWh")
            if pyo.value(self.m.Total_Fail) > 0:
                print(f"   ⚠️ 包含系统缺额/弃能惩罚: {pyo.value(self.m.Total_Fail):.2f}")
            print("-" * 50)

            var_map = {
                "Roof_PV": "PV_Cap", "Wind_Farm": "Wind_Cap", "Main_ASHP": "ASHP_Cap",
                "Ground_Source_HP": "GSHP_Cap",  # 💡 加上这一行
                "Gas_CHP": "CHP_Cap", "Elec_Boiler": "EB_Cap", "Elec_Chiller": "EC_Cap",
                "Electrolyzer": "EL_Cap", "HydrogenFuelCell": "HFC_Cap", "Battery_Array": "Battery_Array_Cap",
                "Thermal_Tank": "Thermal_Tank_Cap", "Heat_Tank": "Heat_Tank_Cap", "Cool_Tank": "Cool_Tank_Cap",
                "Hydrogen_Tank": "Hydrogen_Tank_Cap", "Gas_Tank": "Gas_Tank_Cap",
                "Abs_Chiller": "AC_Cap", "Gas_Boiler": "GB_Cap", "MethanationReactor": "MR_Cap",
                # 👇 在这里加上新设备的变量映射
                "PVT_Collector": "PVT_Cap",
                "WHB": "WHB_Cap"
            }

            for comp_name in self.config["Components"].keys():
                if comp_name in var_map:
                    var_name = var_map[comp_name]
                    cap_var = getattr(self.m, var_name, None)
                    if cap_var is not None:
                        opt_cap = pyo.value(cap_var)
                        if comp_name == "Roof_PV":
                            pieces = int(round(opt_cap / 0.265)) if opt_cap > 0 else 0
                            print(f"  ⚡ {comp_name}: {pieces} 片 (约 {int(round(pieces * 0.265))} kW)")
                            self.config["Components"][comp_name]["capacity"] = pieces * 0.265
                        elif comp_name == "Gas_CHP":
                            print(f"  ⚡ {comp_name}: {int(round(opt_cap))} kW")
                            if hasattr(self.m, "WHB_Cap"):
                                print(f"  ⚡ Waste_Heat_Boiler (WHB): {int(round(pyo.value(self.m.WHB_Cap)))} kW")
                            self.config["Components"][comp_name]["capacity"] = opt_cap
                        elif comp_name == "HydrogenFuelCell":
                            kg_per_h = opt_cap / (39.54 * 0.8) if opt_cap > 0 else 0
                            print(f"  ⚡ {comp_name}: {kg_per_h:.2f} kg/h (等效输出 {int(round(opt_cap))} kW)")
                            self.config["Components"][comp_name]["capacity"] = opt_cap
                        elif comp_name == "MethanationReactor":
                            kg_per_h = opt_cap / 39.54 if opt_cap > 0 else 0
                            print(f"  ⚡ {comp_name}: {kg_per_h:.2f} kg/h (等效耗能 {int(round(opt_cap))} kW)")
                            self.config["Components"][comp_name]["capacity"] = opt_cap
                            # 👇 拦截 PVT 并输出双重指标
                        elif comp_name == "PVT_Collector":
                            print(
                                f"  ⚡ {comp_name}: {int(round(opt_cap))} kW (峰值电功率) / 伴生 {int(round(opt_cap * 3.0))} kW (峰值热功率)")
                            self.config["Components"][comp_name]["capacity"] = opt_cap
                        elif comp_name == "WasteHeatBoiler":
                            # WHB 容量为固定值/NSGA-II传入值，此处报告配置容量及运行摘要
                            whb_cap_val = comps[comp_name].get("capacity", 600000)
                            print(f"  🔥 {comp_name}: {int(round(whb_cap_val))} kW (固定容量, η=0.75)")
                            # 报告典型日平均热回收量（如有求解结果）
                            if hasattr(self.m, "WHB_Heat_out"):
                                try:
                                    total_heat = sum(
                                        (v if (v := pyo.value(self.m.WHB_Heat_out[d, t])) is not None else 0)
                                        for d in self.m.Days for t in self.m.T
                                    )
                                    print(f"      └─ 典型日总回收热量: {total_heat:,.0f} kWh")
                                except Exception:
                                    pass
                            self.config["Components"][comp_name]["capacity"] = whb_cap_val
                        elif comp_name == "WHB":
                            print(f"  ⚡ {comp_name}: {int(round(opt_cap))} kW/kWh (NSGA-II寻优, 余热回收核心)")
                            self.config["Components"][comp_name]["capacity"] = opt_cap
                        else:
                            print(f"  ⚡ {comp_name}: {int(round(opt_cap))} kW/kWh")
                            self.config["Components"][comp_name]["capacity"] = opt_cap

            print("=" * 50 + "\n")
            return self.config
        else:
            print("❌ 严重错误：求解失败 (Infeasible)，请检查母线负荷是否冲突。")
            if self.no_shortage_buses:
                print("   [提示] 零失负荷模式已启用: 设备容量不足以覆盖负荷时模型必然不可行。")
                print("   → 请放宽容量上限 / 检查 ASHP·CHP·锅炉等供能设备边界, 或取消勾选「零失负荷模式」排查。")
            return self.config