# -*- coding: utf-8 -*-
"""
论文图: 固定 TOU 规则策略 (基线评价器 B) 执行流程 — 算法流程图风格
================================================================
画法对齐基线文献 Liu et al. 2025 (JES 122:116592) Fig.3 (全局算法流程)
与 Fig.4 (三档电价并列策略) 的合体:
  上部  全局主干: 典型日 d × 时刻 t 双层循环 + 热/冷侧先行
  中部  三档泳道: 谷/平/峰 各自 P_PV>L_e 判断 + Yes/No 双通道动作链
  下部  循环回收 (t=t+1 / d=d+1) + 年化输出
输出: 论文图片/TOU规则策略流程图.png
"""
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import _paper_figstyle  # noqa: F401  (统一风格)

C_ELE, C_HEAT = '#4C72B0', '#DD8452'

# draw.io 经典配色 (对齐 Liu et al. 2025 Fig.3/4)
F_ACT, E_ACT = '#D5E8D4', '#82B366'      # 动作框 浅绿
F_DEC, E_DEC = '#F8CECC', '#B85450'      # 判断菱形 浅粉
F_TER, E_TER = '#FFF2CC', '#D6B656'      # 起止/循环计数 浅黄
F_RED, E_RED = '#FDECEA', '#C00000'      # 红色强调 (forced buy-to-fill)
LW = 1.1


def box(ax, cx, cy, w, h, text, fc=F_ACT, ec=E_ACT, fs=9.6, tc='#333333',
        bold=False, lw=LW):
    b = FancyBboxPatch((cx - w / 2, cy - h / 2), w, h,
                       boxstyle='round,pad=0.02,rounding_size=0.10',
                       fc=fc, ec=ec, lw=lw, zorder=5)
    ax.add_patch(b)
    ax.text(cx, cy, text, ha='center', va='center', fontsize=fs,
            color=tc, zorder=6, linespacing=1.35,
            fontweight='bold' if bold else 'normal')


def diamond(ax, cx, cy, w, h, text, ec=E_DEC, fs=9.6):
    pts = np.array([[cx, cy + h / 2], [cx + w / 2, cy],
                    [cx, cy - h / 2], [cx - w / 2, cy]])
    ax.add_patch(plt.Polygon(pts, closed=True, fc=F_DEC, ec=ec, lw=LW,
                             zorder=5))
    ax.text(cx, cy, text, ha='center', va='center', fontsize=fs, zorder=6,
            linespacing=1.3)


def seg(ax, pts, color='#333333', lw=1.25):
    """折线: 中间段实线, 末段箭头。"""
    pts = list(pts)
    for a, b in zip(pts[:-2], pts[1:-1]):
        ax.plot([a[0], b[0]], [a[1], b[1]], color=color, lw=lw, zorder=3,
                solid_capstyle='round')
    a = FancyArrowPatch(pts[-2], pts[-1], arrowstyle='-|>',
                        mutation_scale=11, color=color, lw=lw, zorder=3,
                        shrinkA=0, shrinkB=0)
    ax.add_patch(a)


def lbl(ax, x, y, t, color='#333333'):
    ax.text(x, y, t, fontsize=9.2, style='italic', color=color, ha='center',
            va='center', zorder=7,
            bbox=dict(fc='white', ec='none', pad=0.5))


def draw():
    fig, ax = plt.subplots(figsize=(8.8, 9.4))
    ax.set_xlim(-0.85, 13.75)
    ax.set_ylim(1.7, 17.75)
    ax.axis('off')

    # ================= 主干顶部 =================
    box(ax, 6.65, 17.3, 1.7, 0.55, 'Start', F_TER, E_TER, fs=10.5, bold=True)
    seg(ax, [(6.65, 17.02), (6.65, 16.75)])
    box(ax, 6.65, 16.35, 5.2, 0.75,
        '$d$ = 1 (typical-day index)\nSOC$_{ba}$, SOC$_{tk} \\leftarrow$ lower bound',
        F_TER, E_TER)
    seg(ax, [(6.65, 15.97), (6.65, 15.73)])
    box(ax, 6.65, 15.25, 7.9, 0.92,
        'Input typical-day profiles $P_{PV}(d,t)$, $L_e/L_h/L_c(d,t)$, TOU tags $c_t$;\n'
        'derive $C_{ASHP}$ = max hourly thermal / cooling peak $\\div$ COP (not optimized)')
    seg(ax, [(6.65, 14.79), (6.65, 14.67)])
    box(ax, 6.65, 14.4, 1.7, 0.5, '$t$ = 1', F_TER, E_TER)
    seg(ax, [(6.65, 14.15), (6.65, 13.97)])

    # ---- 热/冷侧先行 ----
    diamond(ax, 6.65, 13.45, 3.3, 1.0, 'peak hour?\n(thermal side)')
    seg(ax, [(4.98, 13.45), (4.17, 13.45)])
    lbl(ax, 4.58, 13.62, 'No')
    box(ax, 2.6, 13.45, 3.1, 1.0,
        'ASHP serves heat / cooling\ndirectly;\nvalley: also charges tank')
    seg(ax, [(8.32, 13.45), (9.13, 13.45)])
    lbl(ax, 8.72, 13.62, 'Yes')
    box(ax, 10.7, 13.45, 3.1, 1.0,
        'tank discharges first;\nshortfall covered\nby ASHP')
    seg(ax, [(2.6, 12.95), (2.6, 12.9), (5.8, 12.9), (5.8, 12.725)])
    seg(ax, [(10.7, 12.95), (10.7, 12.9), (7.5, 12.9), (7.5, 12.725)])
    box(ax, 6.65, 12.45, 5.6, 0.55, 'Merge ASHP electric power into load $L_e$')
    seg(ax, [(6.65, 12.175), (6.65, 12.02)])

    # ---- 档位分发 ----
    diamond(ax, 6.65, 11.55, 3.0, 0.9, '$c_t$ = valley?')
    seg(ax, [(5.15, 11.55), (3.5, 11.55)])
    lbl(ax, 4.4, 11.72, 'Yes')
    seg(ax, [(6.65, 11.1), (6.65, 10.82)])
    lbl(ax, 6.95, 10.95, 'No')
    diamond(ax, 6.65, 10.35, 3.0, 0.9, '$c_t$ = flat?')
    seg(ax, [(6.65, 9.9), (6.65, 9.67)])
    lbl(ax, 6.95, 9.78, 'Yes')
    seg(ax, [(8.15, 10.35), (11.125, 10.35), (11.125, 10.22)])
    lbl(ax, 9.2, 10.52, 'No (peak)')

    # ================= 三档泳道 =================
    # 列1 谷 (蓝) — 分支箭头自菱形斜边垂下 (无短横折), 两子框同中心高
    diamond(ax, 2.35, 11.55, 2.25, 0.95, '$P_{PV} > L_e$?', ec=C_ELE)
    seg(ax, [(1.3, 11.518), (1.3, 10.72)])
    lbl(ax, 0.92, 11.32, 'Yes')
    box(ax, 1.3, 10.12, 2.0, 1.15,
        'charge battery\n(rate-limited);\nSOC$_{ba}$ < max $\\rightarrow$\nbuy to fill $\\bigstar$',
        F_RED, E_RED, tc=E_RED, bold=True, lw=1.5)
    seg(ax, [(3.4, 11.518), (3.4, 10.53)])
    lbl(ax, 3.82, 11.18, 'No')
    box(ax, 3.4, 10.12, 2.0, 0.78, 'buy from\ngrid')
    # 列2 平 (灰)
    diamond(ax, 6.65, 9.2, 2.25, 0.9, '$P_{PV} > L_e$?', ec='#8C8C8C')
    seg(ax, [(5.6, 9.17), (5.6, 8.74)])
    lbl(ax, 5.28, 8.98, 'Yes')
    box(ax, 5.6, 8.28, 2.0, 0.88, 'charge battery;\nfull $\\rightarrow$ dump\n(no sell)')
    seg(ax, [(7.7, 9.17), (7.7, 8.68)])
    lbl(ax, 8.05, 8.95, 'No')
    box(ax, 7.7, 8.28, 2.0, 0.75, 'buy from\ngrid')
    # 列3 峰 (橙) — 整体下移, 与谷/平两列支路同深; No 选项不再偏右上
    diamond(ax, 11.125, 9.75, 2.25, 0.9, '$P_{PV} > L_e$?', ec=C_HEAT)
    seg(ax, [(10.0, 9.75), (10.0, 9.26)])
    lbl(ax, 9.68, 9.5, 'Yes')
    box(ax, 10.0, 8.85, 2.0, 0.8, 'dump surplus\n(no sell)')
    seg(ax, [(12.25, 9.75), (12.25, 9.29)])
    lbl(ax, 12.62, 9.5, 'No')
    box(ax, 12.25, 8.85, 2.05, 0.85, 'battery discharge;\nshortfall $\\rightarrow$ buy')

    # ---- 汇流 ----
    yb = 7.6
    for x, ytop in [(1.3, 9.545), (3.4, 9.73), (5.6, 7.84), (7.7, 7.905),
                    (10.0, 8.45), (12.25, 8.425)]:
        ax.plot([x, x], [ytop, yb], color='#333333', lw=1.25, zorder=3,
                solid_capstyle='round')
    ax.plot([1.3, 12.25], [yb, yb], color='#333333', lw=1.25, zorder=3)
    seg(ax, [(6.65, yb), (6.65, 7.42)])

    # ================= 主干底部 =================
    diamond(ax, 6.65, 6.95, 2.6, 0.9, '$t < 24$?')
    seg(ax, [(0.05, 6.95), (5.35, 6.95)])
    lbl(ax, 4.9, 7.12, 'Yes')
    ax.plot([0.05, 0.05], [6.95, 14.4], color='#333333', lw=1.25, zorder=3)
    seg(ax, [(0.05, 14.4), (5.78, 14.4)])
    box(ax, 0.05, 8.9, 1.3, 0.5, '$t = t$+1', F_TER, E_TER, fs=9.7)
    seg(ax, [(6.65, 6.5), (6.65, 6.28)])
    lbl(ax, 6.95, 6.42, 'No')
    box(ax, 6.65, 5.9, 6.0, 0.75,
        'Day-end SOC residual unpenalized;\nannualize by day weight $w_d$')
    seg(ax, [(6.65, 5.525), (6.65, 5.32)])
    diamond(ax, 6.65, 4.85, 2.6, 0.9, '$d < 4$?')
    seg(ax, [(7.95, 4.85), (9.28, 4.85)])
    lbl(ax, 8.5, 5.02, 'Yes')
    box(ax, 10.1, 4.85, 1.6, 0.5, '$d = d$+1', F_TER, E_TER, fs=9.7)
    ax.plot([10.9, 13.4], [4.85, 4.85], color='#333333', lw=1.25, zorder=3)
    ax.plot([13.4, 13.4], [4.85, 16.35], color='#333333', lw=1.25, zorder=3)
    seg(ax, [(13.4, 16.35), (9.27, 16.35)])
    seg(ax, [(6.65, 4.4), (6.65, 4.03)])
    lbl(ax, 6.92, 4.21, 'No')
    box(ax, 6.65, 3.7, 5.2, 0.65, 'Output: annual objectives (TA, AC, TG)',
        F_ACT, E_ACT, bold=True)
    seg(ax, [(6.65, 3.375), (6.65, 3.11)])
    box(ax, 6.65, 2.83, 1.7, 0.55, 'End', F_TER, E_TER, fs=10.5, bold=True)

    ax.text(6.65, 2.05, '$\\bigstar$ forced valley purchase — the systematic-bias '
            'source quantified in §5.1', fontsize=10.0, style='italic',
            color=E_RED, ha='center', va='center')

    fig.tight_layout(pad=0.3)
    fig.savefig('论文图片/TOU规则策略流程图.png', dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('已保存: 论文图片/TOU规则策略流程图.png')


if __name__ == '__main__':
    draw()
